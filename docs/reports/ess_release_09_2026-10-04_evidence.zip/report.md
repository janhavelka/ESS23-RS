# Prompt 09: finite relative positioning and stop interruption

Implemented only [prompt 09](../prompts/ess_release/09_first_relative_motion.md)
under its execution contract. Baseline/upstream: `ac27c3a`; the final commit is
the commit introducing this report. Software, installed consumer, four firmware
builds, read-only COM13 regression and qualification gate checks: **PASS**.
Physical positive/negative moves, independent shaft observations and dynamic
stop latency: **NOT RUN**, because required predecessor electrical/stop evidence
and sign/basis/ramp/input qualification remain unresolved. No gate was bypassed.

[Structured evidence](ess_release_09_2026-10-04.json) and the
[evidence archive](ess_release_09_2026-10-04_evidence.zip) retain both firmware
runs, exact images, raw traffic/console records, stack diagnostics, source
snapshots, verification logs and a SHA-256 member manifest. Simulated sequence
evidence below is distinct from physical effects.

## Delivered APIs and ownership

[MoveOperation.h](../../include/MotorControlRS/MoveOperation.h) supplies the
common `MoveRequest` and explicit `VERIFIED_CONFIGURED` ramp selection.
[ESS Position.h](../../include/MotorControlRS/profiles/ess_rs/Position.h) supplies
`MovePrerequisites`, `MoveContext`, `PreparedMove`, `prepareMoveRelative`,
`nextMove` and `advanceMove`. The common preparation calls the same profile
implementation and existing `preparePosition`; no second conversion or I/O
path was introduced. Installed C++11 consumers need no example include path.

The caller owns fixed contexts, supplies time and copied transport events, and
keeps admitted expectations immutable. Complete preconditions precede any
yielded write. Frame pointers are borrowed only during advancement; up to nine
response bytes per evidence record are copied. The original exact/approximate
input, effective displacement/endpoint, prerequisites and five transaction
evidence records remain inspectable. Setup execution, trigger execution,
observed completion and uncertainty are separate. No terminal phase retries.

The sequence stages exactly the reviewed FC10 `0x0021/5` window, then sends the
checked finite-relative noninterrupting FC06 `0x0027=0x0001`. Bounded waits yield
the bus before FC03 alarm/motion observations. Completion requires a fresh
post-trigger RUNNING report followed by a later ARRIVED/non-running report.
An old arrival flag, target equality or trigger echo cannot complete a move;
a short move missed between polls remains unobserved. Final qualified closure
before the immutable deadline can succeed when serviced later. Partial/lost
setup or trigger evidence retains uncertainty without replay.

The application extends the existing action service loop, owner and axis
reservation. Competing same-axis target/speed/configuration writes reject while
reserved; unrelated reads/other targets continue. Cooperative independent writes
use `admitAxisWrite`, which checks target generation and invalidates matching
observations and current-axis qualification after admission. Priority stop
supersedes unsent continuation work while physical TX settles. Stop/interrupted
results remain separately retained, including under full ordinary result pressure.

The CLI exposes `move relative <value> <unit> <native|motor|load> <native_rpm>
configured [address]` and its `profile ess_rs move-relative` route. Exact parsing
and preparation are shared. Admission is `accepted`, followed by one `type=move`
terminal; `result` is non-consuming and `release` explicit. Eight ordinary
application slots, one dedicated stop slot, one monitor slot and ten console
correlations remain bounded. Maximum tested retained move line is 3995/4096
bytes, including extreme approximate provenance and all five evidence records.

The finite Python scenario attempts one move, inspects retention, sends one
explicit normal/direct cleanup stop after admission, reads final state/health
and releases local results. Rejected admission sends no cleanup motor command.
Broken framing poisons the session and leaves cleanup unknown; it never retries
the move or claims independent physical standstill. See [the contract](../ess_position.md).

## Requirement and failure audit

| Requirement / failure scenario | Production path and actual API | Native/build evidence | Hardware result and artifact | Remaining proof |
| --- | --- | --- | --- | --- |
| Complete exact target/speed/flags/ramp/readiness validation before writes | Common/profile `prepareMoveRelative`, fixed trigger flags | Parameter gates, unchanged outputs, signed32 extremes, negative gate, word order, zero displacement, common parity PASS | Positive/negative CLI reject with operation ID0 and zero TX PASS | Qualified units/basis/sign/ramp/start-speed/device bounds |
| Serial-only operation without implicit I/O changes | Explicit input/limit permission in `MovePrerequisites` | Unresolved permission rejects; qualified fixture needs no home/limit/output metadata PASS | Configuration frames identical before/after PASS | Actual assigned-input effects/wiring qualification; any changes belong to15 |
| Stage then trigger only after checked preceding write | `nextMove`/`advanceMove` using existing FC10/FC06 policy | Literal19-byte request, wrong echo/CRC/address/function, known/unknown exceptions at every transaction PASS | No write transmitted | Physical stage/trigger behavior |
| Partial setup/lost trigger acknowledgement remains uncertain | Separate staging/trigger/failure evidence; application conflict bitmap | Partial/full TX cancellation/failure/deadline matrices; no next write/retry; retained historical uncertainty PASS | Gate checks PASS | Physical execution cannot be inferred from transport failure |
| Same-axis ownership spans staging, trigger and waits | Existing records/reservation plus `admitAxisWrite` | Injected second-producer target/speed/config writes reject between staging acknowledgement and trigger; original values alone trigger PASS | NOT APPLICABLE to gated write campaign | Future producers must use the application policy adapter |
| Priority stop/cancel while TX settles | Existing urgent owner path and shared action service | Stop at queued/setup/staging/trigger/early RUNNING/later RUNNING boundaries, active cancel, full retained pressure PASS | Normal/direct stop reject without TX PASS | Physical acceleration/movement/dynamic stop latency NOT RUN |
| Fresh completion and immutable deadline | Qualified closure bounds mapped into supplied `ActionEvent` | Old arrival, stale token/generation/time, observation limits, final closure straddling deadline, delayed on-time completion PASS | Cached observations retain timestamps and increase age PASS | Drive sample time and physical shaft proof absent |
| Configuration changes invalidate stale continuations | `invalidateAxis`, checked configuration delivery | Polarity/function/soft/over-limit changes cancel unsent continuation; in-flight frames settle PASS | Readback unchanged PASS | Requalification after actual configuration change |
| Real CLI/harness and portable package | Console host callback, retained formatter, `Console._check_move`, finite campaign | Actual SDK-fake application, strict parsing/correlation, generic rounding/radian inspection and no framing-failure replay PASS | Final-image CLI/gate and read-only paths PASS | Live move/cleanup scenario remains gated |
| Caller-owned bounded storage and resource limits | PSRAM `App` records; in-place `clearRecord`; internal driver/task stacks | C++11 installed consumer and all firmware builds PASS | Stack regression diagnosed, corrected and original scenario rerun PASS | Qualified moving-path stack/latency remains to measure |

## Source review and independent review findings

Original function-manual physical pages14–16 and70 were visually checked with
the ESS appendix/status material. Page16 orders acceleration, deceleration,
speed and target pair; its printed example has an extra byte. The native test
uses the corrected19-byte shape and independently computed CRC. Configured
ramps remain raw words, not physical acceleration. The speed/start-speed default
notation, full signed target range, firmware mapping and actual-relative basis
are not resolved by guessing. Enabled polarity remains RELEASED bit4 clear.
Readiness checks retain alarms and soft-limit effects instead of overriding them.

The manual/command reviewer independently authored actual application failure
tests; the sequence/completion reviewer authored the core sequence tests and
reviewed application invalidation; a third console/correlation reviewer audited
the integrated boundary and harness. The root checked their findings against
actual code/diff. Confirmed corrections during integration were:

- An admitted move was labelled `done`; it now reports `accepted`.
- Application admission silently replaced a supplied stale configuration
  generation; the original intent now rejects, while CLI supplies its own
  current generation through the existing axis query.
- Input assignments/polarity and drive limit changes were missing from axis
  invalidation; they now cancel dependent continuations.
- Independent writes accepted stale bindings and left move qualifications
  reusable; admission now rejects stale bindings and invalidates affected data.
  Review also corrected unrelated-target cache invalidation to use the existing
  matching-address watermark, preserving historical values/provenance.
- Retained Python inspection imposed CLI EXACT restrictions on direct API
  rounded/radian requests. Reports now retain selected input/error allowances;
  unknown-handle inspections validate provenance without inventing conversions.
- The first board campaign exposed insufficient stack headroom, diagnosed and
  fixed below. Focused non-author re-review found no remaining confirmed defect.

Current FieldCore RS485 owner/backend/module/CLI were inspected read-only at
`47f52e5519725ee16a43da576f4ba52d78b50551`. Yielded request/wait/result vocabulary
is compatible; its sensor retries, measurement-only contexts, TX8 capacity and
equal-TX echo stripping are deliberate differences. This reviewed FC10 request
needs19 TX bytes; that integration remains separately authorized. No FieldCore,
generated descriptor or preserved vendor file changed.

## Verification and board resource correction

Strict GCC15.1.0 C++11 Release build with `-Werror`: **23/23 CTest suites PASS**,
including new `position` and actual `move_app`, both previous application builds,
131 Python harness tests and13 inventory negative cases. Separate generator
negative tests8/8 PASS, version/register checks PASS, contrast snapshots5/5 PASS.
Installed-header/archive-only consumer1/1 PASS. All four PlatformIO environments
(`bench_s3_units`, `bench_s3_probe`, load polling and timer capture) PASS with the
existing pinned Arduino3.3.11/IDF5.5.5/Xtensa14.2.0 toolchain. No warnings were
weakened. `git diff --check` PASS. Initial fixture/build issues were corrected
before these final runs; no uncertain motor write was replayed.

The first new image (410176bytes,
`1e01b619320071bc19e3d823fe7a8e527637c4daf54d905a97ea47758995f082`)
passed28 checked reads and zero-TX gates but reported only36 bytes of owner
stack headroom. ELF disassembly identified complete `App::Record` assignment
temporaries: loop frame2432, typed-read admission2064, release1968 bytes.
Adding the824-byte move context to each record enlarged these stack temporaries.
This resource defect was retained as an unsuccessful qualification observation,
despite no panic or transport error.

`clearRecord` now destroys/reconstructs directly in the existing PSRAM slot,
with no heap allocation or whole-record temporary. Initial preparation also
uses the free retained move slot instead of a duplicate context. The compiled
loop frame fell to768 bytes and release to32; task stack allocation was not
increased. Native lifetime/release/reuse tests and independent lifetime review
pass. The same hardware campaign was deliberately rerun after uploading the
fixed image: owner headroom **3636 bytes**, worker headroom3268 bytes. The original
36-byte snapshot, image and before/after frame diagnostics remain in the archive.

Xtensa object sizes: `MoveContext`824, `PreparedMove`72,
`MovePrerequisites`56 bytes; native host sizes944/80/56. Large records, queue,
frames/output and trace remain PSRAM; ISR/driver state and stacks remain internal.
New retained contexts account for the8192-byte PSRAM allocation increase from
the previous image. No additional task, queue, scheduler or conversion exists.

## Final-image COM13 evidence

COM13 was reidentified as USB303A:1001, serial `3C:0F:02:CD:6B:98`. The uploaded
timer image is409424 bytes, SHA-256:

`12f2e54bfde7ab96238308dfb7ed5ee0f82d83483e4c920e2c571e6f194d54bf`

UART remains address1/115200/8N1, TX47/RX48/DE21, 200000-us response timeout,
304-us reviewed bench reply gap, 85-us capture guard and20-us timer. Original
16-MiB CO2control backup hash is unchanged:
`85c089bc3956b22037af7e6f0d7945f6ed778bb1a0526fb5b2ba3e8fea02d0c1`.
No reset/recover command cleared faults or statistics to obtain a passing run.

Final campaign:28 checked FC03 frames/288 RX bytes (identity, configuration and
state before/after,37-byte capture reply and10 model probes). Positive and
negative common moves, the finite Python scenario and all five action choices
reject `timing_unqualified`, operation ID0, with transport counters unchanged.
The finite scenario explicitly records cleanup `not_required` on admission
rejection. Ten additional one-attempt probes at50-ms intervals pass. Final
totals: **38 frames/358 RX bytes**, zero failures/timeouts/cancellations/capture
faults/UART errors, discarded or echo bytes. No motor write or motion was sent.

Raw before/after configuration/state frames are identical. Model4EEA/version0029,
node1/DIP0, subdivision1000, algorithm3 (unknown), configured encoder4000,
word-order0, assigned inputs1/2/3/0, input polarity0 and soft/over-limit settings0
remain recorded. Alarm0/motion1, input/output0 and speed/position0 are checked
drive reports, not independent standstill or physical-unit proof. User-confirmed
ESS23-RS20 identity does not identify firmware behavior or turn subdivision
feedback into measured encoder position. Cached queries preserve observation
bounds; motion-block age rises168091 to333134us without a refresh.

Campaign model probes take5435–5491us;37-byte capture8091us. Ending maximum
owner gap133us/capture gap55us, capture high-water2, no85-us guard exceedance.
Optional trace overwrites610 are retained diagnostics. Ending capture section
7191859us/46019979us elapsed is15.63% of one core; the separate scheduler sample
reports0%/6% busy. This unloaded snapshot does not extend prompt04 qualification.
Internal free/minimum/largest336656/331496/278516 bytes; PSRAM
8310316/8310316/8257524 bytes. Ending load/monitor off, DE released, no pending,
retained/reserved work or recovery requirement; zero blocked/short output and
dropped input. Cleanup changed no motor state or setting.

## Remaining gates and handoff to10–11

The software ceiling is +/-250 native increments,60 nativeRPM, a3-second absolute
deadline and64 polls spaced20ms. It is a proposed software bound, **not a recorded
qualified physical movement envelope**. Live movement requires independent
TX/RX/DE/closure and FC06 echo-source evidence, usable physical stop, verified
command increment/relative basis/sign/target range, ramp/start-speed semantics
and actual input/limit permission. No available analyzer or independent shaft
observation was supplied; no physical effects or dynamic stopping were fabricated.

These gates also block required positive/negative move/readback/shaft comparison,
acceleration-phase stop and measured dynamic-stop latency. A tiny move missed
by bounded polling cannot be claimed complete. Future absolute/velocity work
must reuse the same axis reservation, explicit preparation and uncertainty
contract; it must not expand write access or derive physical acceleration from
ambiguous raw milliseconds. Prompt10 was not executed.
