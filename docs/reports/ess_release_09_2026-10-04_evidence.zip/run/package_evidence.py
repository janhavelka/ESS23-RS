import hashlib
import json
from pathlib import Path
import subprocess
import zipfile
ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
REPORTS = ROOT / 'docs/reports'
STEM = 'ess_release_09_2026-10-04'
def sha(data): return hashlib.sha256(data).hexdigest()
summary = {key: json.loads((HERE / name).read_text(encoding='utf-8')) for key, name in
           [('preflight','preflight.json'), ('before_stack_fix','before-stack-fix.json'),
            ('campaign','summary.json'), ('ending','ending.json')]}
ending = summary['ending']
assert ending['stats']['frames'] == 38 and ending['stats']['rx_bytes'] == 358
assert not any(ending['stats'][k] for k in ('failed','timeouts','cancelled','capture_faults','rx_errors','echo_bytes','discarded'))
assert not any(ending['drv'][k] for k in ('busy','transmit_enabled','recovery_required','pending','retained','reserved','input_dropped','output_blocked','output_short_writes'))
assert ending['memory']['stack_free_bytes'] == 3636
assert summary['before_stack_fix']['final_memory']['stack_free_bytes'] == 36
for command in ('status','health'):
 for first, second in zip(summary['campaign']['cached_first'][command]['state_blocks'], summary['campaign']['cached_second'][command]['state_blocks']):
  assert first['observed_earliest_us'] == second['observed_earliest_us']
  assert first['observed_latest_us'] == second['observed_latest_us'] and second['age_us'] > first['age_us']
backup = ROOT/'build/bench/co2control_com13_before.bin'
assert backup.stat().st_size == 16777216
assert sha(backup.read_bytes()) == '85c089bc3956b22037af7e6f0d7945f6ed778bb1a0526fb5b2ba3e8fea02d0c1'
summary['verification'] = {
 'baseline': subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip(),
 'final_commit': 'The commit introducing this report and evidence',
 'scope': 'Prompt09 only; physical moves/dynamic stop NOT RUN behind required qualification gates',
 'native': {'result':'PASS','suites':23,'compiler':'GCC15.1.0','language':'C++11','flags':'-Werror',
            'python_harness_cases':131,'inventory_negative_cases':13},
 'generator_negative':{'result':'PASS','cases':8}, 'contrasts':{'result':'PASS','references':5},
 'installed_consumer':{'result':'PASS','tests':1,'examples_include_path':False},
 'firmware':{env:'PASS' for env in ('bench_s3_units','bench_s3_probe','bench_s3_load_poll','bench_s3_load_timer')},
 'hardware':{'read_only':'PASS','move_action_zero_TX_gates':'PASS','stack_regression_rerun':'PASS',
             'positive_negative_moves':'NOT RUN','independent_shaft_measurement':'NOT RUN','dynamic_stop_latency':'NOT RUN'},
 'target_sizes':{'MoveContext':824,'PreparedMove':72,'MovePrerequisites':56},
 'native_sizes':{'MoveContext':944,'PreparedMove':80,'MovePrerequisites':56},
 'maximum_move_report_bytes':3995,'report_capacity':4096,
 'stack_root_cause':{'before_loop_frame':2432,'after_loop_frame':768,'before_release_frame':1968,'after_release_frame':32,
                    'fix':'Reconstruct caller-owned record in PSRAM slot; no temporary full record and no stack enlargement'},
 'backup':{'bytes':backup.stat().st_size,'sha256':sha(backup.read_bytes())},
 'fieldcore_read_only_commit':'47f52e5519725ee16a43da576f4ba52d78b50551',
 'host_verification_notes':[
   'Early build ran before delegated position test existed; registered source then rebuilt successfully.',
   'Application fixture/unit spelling and supplied monotonic event-time mistakes were corrected before final tests.',
   'Move admission incorrectly labelled done and stale generation override were confirmed/fixed by actual application tests.',
   'Catalogue record ID typo corrected to POSITION_PULSES; physical-model inventory fixture updated independently of firmware qualification.',
   'First stack invalidation correction used a nonexistent fixture enum SPEED; corrected to FEEDBACK before rebuilt test execution.',
   'Target GDB inspection could not load DWARF; sizes instead measured by target-compiled sizeof arrays and nm, not claimed GDB success.',
   'First final-image campaign retained with insufficient36-byte stack headroom despite28 passing reads; root cause and original scenario rerun retained.',
 ]
}
(REPORTS/(STEM+'.json')).write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
(HERE/'implementation.diff').write_bytes(subprocess.check_output(['git','diff','--','.',':!docs/reports/*'],cwd=ROOT))
members={}
def add(path,name): members[name]=path.read_bytes()
for path in HERE.iterdir():
 if path.is_file(): add(path,'run/'+path.name)
for directory in ('src','include','examples','scripts','test'):
 for path in (ROOT/directory).rglob('*'):
  if path.is_file() and '__pycache__' not in path.parts and path.suffix!='.pyc':
   add(path,'source/'+path.relative_to(ROOT).as_posix())
for name in ('CMakeLists.txt','platformio.ini','library.json','AGENTS.md','README.md',
             'docs/ess_position.md','docs/ess_actions.md','docs/profile_contract.md','docs/cli_contract.md',
             'docs/hardware_bench.md','docs/backlog.md','docs/roadmap.md','docs/reference/ess_rs_operations.json',
             'docs/prompts/ess_release/09_first_relative_motion.md','docs/prompts/ess_release/execution_contract.md',
             'docs/prompts/ess_release/README.md','docs/axis_contract.md'):
 add(ROOT/name,'source/'+name)
for env in summary['verification']['firmware']:
 for name in (('firmware.bin','firmware.elf') if env=='bench_s3_load_timer' else ('firmware.bin',)):
  add(ROOT/'.pio/build'/env/name,'firmware/'+env+'/'+name)
for path,name in [('build/native/Testing/Temporary/LastTest.log','native_final.log'),('build/native/CMakeCache.txt','native_cache.txt'),
                  ('build/installed_consumer09/Testing/Temporary/LastTest.log','installed_consumer.log')]:
 add(ROOT/path,'verification/'+name)
add(REPORTS/(STEM+'.md'),'report.md'); add(REPORTS/(STEM+'.json'),'report.json')
manifest={name:{'bytes':len(data),'sha256':sha(data)} for name,data in sorted(members.items())}
archive=REPORTS/(STEM+'_evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as out:
 for name,data in sorted(members.items()): out.writestr(name,data)
 out.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as out:
 assert out.testzip() is None
 for name,expected in manifest.items():
  data=out.read(name); assert len(data)==expected['bytes'] and sha(data)==expected['sha256']
print(json.dumps({'archive_bytes':archive.stat().st_size,'members':len(manifest),'sha256':sha(archive.read_bytes())}))
