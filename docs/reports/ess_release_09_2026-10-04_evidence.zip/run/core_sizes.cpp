#include <MotorControlRS/profiles/ess_rs/Position.h>
extern "C" {
unsigned char move_context_bytes[sizeof(MotorControlRS::ESS_RS::MoveContext)];
unsigned char prepared_move_bytes[sizeof(MotorControlRS::ESS_RS::PreparedMove)];
unsigned char move_prerequisites_bytes[sizeof(MotorControlRS::ESS_RS::MovePrerequisites)];
}
