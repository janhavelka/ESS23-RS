import sys, time, re, json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'scripts'))
from bench_probe import BenchError, observe_stopped
from bench_session import run_recorded, checked
from bench_motion import restore_profile

def human(c, text, terminal=None, timeout=7):
    assert not c.pending and not c.buffer
    c.emit('human_command', text=text)
    c.port.write((text+'\n').encode())
    end=time.monotonic()+timeout; quiet=end; data=bytearray()
    while time.monotonic()<end:
        chunk=c.port.read(8192)
        if chunk:
            data.extend(chunk); quiet=time.monotonic()+.1
        decoded=data.decode('utf-8')
        if data and time.monotonic()>=quiet and (terminal is None or terminal in decoded):
            c.emit('human_output', text=decoded); print(text+'\n'+decoded,flush=True); return decoded
        time.sleep(.005)
    c.emit('human_output',text=data.decode('utf-8',errors='replace'))
    raise BenchError('human terminal missing for '+text)

def campaign(c,r):
    menu=human(c,'help'); r['help']=menu
    assert menu==human(c,'help advanced')==human(c,'?')
    entries=re.findall(r'^  ([a-z?-]+)\s',menu,re.M)
    assert len(entries)==len(set(entries)) and len(entries)>35
    assert not set(entries)&{'?','ver','ping','reset'}
    assert {'settings','moveby','moveto','stop','driver','io','read','debug','result','axis','stats'}<=set(entries)
    assert 'ESS emergency stop without the ramp' in menu
    r['canonical_entries']=entries
    r['stop_help']=human(c,'help stop')
    assert 'stop normal|direct' in r['stop_help'] and 'reserved priority' in r['stop_help']
    assert 'not a hardwired emergency-stop circuit' in r['stop_help']
    r['move_help']=human(c,'help move')
    assert 'move relative|absolute' in r['move_help'] and 'round' in r['move_help']
    r['driver_help']=human(c,'help driver')
    assert 'profile ess_rs' not in r['driver_help']
    r['settings']=human(c,'settings','Details:')
    assert 'Microstep / subdivision: 1000' in r['settings']
    wrapper=int(re.search(r'Details: @1 result (\d+)',r['settings']).group(1))
    checked(c,'release',operation_id=wrapper)
    r['identity']=checked(c,'read-identity',address=1)
    r['final_state']=observe_stopped(c,address=1,timeout_s=5)
    r['probes']=[checked(c,'probe',address=1) for _ in range(3)]
    r['workload_verified']=True

plan=dict(motor_writes=0,success='all menus identical and unique; explicit emergency-stop help; actual settings; checked stopped state and three probes',
          cleanup='release settings wrapper; no configuration or movement commands',automatic_write_replay=False)
print(json.dumps(plan),flush=True)
run_recorded(port='COM13',out=Path(sys.argv[1]),scenario='unified-help-readonly-regression',
             inputs=plan,run=campaign,refresh=False,
             firmware=Path('build/unified_help/pio/bench_s3_load_timer/firmware.bin'))
