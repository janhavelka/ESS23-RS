﻿#include <MotorControlRS/MotorControlRS.h>
#include <MotorControlRS/profiles/ess_rs/Traffic.h>
#include <MotorControlRS/profiles/ess_rs/Position.h>
#include <cassert>
int main() {
 using namespace MotorControlRS;
 uint8_t wire[64] = {};
 const auto n=ESS_RS::buildProbe(1,wire,sizeof(wire)); assert(n==8);
 TrafficRecord storage[4], copy; TrafficCapture capture(storage,4);
 capture.setEnabled(true); capture.begin(10); capture.transmitted(wire,n,true,11);
 uint64_t first=0,second=0; assert(capture.copyAfter(first,copy));
 ESS_RS::TrafficDecoded value; assert(ESS_RS::decodeTraffic(copy,nullptr,value));
 assert(value.function==3 && value.start==0 && value.count==1);
 assert(capture.copyAfter(second,copy) && first==second);
 ESS_RS::PositionProfile profile; profile.accelerationTime=100;
 profile.decelerationTime=100;profile.speed=60;profile.targetBits=100;
 assert(ESS_RS::buildWritePositionProfile(1,profile,ESS_RS::WordOrder::HIGH_WORD_FIRST,wire,sizeof(wire))==19);
}
