﻿import hashlib,json,pathlib,subprocess,zipfile
root=pathlib.Path.cwd(); bench=root/'build/bench/regular_sniff'; dest=root/'docs/reports'
phases={p.stem:json.loads(p.read_text()) for p in sorted(bench.glob('*.json')) if p.name!='preflight.json'}
final=phases['settled_final']; initial=phases['inspect_raw']; restored=phases['restore_final']['restore']
assert all(d['ok'] for d in phases.values())
assert restored['original']==restored['current']==[30,100,100,60,0,5000]
assert initial['configuration_before']['config']==final['configuration_before']['config']
summary=dict(baseline='8260081',final_revision='commit introducing this artifact',firmware_environment='bench_s3_load_timer',
 firmware_sha256=hashlib.sha256((bench/'firmware.bin').read_bytes()).hexdigest(),firmware_bytes=(bench/'firmware.bin').stat().st_size,
 phase_results={k:dict(ok=v['ok'],before=v.get('state_before'),after=v.get('state_after'),move=v.get('move'),sniff=v.get('ending_sniff'),restore=v.get('restore')) for k,v in phases.items()},
 final_stats=final['ending_stats'],final_load=final['ending_load'],final_memory=final['ending_memory'],final_owner=final['ending_drv'],final_host=final['ending_host'],
 final_sniff=final['ending_sniff'],configuration_restored=True,
 verification=dict(ctest='55/55 PASS',python_protocol='196 PASS',python_campaign='18 PASS',generator='18 PASS',firmware='4/4 standard environments PASS',installed_consumers='C++11/C++17 PASS'),
 independent_review=dict(traffic_records=1902,decoded_payloads=464,correlated_decoded_rx=217,tx_release_rx_orderings=267),
 wiring='user-supplied combined DE/~RE disables RX during TX; runner validates RX after physical TX/release/response gap',
 electrical_measurement='NOT RUN',independent_shaft_measurement='NOT RUN',hours_soak='NOT RUN by user request')
(dest/'regular_api_sniff_2026-10-04.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
changed=subprocess.check_output(['git','diff','HEAD','--name-only'],text=True,stderr=subprocess.DEVNULL).splitlines()
new=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
entries={}
for p in sorted(bench.iterdir()):
 if p.is_file(): entries['bench/'+p.name]=p.read_bytes()
for p in (root/'build/regular_sniff_consumer_src').iterdir():
 if p.is_file():entries['installed_consumer/'+p.name]=p.read_bytes()
for name in sorted(set(changed+new)):
 p=root/name
 if p.is_file() and not name.endswith('.zip'):entries['source/'+name]=p.read_bytes()
entries['working.diff']=subprocess.check_output(['git','diff','HEAD','--no-ext-diff'],stderr=subprocess.DEVNULL)
manifest={k:dict(bytes=len(v),sha256=hashlib.sha256(v).hexdigest()) for k,v in entries.items()}
with zipfile.ZipFile(dest/'regular_api_sniff_2026-10-04_evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for k,v in entries.items():z.writestr(k,v)
 z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(dest/'regular_api_sniff_2026-10-04_evidence.zip') as z:
 assert all(hashlib.sha256(z.read(k)).hexdigest()==v['sha256'] for k,v in manifest.items())
print(len(entries),'artifacts archived and verified')
