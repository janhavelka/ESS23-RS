﻿import sys,json,pathlib
sys.path.insert(0,'scripts')
from bench_probe import Console,Evidence,open_port
from serial.tools import list_ports
p=pathlib.Path('build/bench/regular_sniff')
d={'ports':[{'device':x.device,'hwid':x.hwid} for x in list_ports.comports()]}
with (p/'preflight.jsonl').open('x') as log, open_port('COM13',115200,5) as port:
 c=Console(port,on_event=Evidence(log)); c.drain_startup(.3)
 d['version']=c.identify()
 for name in ['host','config','stats','load','read-config','read-state','probe','memory','drv']:
  d[name]=c.command(name,timeout_s=5,**({'address':1} if name in ['read-config','read-state','probe'] else {}))
  assert d[name]['ok'],d[name]
(p/'preflight.json').write_text(json.dumps(d,indent=2)+'\n')
print('preflight complete',d['stats'])
