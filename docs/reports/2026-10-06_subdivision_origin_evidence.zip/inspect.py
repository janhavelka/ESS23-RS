import sys
from pathlib import Path
sys.path.insert(0,'scripts')
from bench_session import run_recorded,checked

def run(c,r):
    r['axis']=checked(c,'axis',host_args=('config',))
    r['profile']=checked(c,'motion-profile',profile_action='inspect')
    r['workload_verified']=True
run_recorded(port='COM13',out=Path('build/subdivision_origin/old-origin'),scenario='inspect-lost-origin',inputs={'read_only':True},run=run,refresh=False)
