import json, re, sys, time
from pathlib import Path
sys.path.insert(0, 'scripts')
from bench_session import run_recorded, checked
from bench_probe import BenchError, observe_stopped, FAULT_TEXT
from bench_motion import profile_snapshot, restore_profile

def send(c, text):
    assert not c.pending and not c.buffer
    c.emit('human_command', text=text)
    c.port.write((text+'\n').encode())

def receive(c, predicate, timeout=12):
    deadline=time.monotonic()+timeout; raw=bytearray(); quiet=deadline
    while time.monotonic()<deadline:
        part=c.port.read(4096)
        if part: raw.extend(part); quiet=time.monotonic()+.05
        text=raw.decode('utf-8')
        if len(raw)>32768 or FAULT_TEXT.search(text):
            c.synchronized=False
            raise BenchError('fault or excessive output during human command')
        if predicate(text) and time.monotonic()>=quiet:
            c.emit('human_output',text=text); print(text,flush=True); return text
        time.sleep(.005)
    c.synchronized=False
    c.emit('human_incomplete',text=raw.decode('utf-8',errors='replace'))
    raise BenchError('human command timeout; no replay')

def motion(c, text):
    send(c,text)
    out=receive(c,lambda s:'Details:' in s)
    assert 'Move complete' in out, out
    return out

def subdivision(c,value=None):
    text='subdivision' if value is None else f'subdivision {value}'
    send(c,text)
    out=receive(c,lambda s:'Details:' in s)
    assert ' complete' in out,out
    op=int(re.search(r'Details: @1 result (\d+)',out).group(1))
    result=c.command('result',operation_id=op)
    assert result['ok'],result
    checked(c,'release',operation_id=op)
    return {'text':out,'result':result}

def run(c,r):
    r['config']=checked(c,'read-config',address=1)
    r['baseline']=observe_stopped(c,address=1,timeout_s=5)
    r['profile']=profile_snapshot(c,timeout_s=5)
    changed=False; restore_attempted=False
    def prepare_setting():
        checked(c,'read-config',address=1)
        result=subdivision(c)
        observe_stopped(c,address=1,timeout_s=5)
        return result
    try:
        r['boot_zero']=motion(c,'moveto 0 deg')
        r['outward']=motion(c,'moveby 90 deg')
        r['before_restore']=observe_stopped(c,address=1,timeout_s=5)
        r['restored_while_offset']=restore_profile(c,timeout_s=5)
        r['axis_after_restore']=checked(c,'axis',host_args=('config',))
        assert r['axis_after_restore']['origin_known']
        assert r['axis_after_restore']['origin_native']==r['baseline']['state_blocks'][2]['raw_position']
        r['moveto_10']=motion(c,'moveto 10 deg')
        r['moveto_90']=motion(c,'moveto 90 deg')
        r['return']=motion(c,'moveto 0 deg')
        observe_stopped(c,address=1,timeout_s=5)
        r['profile_restored_again']=restore_profile(c,timeout_s=5)
        send(c,'subdivision options')
        r['options']=receive(c,lambda s:'no motion or save is automatic' in s)
        r['original_subdivision']=prepare_setting()
        assert 'Microstep / subdivision: 1000' in r['original_subdivision']['text']
        r['set_1600']=subdivision(c,1600); changed=True
        r['changed_readback']=prepare_setting()
        assert 'Microstep / subdivision: 1600' in r['changed_readback']['text']
        restore_attempted=True
        r['restore_1000']=subdivision(c,1000); changed=False
        r['restored_readback']=prepare_setting()
        assert 'Microstep / subdivision: 1000' in r['restored_readback']['text']
        r['workload_verified']=True
    finally:
        if c.synchronized:
            r['cleanup_stop']=checked(c,'stop',address=1,stop_policy='normal')
            r['cleanup_state']=observe_stopped(c,address=1,timeout_s=5)
            if changed and not restore_attempted:
                prepare_setting(); restore_attempted=True
                r['cleanup_restore_1000']=subdivision(c,1000)
        else:
            r['cleanup']='unknown: framing lost; no replay'

run_recorded(port='COM13',out=Path(sys.argv[1]),scenario='origin-restore-and-subdivision',
    inputs={'moves_deg':[0,90,10,90,0],'subdivision':[1000,1600,1000],'speed_rpm':60,'ramps_ms':100},run=run,refresh=False,
    firmware=Path('build/ownership_fix/pio/bench_s3_load_timer/firmware.bin'))
