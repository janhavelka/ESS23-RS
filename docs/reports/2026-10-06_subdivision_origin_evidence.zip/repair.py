import sys
from pathlib import Path
sys.path.insert(0,'scripts')
from bench_session import run_recorded,checked
from bench_probe import observe_stopped

def run(c,r):
    r['config']=checked(c,'read-config',address=1)
    r['state']=observe_stopped(c,address=1,timeout_s=5)
    r['driver']=checked(c,'driver',address=1,driver_args=('read',))
    r['restore']=checked(c,'driver',address=1,driver_args=('set','subdivision','1000'))
    r['readback']=checked(c,'driver',address=1,driver_args=('read',))
    assert r['readback']['observation']['raw'][1]==1000
    r['cleanup_stop']=checked(c,'stop',address=1,stop_policy='normal')
    r['cleanup_state']=observe_stopped(c,address=1,timeout_s=5)
    r['workload_verified']=True
run_recorded(port='COM13',out=Path('build/subdivision_origin/explicit-restore'),scenario='explicit-subdivision-restoration',inputs={'before':1600,'restore':1000,'prior_rejection':'no TX'},run=run,refresh=False)
