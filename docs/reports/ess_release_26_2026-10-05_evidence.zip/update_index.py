from pathlib import Path
p=Path('docs/prompts/ess_release/README.md')
s=p.read_text(encoding='utf-8')
rows=[]
for line in s.splitlines():
    if line.startswith('| [25 '):
        line=line.replace('native motion/load parity pending26','available native motion/load parity qualified in26')
    if line.startswith('| [26 '):
        columns=line.split('|')
        columns[3]=' Implemented and independently reviewed;68 CTest/233 Python/three Arduino builds PASS; matched S3 capture/load/state/finite motion/both stops/settings restoration; clean S2 core/portable and installed desktop builds; retained mismatch failure and unqualified fixtures remain explicit '
        columns[4]=' [Handoff/evidence](../../reports/ess_release_26_2026-10-05.md), [S2 compile fixture](../../../test/portability_consumer/README.md) '
        line='|'.join(columns)
    rows.append(line)
p.write_text('\n'.join(rows)+'\n',encoding='utf-8')
