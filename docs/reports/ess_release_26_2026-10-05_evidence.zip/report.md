# Prompt26 — Platform parity and portability

Baseline/upstream: `77ee61dfde3f9f349cee93f072bd8431050f2d23`. Final revision is
the commit containing this report and its test changes. Only prompt26 was
executed. Implementation and functional qualification of the available subset
PASS; full ESS coverage, endurance and unavailable fixtures remain open.

The secured ESS23-RS20 has a free shaft, power and RS485 only. Acceptance follows
the execution contract's short unattended functional procedure. No analyzer or
independent shaft measurement was used. Drive reports prove the tested software
behavior; they do not calibrate physical stopping distance or feedback units.

## Images and platform scope

| Consumer | Image SHA-256 / bytes | SDK and actual tuple | Evidence scope |
| --- | --- | --- | --- |
| Arduino ESP32-S3 `bench_s3_load_timer` | `4f6d5bc82af7ade90689be5d2405c0bba22e69bbded3c364e7ca7072afadbb11` /580608 | Arduino3.3.11, pioarduino55.03.311, IDF5.5.5;115200 8N1, actual115211 baud | Flashed with verification; matched physical campaigns below |
| Native ESP32-S3 | `4ae0eb2b194896f7cee93ce0f2bfe2af55489f0665b160a2a5e77430a952041c` /495248 | IDF5.5.5, Xtensa14.2.0+20260121; same tuple | Unchanged prompt25 image, reidentified and exercised before Arduino upload |
| ESP32-S2 core-only IDF consumer | Compile/link only; binary/config hashes in archive | Maintained IDF5.5.5 ESP32-S2 target, same compiler | Clean staged core; all27 public headers; no example/vendor include paths |
| ESP32-S2 portable application consumer | Compile/link only; binary/config hashes in archive | Same maintained target | Actual portable runner/owner/validator/console; missing physical port; no S3 adapter, pins or PSRAM requirement |
| Installed desktop core | Executed installed consumer | C++11, warnings as errors | All27 public headers; exported package only, no Arduino/IDF/ESP32/board/FieldCore/example include path |

Native source/configuration and exact image are inherited unchanged from the
[clean prompt25 build](ess_release_25_2026-10-05.md); this block changes tests and
documentation, not production firmware. Arduino's extracted shared application
was built in25 and is physically tested here. Three required Arduino builds
were repeated successfully in26. Native SDK guards still reject other SDKs/S3
configurations; a core S2 compile does not qualify an S2 UART/board adapter.

Both images use TX47/RX48/DE21, declared combined DE/~RE with receiver disabled
during TX, timer capture20us, character bounds85..89us, final frame gap1750us,
reply guard304us, response/request budgets200000/500000us, TX budget20000us and
recovery guard500000us. The304us exception remains specific to the recorded
115200 8N1 bench tuple. Host9600 8N1 mismatch recomputes character/framing budgets;
it neither changes the motor tuple nor inherits the304us exception.

## Coverage and verification

| Requirement / failure scenario | Actual production path | Native/build evidence | Physical evidence | Remaining proof |
| --- | --- | --- | --- | --- |
| Command, unit, prerequisite and result parity | Both compile `ProbeApp`, `ProbeConsole`, owner, codecs and operations |68/68 CTest suites; same move/control tests now compiled against both USB adapters | Matched quick/state/control/settings/finite move/stop scenarios PASS | Other unresolved native families retain their owning-prompt gaps |
| Capture qualification before writes | Same GPTimer adapter and runner physical TX/closure contract | Runner/UART/capture/service tests retain unchanged interval bounds | Each image first passes quick plus10 loaded7-byte and10 loaded37-byte replies | Electrical wire timing unmeasured; `timing_qualified:false` preserved |
| Delayed service and console pressure | Existing load fixture and bounded owner service | Existing delayed-capture and USB backpressure tests | CPU work2000us/10ms, active owner delay5000us, console128bytes/10ms; both widths PASS | Short campaigns, not endurance or arbitrary-load qualification |
| Finite motion and stops | Public relative preparation, checked staging/trigger, urgent action owner | Shared move tests cover faults, stale readiness, cancellation, uncertain TX/trigger, reservation and stop preemption |100 native increments at60RPM; normal/direct stop during separate250-increment moves, configured ramps; PASS | No continuous velocity, negative encoding, calibrated acceleration or independent shaft/stop measurement |
| Native setting and cleanup | Typed control read/update with readback, effect invalidation | Same control scenarios on both frameworks | Lock delay200→201→200, current/control snapshots unchanged afterward; PASS | Physical torque/lock effects unmeasured; no gain/current/feedback-mode perturbation |
| Init and PSRAM failure | Actual `beginApplication` and native `app_main` failure paths | Labelled SDK injection: allocation/USB/UART/timer/task/load failure, no large internal fallback/no motor TX | Normal initialization and measured memory PASS | Real missing-PSRAM board not available; no hardware allocation-failure claim |
| Console stop with blocked output | Ordinary console `stop direct`, same service loop | New shared test: nine cached commands fill output, USB capacity0; stop admitted, TX settles, interrupted move/observed stop retained; exactly one terminal each after drain | Loaded read-only console pressure measured; physical stops use unloaded finite envelope | Full USB disconnect during moving autonomous operation NOT RUN |
| Transport fault and explicit repair | Host tuple selection, retained probe failure, recovery queue policy, host restore | Existing runner/host/recovery tests; both adapter operation variants | Stopped host9600 mismatch, interlock and explicit recovery/restore/fresh read PASS | Intermittent malformed mismatch traffic's physical source unresolved |
| Core/application portability | Installed package and small S2 compile fixture | Desktop installed test PASS; two clean S2 consumers PASS | S3 only | No S2 hardware/wiring/transceiver, no other SDK/platform qualification |
| Ending state | Fresh identity/config/state and passive driver/load diagnostics | Harness refuses unknown cleanup or uncertain write replay | Both endings stopped/restored; final COM13 Arduino, load/monitor/debug off, DE released, no pending/results/recovery | No independent physical standstill instrument |

Focused desktop checks and required generators also pass:233 Python probe cases,
generator tests, version check,221 generated descriptors/242 words and contrast
snapshot check. Test-only parity adds no second workflow or framework types to
public APIs. `test/installed_consumer` now explicitly includes all27 headers.
`test/portability_consumer` links four real portable sources, caller-owned fixed
storage and an unavailable port, never the S3 UART adapter. Its `app_main` was
compiled, not executed on an S2 board. Its README records reproducible commands.

## Matched observations

These are actual campaign-window samples, not future service guarantees.

| Measurement | Arduino S3 | Native IDF S3 |
| --- | --- | --- |
| Unloaded10 probe latency, min/max/mean us |5482/5690/5536.9 |5525/5746/5584.4 |
| Loaded7-byte latency, min/max/mean us |14830/17607/16522.2 |14107/17701/16005.1 |
| Loaded37-byte latency, min/max/mean us |16723/20225/19027.2 |16557/20284/19149.5 |
| Loaded7/37 owner gap maximum us |8034/8036 |8035/8054 |
| Loaded7/37 capture gap maximum us |55/56 |52/59 |
| Sample gap limit / overflow disposition |85us, no breach |85us, no breach |
| Capture high water7/37 |7/37 of64 bytes |7/37 of64 bytes |
| Loaded7/37 work iterations |394/403 |396/417 |
| Loaded7/37 measured work us |788484/806674 |792975/835657 |
| Loaded7/37 complete diagnostic lines / dropped |348/46;352/51 |342/54;362/54 |
| Input command lines dropped |0 |0 |
| Loaded7/37 core1 task busy sample |34%/33% |35%/34% |
| Loaded7/37 separately measured capture time / elapsed |20.00%/19.97% |24.04%/24.05% |
| Final internal free / minimum / largest bytes |336624/331464/278516 |369335/332848/270336 |
| Final PSRAM free / minimum / largest bytes |8177196/8177196/8126452 |8177408/8177408/8126464 |
| Owner / worker stack headroom bytes |2004/3268 |2292/3272 |

CPU task-runtime samples omit ISR accounting; the separate capture fraction is
measured ISR/callback cost and must not be substituted for total CPU utilization.
Native USB is the SDK's all-or-zero64-byte zero-tick write with1024/256-byte
TX/RX rings and one-byte input lookahead. Arduino uses available writable space
and may return partial writes. Shared output queues retain the suffix and shared
command correlation/result storage does not depend on diagnostic display.
Dropped load lines and overwritten optional traces remain visible; they are not
lost protocol bytes. Console framing/correlation was never relaxed.

Both images have `sizeof(App)=206528` PSRAM bytes, internal UART1720 and load4816.
Native has static internal8192-byte owner stack/352-byte TCB; Arduino creates
its8192-byte loop stack dynamically through SDK internal allocation. The worker
stack4096 is explicitly internal on both. Arduino permits externally supplied
task stacks in SDK configuration; its normal dynamic stack uses INTERNAL|8BIT.
Native disables that option. Neither imports this memory policy into the core.
ELF/map/config evidence is retained. Headroom and heap readings are short-case
observations, not a leak-free/endurance claim.
The Arduino archive contains the effective `esp32s3/qio_opi/include/sdkconfig.h`,
SDK versions and selected build/board settings, rather than the SDK's generic
S3 configuration template. Native configuration remains its generated sdkconfig.

Forward100 changes reported raw position by100 on both. Normal/direct stopping
produces reported raw deltas180/131 on Arduino and226/171 on IDF. Stop requests
follow host receipt of fresh RUNNING evidence; scheduling/USB observation time
changes where the stop is requested. Both retain the interrupted uncertain move,
separate observed stop, new zero speed/no running/alarm and exact profile restore.
These are not calibrated stopping distances or proof of a physical adapter
defect. Final raw position is2870 on Arduino and2457 at the IDF ending; counters
were not cleared. Absolute/angle/return fixture cases remain NOT RUN because the
fresh raw position is outside their existing0..250 fixture window. No origin or
feedback scale was silently manufactured to admit them.

## Retained failure and honest traffic accounting

The original IDF `host-check --baud9600 --fmt8N1` FAIL is preserved: one malformed
byte`F9`, transport LENGTH, codec NOT_CHECKED, eight accepted request bytes,
execution unknown. The strict NO_RESPONSE-only scenario sent no recovery and
could not restore while the transport interlock held. This repeats the known
prompt19 mismatch disposition, not an ordinary working-tuple failure. Its
physical source cannot be determined from software traffic alone.

`idf-fault-repair` records a separately explicit recovery, host restoration and
new checked reads. The subsequent predeclared stopped read-only mismatch case
accepts only NO_RESPONSE or LENGTH as distinct negative evidence, proves that
host restore is blocked before explicit recovery, restores115200 8N1 and checks
new identity/config/state. Both images returned NO_RESPONSE on that repeated
case. It did not reproduce or fix`F9`; the original failed attempt remains FAIL.
No motor write, moving link-loss experiment, hidden recovery or replay occurred.

Actual counter differences plus the final snapshot's nine explicit read steps
give IDF481 transactions/479 FRAME/5184 RX bytes, and Arduino470/469/5083. The
two IDF failures are the original LENGTH and deliberate NO_RESPONSE; Arduino's
one failure is deliberate NO_RESPONSE. Capture faults/RX errors/sample-gap
breaches are zero. Deduplicated retained raw evidence covers460/451 transactions
and4995/4912 RX bytes respectively, including the failed traffic. Intermediate
internal polls need not survive in a context; the raw subset is not presented as
an exhaustive wire recording. Historical profile inspections and pending
prepared requests are excluded. Raw successful retained replies have valid CRC;
`F9` is retained as malformed. Counter samples precede final typed reads; the
summary explicitly accounts for those nine requests/97 RX bytes.

## Review, artifacts and handoff

Cross-platform semantic and SDK/memory reviewers independently inspected actual
code, ELF/configuration and raw evidence. They confirmed matched effective
targets/restoration and corrected an interim repeated-F9 claim, raw counting
of historical/unsent contexts and archival of a generic Arduino SDK template
instead of its effective qio_opi header. Root verified corrections against records.
The new pressure test initially asserted cancellation in the admission turn;
the real loop advances actions before servicing input. The test now waits bounded
cooperative turns for settlement, retaining all stop/no-replay assertions. Both
adapter variants and all68 suites pass; no production workaround was needed.

Current FieldCore source at`d19758865852f4e215ea05c6572d060edc4f0c66` was inspected
read-only (`Rs485OwnerTransaction`, `Rs485Task`, `SerialCli`). Compatible concepts
are one owner, deadlines, supplied transactions and bounded64-byte USB writes.
Deliberate differences remain: standalone retained/non-consuming results,
explicit unknown motor writes/recovery, richer framing evidence,32-byte TX
storage and checked FC06/FC10 policy; FieldCore's8-byte sensor transaction and
measurement/retry conventions are not imported. FieldCore was not modified.

[Structured evidence](ess_release_26_2026-10-05.json) and
[archive](ess_release_26_2026-10-05_evidence.zip) retain every campaign, failed
attempt, exact scripts/inputs, incremental raw/structured lines, image hashes,
SDK configuration, resource/map evidence, build/test logs and manifest. Original
whole-flash backups described in25 remain preserved locally; rollback not tested.

COM13 ends on the Arduino hash above, node1/115200 8N1, load0/0/0, debug and
monitor off, DE released, owner/results empty, no recovery, enabled/no alarm,
fresh zero speed/no running. Motion profile`[30,100,100,60,0,250]` and lock delay200
are restored. Model/version remain raw`4EEA/0029`, algorithm3/configured encoder4000;
physical feedback mapping remains unresolved. External switches/loads, homing,
external segments, linear mechanics, continuous velocity, persistence/restart,
other tuples/platforms, electrical/independent shaft evidence and endurance stay
unqualified. Prompt27 inherits these platform scopes, ordinary shared scenarios,
the real build recipes and the existing complete coverage denominator.
