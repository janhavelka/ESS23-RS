import json, pathlib, hashlib
base=pathlib.Path('build/p26')
result={'baseline_commit':'77ee61dfde3f9f349cee93f072bd8431050f2d23','platforms':{}}
def crc(data):
    v=0xffff
    for byte in data:
        v ^= byte
        for _ in range(8): v=(v>>1)^0xa001 if v&1 else v>>1
    return v
def walk(item,path=''):
    if isinstance(item,dict):
        tx=item.get('tx',item.get('tx_hex')); rx=item.get('rx',item.get('rx_hex'))
        if isinstance(tx,str) and isinstance(rx,str) and tx and item.get('tx_accepted',item.get('tx_bytes',0)):
            earliest=item.get('earliest_us',item.get('observed_earliest_us',item.get('closure_earliest_us',0)))
            latest=item.get('latest_us',item.get('observed_latest_us',item.get('closure_latest_us',0)))
            yield tx,len(bytes.fromhex(tx)),rx,earliest,latest,item.get('tx_end_us',0)
        elif isinstance(item.get('raw_hex'),str) and item.get('tx_accepted',0):
            yield None,item['tx_accepted'],item['raw_hex'],item.get('earliest_us',0),item.get('latest_us',0),0
        if item.get('write_tx_hex'):
            yield item['write_tx_hex'],item['write_tx_accepted'],item['write_reply_hex'],item['write_closure_earliest_us'],item['write_closure_latest_us'],0
        # Native parameter sequences report a compact evidence table.
        if 'evidence_columns' in item:
            for row in item['evidence']:
                evidence=dict(zip(item['evidence_columns'],row))
                yield from walk(evidence,path+'/'+str(evidence.get('step')))
        for key,value in item.items():
            if key!='evidence': yield from walk(value,path+'/'+key)
    elif isinstance(item,list):
        for i,value in enumerate(item): yield from walk(value,path+'/'+str(i))
for platform,image in [('idf',pathlib.Path('build/p25/idf-final/motorcontrol_probe.bin')),
                        ('arduino',base/'arduino-image/firmware.bin')]:
    last=json.loads((base/f'{platform}-final.json').read_text())
    out={'image_sha256':hashlib.sha256(image.read_bytes()).hexdigest(),'image_bytes':image.stat().st_size,
         'final':last['after'],'campaigns':{},'frames':0,'tx_bytes':0,'rx_bytes':0,'bad_rx_crc':0,
         'transport_failures':[]}
    for file in sorted(base.glob(platform+'-*.json')):
        data=json.loads(file.read_text()); out['campaigns'][file.stem]={'ok':data['ok']}
        for key in ('window','campaigns','negative'):
            if key in data: out['campaigns'][file.stem][key]=data[key]
        if 'motion' in data:
            motion=data['motion']
            out['campaigns'][file.stem]['motion']={k:motion[k] for k in
              ('move','state_before','state_after','cleanup','restoration') if k in motion}
        if 'setting' in data: out['campaigns'][file.stem]['setting']=data['setting']
    seen=set() # Retained profile evidence can be inspected across later sessions.
    for file in sorted(base.glob(platform+'-*.jsonl')):
        for line in file.open(encoding='utf-8'):
            event=json.loads(line)
            if event['event']!='reply': continue
            reply=event['response']
            for tx,txCount,rx,earliest,latest,txEnd in walk(reply):
                key=(earliest,latest,rx,txEnd if not earliest else 0)
                if key in seen: continue
                seen.add(key)
                rawRx=bytes.fromhex(rx)
                if tx: assert crc(bytes.fromhex(tx))==0,(file,tx)
                out['frames']+=1; out['tx_bytes']+=txCount; out['rx_bytes']+=len(rawRx)
                if rawRx and crc(rawRx): out['bad_rx_crc']+=1
            if reply['type']!='reply' and reply.get('ok') is False and reply.get('transport') not in (None,'FRAME','RECOVERED'):
                out['transport_failures'].append({'file':file.name,'terminal':reply})
    before=json.loads((base/f'{platform}-quick.json').read_text())['before']['stats']
    after=out['final']['stats']
    # Fixed final snapshot reads identity(1), config(5), state(3) after stats.
    out['counter_delta']={'attempted':after['started']+9-before['started'],
        'frames':after['frames']+9-before['frames'],'failed':after['failed']-before['failed'],
        'rx_bytes':after['rx_bytes']+97-before['rx_bytes'],
        'provenance':'actual counter difference plus nine final explicit read steps (97 RX bytes); no resets'}
    out['raw_provenance']='deduplicated retained raw evidence subset; intermediate internal polls need not be retained'
    result['platforms'][platform]=out
(base/'measurements.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
for platform,out in result['platforms'].items():
    last=out['final']
    print(platform,'frames',out['frames'],'tx/rx',out['tx_bytes'],out['rx_bytes'],'crc_bad',out['bad_rx_crc'],
          'memory',last['memory'],'rawstate',last['state']['state_blocks'])
    for name,value in out['campaigns'].items():
        if 'window' in value: print(name,value['window'],value['campaigns'][0]['latency_us'])
