import sys
sys.path.insert(0, 'scripts')
from bench_session import run_recorded, checked
from bench_probe import BenchError
platform, image, phase = sys.argv[1:]
def run(console, record):
    if phase == 'mismatch':
        checked(console, 'probe', address=1)
        record['selected'] = checked(console, 'host', host_args=('set','9600','8N1'))
        bad = console.command('probe', address=1)
        record['negative'] = bad
        if (bad['ok'] or bad.get('transport') not in ('NO_RESPONSE','LENGTH')
                or bad.get('codec') != 'NOT_CHECKED' or bad.get('tx_bytes') != 8):
            raise BenchError('unexpected host mismatch outcome; no implicit recovery')
        # An explicit read-only fault experiment: no write, replay or moving drive.
        record['interlock'] = console.command('host', host_args=('restore',))
        if record['interlock']['ok'] or record['interlock']['result'] != 'recovery_required':
            raise BenchError('fault did not preserve recovery interlock')
    record['recovery'] = checked(console, 'recover')
    record['restored'] = checked(console, 'host', host_args=('restore',))
    record['probe_after'] = checked(console, 'probe', address=1)
    checked(console, 'read-identity', address=1)
    checked(console, 'read-config', address=1)
    record['state_after'] = checked(console, 'read-state', address=1)
    record['workload_verified'] = True
run_recorded(port='COM13', out=f'build/p26/{platform}-fault-{phase}',
             scenario='explicit-read-only-fault-recovery', inputs={'phase':phase,'mismatch':'9600 8N1',
             'accepted_faults':['NO_RESPONSE','LENGTH'],'recovery':'explicit; stopped read-only experiment'},
             run=run, firmware=image, refresh=False)
