from pathlib import Path
import json,hashlib,zipfile,sys
base=Path('build/p26'); reports=Path('docs/reports')
record=json.loads((base/'measurements.json').read_text())
record.update(prompt=26,final_revision='commit containing this report',implementation='PASS available subset',
    qualification='functional drive-report acceptance; electrical/independent shaft evidence unmeasured',
    verification={'ctest_suites':68,'ctest':'PASS','python_probe_cases':233,'generators':'PASS',
      'arduino_builds':['bench_s3_probe','bench_s3_load_poll','bench_s3_load_timer'],
      'desktop_installed_all_27_headers':'PASS','s2_core':'compile/link PASS; no hardware',
      's2_portable':'compile/link PASS; no S3 UART; no hardware',
      'psram_init_failure':'labelled SDK fake injection; no real missing-PSRAM board',
      'console_pressure_stop':'same actual-console fake scenario on both platform adapters PASS'},
    motor={'model':'user-identified ESS23-RS20','raw_model':'4EEA','raw_version':'0029',
       'wiring':'power+RS485 only; external inputs/outputs unconnected; free secured shaft'},
    ending={'platform':'Arduino ESP32-S3 timer','tuple':'node1/115200 8N1','load':[0,0,0],
       'debug':'off','monitor':'off','standstill':'fresh drive reports speed0/runningfalse/alarm0',
       'profile':[30,100,100,60,0,250],'lock_delay':200,'raw_position':2870},
    retained_failure={'file':'idf-host-fault.jsonl','outcome':'FAIL; LENGTH/F9, interlocked restoration failed',
       'source':'unresolved intermittent host-baud-mismatch traffic',
       'repair':'separate explicit idf-fault-repair; subsequent mismatch yielded NO_RESPONSE, not F9',
       'automatic_replay':False},
    remaining=['S2 hardware/adapter','other SDK/platform','external switches/output loads/homing/segments',
       'linear mechanism','continuous velocity and negative encoding','restart/persistence',
       'independent shaft/electrical timing','endurance','owning-prompt unresolved native-family gaps'],
    backup={'full_flash':'build/p25/original-image/flash-16mb-v4.bin',
       'sha256':'09b0700e6b4f392e9bc3dbf4d935029cdacd0d2fe3d96d2be1613614680ea408',
       'preserved':'local; whole-flash rollback NOT RUN'})
reportJson=reports/'ess_release_26_2026-10-05.json'
reportJson.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
files={p:p.relative_to(base).as_posix() for p in base.iterdir() if p.is_file()}
for folder in ('arduino-image',):
    for p in (base/folder).iterdir():
        if p.is_file(): files[p]=p.relative_to(base).as_posix()
for name in ('motorcontrol_probe.bin','motorcontrol_probe.elf','motorcontrol_probe.map','project_description.json','flasher_args.json'):
    p=Path('build/p25/idf-final')/name; files[p]='idf-image/'+name
for name,path in [('sdkconfig',Path('examples/probe_idf/sdkconfig')),
                  ('bootloader.bin',Path('build/p25/idf-final/bootloader/bootloader.bin')),
                  ('partitions.bin',Path('build/p25/idf-final/partition_table/partition-table.bin'))]:
    files[path]='idf-image/'+name
for folder,binary in [('s2-core','motorcontrol_core_consumer.bin'),('s2-portable','motorcontrol_portable_consumer.bin')]:
    for name in (binary,'compile_commands.json','project_description.json'):
        p=base/folder/name; files[p]=folder+'/'+name
    p=base/(folder+'.sdkconfig'); files[p]=folder+'/sdkconfig'
files[Path('build/p26/installed-consumer/compile_commands.json')]='installed-consumer/compile_commands.json'
files[Path('C:/pio/packages/framework-arduinoespressif32-libs/esp32s3/qio_opi/include/sdkconfig.h')]='arduino-image/qio_opi/sdkconfig.h'
files[Path('C:/pio/packages/framework-arduinoespressif32-libs/versions.txt')]='arduino-image/versions.txt'
files[Path('C:/pio/packages/framework-arduinoespressif32/package.json')]='arduino-image/framework-package.json'
files[Path('platformio.ini')]='arduino-image/platformio.ini'
files[Path('boards/bench_s3_n16r8.json')]='arduino-image/board.json'
files[Path('build/p25/idf-tools/espidf.constraints.v5.5.txt')]='tools/espidf.constraints.v5.5.txt'
files[reports/'ess_release_26_2026-10-05.md']='report.md';files[reportJson]='report.json'
manifest=[]
archive=reports/'ess_release_26_2026-10-05_evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as output:
    for path,name in sorted(files.items(),key=lambda pair:pair[1]):
        data=path.read_bytes();output.writestr(name,data)
        manifest.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
    output.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None
    for item in manifest:
        assert hashlib.sha256(check.read(item['path'])).hexdigest()==item['sha256']
print('Archive verified:',len(manifest),'files;',archive.stat().st_size,'bytes')
