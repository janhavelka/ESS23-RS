import sys,time,json
from pathlib import Path
sys.path.insert(0,'scripts')
from bench_session import run_recorded,checked
from bench_probe import observe_stopped

def run(c,r):
 r['stopped']=observe_stopped(c,address=1,timeout_s=5)
 end=time.monotonic()+1800
 r['queries']=0
 while time.monotonic()<end and r['queries']<100000:
  r['last']=checked(c,('stats','version','host','config')[r['queries']%4])
  r['queries']+=1
  if r['queries']%1000==0: print(r['queries'],flush=True)
 assert r['queries']==100000
 r['workload_verified']=True
run_recorded(port='COM13',out=Path('build/usb_motion_fix/after_stress'),scenario='reset-board-local-usb-stress',inputs={'seconds':1800,'max_queries':100000,'motor_writes':0},run=run,refresh=False,max_records=500000,max_bytes=256*1024*1024)
