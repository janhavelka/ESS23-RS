import sys,json,time,faulthandler
from pathlib import Path
sys.path.insert(0,'scripts')
from bench_session import run_recorded,checked
from bench_probe import open_port
import serial.win32 as win32

prior=Path('build/usb_motion_fix/after_stress.json')
assert json.loads(prior.read_text())['ok']
idle=time.time()-prior.stat().st_mtime
assert idle>=180, idle
def run(c,r):
    for command in ('stats','version','host','config'):
        r[command]=checked(c,command)
    r['workload_verified']=True

def instrumented_port(*args):
    port=open_port(*args)
    original_close=port.close
    def close():
        if not port.is_open:
            return original_close()
        originals={name:getattr(win32,name) for name in ('SetCommTimeouts','GetOverlappedResult','CancelIoEx','CloseHandle')}
        def traced(name,fn):
            def call(*args):
                start=time.monotonic()
                print('close enter',name,flush=True)
                result=fn(*args)
                print('close exit',name,time.monotonic()-start,result,flush=True)
                return result
            return call
        for name,fn in originals.items():setattr(win32,name,traced(name,fn))
        faulthandler.dump_traceback_later(10,repeat=True)
        try:return original_close()
        finally:
            faulthandler.cancel_dump_traceback_later()
            for name,fn in originals.items():setattr(win32,name,fn)
    port.close=close
    return port

run_recorded(port='COM13',out=Path('build/usb_motion_fix/reopen'),scenario='explicit-port-reopen-after-idle',inputs={'idle_seconds':idle,'controller_reset':False,'motor_writes':0},run=run,refresh=False,port_opener=instrumented_port,firmware=Path('build/usb_motion_fix/pio/bench_s3_load_timer/firmware.bin'))
