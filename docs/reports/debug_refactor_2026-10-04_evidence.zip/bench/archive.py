import hashlib,json,pathlib,subprocess,zipfile
root=pathlib.Path.cwd(); bench=root/'build/bench/debug_refactor'; dest=root/'docs/reports'
changed=subprocess.check_output(['git','diff','HEAD','--name-only'],text=True,stderr=subprocess.DEVNULL).splitlines()
new=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
entries={}
for p in sorted(bench.rglob('*')):
 if p.is_file() and '__pycache__' not in p.parts:entries['bench/'+p.relative_to(bench).as_posix()]=p.read_bytes()
for p in (root/'build/debug_consumer_src').iterdir():
 if p.is_file():entries['installed_consumer/'+p.name]=p.read_bytes()
for name in sorted(set(changed+new)):
 p=root/name
 if p.is_file() and not name.endswith('.zip'):entries['source/'+name]=p.read_bytes()
entries['working.diff']=subprocess.check_output(['git','diff','HEAD','--no-ext-diff'],stderr=subprocess.DEVNULL)
manifest={k:dict(bytes=len(v),sha256=hashlib.sha256(v).hexdigest()) for k,v in entries.items()}
with zipfile.ZipFile(dest/'debug_refactor_2026-10-04_evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for k,v in entries.items():z.writestr(k,v)
 z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(dest/'debug_refactor_2026-10-04_evidence.zip') as z:
 assert all(hashlib.sha256(z.read(k)).hexdigest()==v['sha256'] for k,v in manifest.items())
print(len(entries),'artifacts archived and verified')
