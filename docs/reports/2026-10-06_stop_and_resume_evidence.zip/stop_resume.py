import json, re, sys, time
from pathlib import Path
sys.path.insert(0, 'scripts')
from bench_session import run_recorded, checked
from bench_probe import BenchError, observe_stopped, FAULT_TEXT
from bench_motion import profile_snapshot, restore_profile

def send(c, text):
    assert not c.pending and not c.buffer
    c.emit('human_command', text=text)
    c.port.write((text+'\n').encode())

def receive(c, predicate, timeout=12):
    deadline=time.monotonic()+timeout; raw=bytearray(); quiet=deadline
    while time.monotonic()<deadline:
        part=c.port.read(4096)
        if part: raw.extend(part); quiet=time.monotonic()+.05
        text=raw.decode('utf-8')
        if len(raw)>32768 or FAULT_TEXT.search(text):
            c.synchronized=False
            raise BenchError('fault or excessive output during human command')
        if predicate(text) and time.monotonic()>=quiet:
            c.emit('human_output',text=text); print(text,flush=True); return text
        time.sleep(.005)
    c.synchronized=False
    c.emit('human_incomplete',text=raw.decode('utf-8',errors='replace'))
    raise BenchError('human command timeout; no replay')

def motion(c, text):
    send(c,text)
    out=receive(c,lambda s:'Details:' in s)
    assert 'Move complete' in out, out
    return out

def run(c,r):
    r['config']=checked(c,'read-config',address=1)
    r['baseline']=observe_stopped(c,address=1,timeout_s=5)
    r['profile']=profile_snapshot(c,timeout_s=5)
    try:
        for text in ('speed 60 rpm','accel 100 ms','decel 100 ms'):
            send(c,text); receive(c,lambda s:'Use settings' in s)
        r['outward']=motion(c,'moveby 180 deg')
        send(c,'moveto 0 deg')
        time.sleep(.20)
        send(c,'stop fast')
        out=receive(c,lambda s:'Stop complete' in s and s.count('Details:')>=2)
        assert 'Move uncertain' in out or 'Move interrupted' in out,out
        r['interrupted']=out
        child=int(re.search(r'Details: @1 result (\d+)',out).group(1))
        r['old_result']=c.command('result',operation_id=child)
        assert r['old_result']['uncertain']
        r['stopped']=observe_stopped(c,address=1,timeout_s=5)
        r['resumed']=motion(c,'moveto 0 deg')
        r['old_result_after']=c.command('result',operation_id=child)
        for key in ('operation_id','outcome','execution','completion','uncertain'):
            assert r['old_result'][key]==r['old_result_after'][key]
        r['release_old']=checked(c,'release',operation_id=child)
        r['repeated_stops']=[]
        for text in ('stop fast','stop normal','stop fast'):
            send(c,text); out=receive(c,lambda s:'Details:' in s)
            assert 'Stop complete' in out,out
            r['repeated_stops'].append(out)
        r['next_move']=motion(c,'moveby 90 deg')
        r['return']=motion(c,'moveto 0 deg')
        r['final_position']=observe_stopped(c,address=1,timeout_s=5)
        assert abs(r['baseline']['state_blocks'][2]['raw_position']-r['final_position']['state_blocks'][2]['raw_position'])<=1
        r['workload_verified']=True
    finally:
        if c.synchronized:
            r['cleanup_stop']=checked(c,'stop',address=1,stop_policy='normal')
            r['cleanup_state']=observe_stopped(c,address=1,timeout_s=5)
            r['restored']=restore_profile(c,timeout_s=5)
        else:
            r['cleanup']='unknown: framing lost; no replay'

run_recorded(port='COM13',out=Path(sys.argv[1]),scenario='human-move-stop-resume',
    inputs={'moves_deg':[180,'interrupted_return',0,90,0],'speed_rpm':60,'ramps_ms':100,
            'stop_after_s':.20,'repeated_stops':['fast','normal','fast']},run=run,refresh=False,
    firmware=Path('build/ownership_fix/pio/bench_s3_load_timer/firmware.bin'))

