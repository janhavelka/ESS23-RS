import json,sys
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,str(Path('scripts').resolve()))
import bench_probe as probe
from bench_session import checked,run_recorded
from bench_scenarios import _setting
plan={'reproduce':'one control lock-delay201 admission with stale identity; require zero operation ID and unchanged owner TX count',
      'correction':'explicit fresh identity/config, one lock-delay201 with readback; distinct saved200 restore',
      'cleanup':'fresh stopped feedback and10probes; load/debug original; no motion'}
Path('build/p29/evidence/arduino-setting-recheck-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
def run(c,r):
    checked(c,'control',driver_args=('read',),address=1)
    probe.observe_stopped(c,address=1,timeout_s=5)
    before=checked(c,'stats')
    refusal=c.command('control',driver_args=('set','lock-delay','201'),address=1)
    after=checked(c,'stats')
    r['reproduced_refusal']=refusal; r['refusal_stats']=[before,after]
    if refusal['ok'] or refusal.get('result')!='invalid' or refusal.get('operation_id')!=0 or before['started']!=after['started']:
        raise probe.BenchError('stale identity did not reject without TX')
    r['fresh_identity']=checked(c,'read-identity',address=1)
    r['fresh_config']=checked(c,'read-config',address=1)
    _setting(c,SimpleNamespace(setting='lock-delay',value=201,address=1,timeout=5),r)
    if not r['setting']['restored']: raise probe.BenchError('restore incomplete')
    r['final_state']=probe.observe_stopped(c,address=1,timeout_s=5)
    probe.campaign(c,'stress',count=10,interval_s=.05,timeout_s=5,address=1)
    r['workload_verified']=True
run_recorded(port='COM13',out=Path('build/p29/evidence/arduino-setting-recheck'),scenario='stale identity refusal reproduction and explicit prerequisite correction',inputs=plan,
    run=run,address=1,timeout_s=5,debug='decoded',firmware=Path('build/p28/pio/bench_s3_load_timer/firmware.bin'),refresh=False)
print('PASS refusal reproduction, fresh prerequisite and checked settings restore')
