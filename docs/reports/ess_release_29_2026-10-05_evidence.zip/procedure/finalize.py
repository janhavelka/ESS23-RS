import json,hashlib,zipfile
from pathlib import Path
root=Path('build/p29/evidence')
r=json.loads(Path('build/p29/measurements.json').read_text())
r['disposition']='Available finite qualification complete; original Arduino aggregate FAIL retained, scoped stages and corrected settings PASS; native IDF aggregate PASS; deferred/missing qualification open.'
r['arduino_setting_recheck']=json.loads((root/'arduino-setting-recheck.json').read_text())
r['restored_quick']=json.loads((root/'arduino-restored-quick.json').read_text())
r['final_cached']=json.loads((root/'arduino-restored-cached.json').read_text())
r['verifier']=json.loads(Path('build/p29/verify/summary.json').read_text())
total=sum(p['frame_delta'] for p in r['platforms'].values())+r['final_cached']['stats']['frames']
r['total_checked_frames']=total
r['expected_zero_tx_faults']=2
table=['| Image / read | Work/owner delay/console | Window seconds | Min / p50 / p95 / p99 / max (us) | Owner / capture gap max (us) | Capture section (%) |',
       '| --- | --- | --- | --- | --- | --- |']
for name,p in r['platforms'].items():
    for w in p['windows']:
        l=w['latency_us']
        table.append('| '+name+' / '+w['command']+' | '+' / '.join(map(str,w['load']))+' | '+str(w['duration_s'])+' | '+' / '.join(str(l[k]) for k in ('min','p50','p95','p99','max'))+' | '+str(w['owner_gap_us'])+' / '+str(w['capture_gap_us'])+' | '+str(w['capture_pct'])+' |')
text='Each row contains100 successful reads; percentiles use nearest rank over the\n100 firmware durations, not host command/release time. All1,200 planned load\nreads passed.\n\n'+'\n'.join(table)
text+='\n\n| Resource / outcome | Arduino S3 | Native IDF S3 |\n| --- | --- | --- |\n'
def row(label,a,b): return f'| {label} | {a} | {b} |\n'
a,b=r['platforms']['arduino'],r['platforms']['idf']
text+=row('Aggregate duration/status','392.500s / FAIL at final prerequisite refusal','403.375s / PASS')
text+=row('Additional Arduino corrected settings run',f"{r['arduino_setting_recheck']['elapsed_s']:.3f}s / PASS",'Included fresh prerequisites')
text+=row('Checked frame delta (includes baseline/final reads)',a['frame_delta'],b['frame_delta'])
text+=row('Expected zero-TX fault / unexpected transport failures','1 / 0','1 / 0')
for label,key in [('Warmed internal free (bytes)','internal_free'),('Warmed PSRAM free (bytes)','psram_free')]:
    text+=row(label,a['windows'][0][key],b['windows'][0][key])
text+=row('Six-window internal / PSRAM median decline (bytes)','0 / 0','0 / 0')
text+=row('Final internal free / minimum / largest (bytes)',*[f"{p['final_memory']['internal_free']} / {p['final_memory']['internal_min']} / {p['final_memory']['internal_largest']}" for p in (a,b)])
text+=row('Final PSRAM free / minimum / largest (bytes)',*[f"{p['final_memory']['psram_free']} / {p['final_memory']['psram_min']} / {p['final_memory']['psram_largest']}" for p in (a,b)])
text+=row('Owner stack minimum after features / worker stack (bytes)',*[f"{p['final_memory']['stack_free_bytes']} / {p['final_load']['work_stack_free_bytes']}" for p in (a,b)])
text+=row('Scheduler CPU0; CPU1 across six windows (%)',*[str([w['cpu0_scheduler_pct'] for w in p['windows']])+'; '+str([w['cpu1_scheduler_pct'] for w in p['windows']]) for p in (a,b)])
text+=row('Dropped passive display records / capture drops',*[str(p['debug_drop_delta'])+' / '+str(p['debug_capture_dropped']) for p in (a,b)])
text+=row('Normal / direct stop observation interval (us)',*[str(p['stops'][0]['firmware_observation_us'])+' / '+str(p['stops'][1]['firmware_observation_us']) for p in (a,b)])
text+='\nArduino frame delta includes the original failed aggregate and46-frame\nreproduction/correction; its baseline already contained107 historical frames,\nwhich are subtracted. The final restored-image regression adds33 checked frames\nwith zero failures, giving**'+str(total)+' current-block checked frames** plus the two\nexpected zero-TX deadline failures. No counter reset hides those faults: each\npre-flash snapshot preserves them; firmware upload starts a new counter epoch.\n\n'
text+='Both moving-stop operations preserve `cancelled` interrupted moves with\n`not_observed` move completion and distinct acknowledged/observed stop results.\nTheir118.770/28.460ms (Arduino) and118.683/28.758ms (IDF) intervals measure\nfirmware operation start to checked completion, not physical shaft latency.\nThe two ordinary100-increment commands report raw deltas101/100 on Arduino\nand100/100 on IDF; no scale, target or tolerance was altered. Release/enable\non IDF changes raw feedback4271→4279 without a position command. These\nobservations leave calibrated position/shaft behavior unresolved.\n\n'
text+='Final restored Arduino image is the exact SHA above. Fresh typed readback\nreports raw position4881, alarm0, enabled/non-running and speed0. Profile\n`[30,100,100,60,0,250]` and lock delay200 were restored before flashing; motor\nconfiguration remains unchanged. Debug/load/monitor are off, DE released,\nowner/results empty and recovery not required. Cached-only follow-ups measure\nresources/counters; fresh stopped/position claims come from the typed campaign\nreads. The Arduino correction’s final position words are`[0,4271]`, but its\ninvalidated decoded-position placeholder is not treated as a position of zero.\n'
report=Path('docs/reports/ess_release_29_2026-10-05.md')
body=report.read_text(encoding='utf8'); assert '<!-- MEASUREMENTS -->' in body
report.write_text(body.replace('<!-- MEASUREMENTS -->',text),encoding='utf8')
Path('docs/reports/ess_release_29_2026-10-05.json').write_text(json.dumps(r,indent=2)+'\n')
print('Report measurements complete:',total,'frames')
