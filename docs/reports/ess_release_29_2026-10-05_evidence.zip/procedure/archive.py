import hashlib,json,zipfile
from pathlib import Path
files={}
def add(path,name=None):
    p=Path(path); assert p.is_file(),p
    files[name or p.as_posix()]=p
for p in Path('build/p29/evidence').iterdir():
    if p.is_file(): add(p,'evidence/'+p.name)
for p in Path('build/p29/verify').iterdir():
    if p.is_file() and p.suffix in ('.log','.json'): add(p,'verification/'+p.name)
for name in ('qualify.py','setting_recheck.py','cached.py','analyze.py','finalize.py','archive.py','measurements.json','repository-final.log'):
    add('build/p29/'+name,'procedure/'+name)
for path,name in (
    ('build/p28/pio/bench_s3_load_timer/firmware.bin','images/arduino.bin'),
    ('build/p28/pio/bench_s3_load_timer/bootloader.bin','images/arduino-bootloader.bin'),
    ('build/p28/pio/bench_s3_load_timer/partitions.bin','images/arduino-partitions.bin'),
    ('C:/pio/packages/framework-arduinoespressif32/tools/partitions/boot_app0.bin','images/arduino-boot-app0.bin'),
    ('build/p29/verify/idf-app/motorcontrol_probe.bin','images/idf.bin'),
    ('build/p29/verify/idf-app/bootloader/bootloader.bin','images/idf-bootloader.bin'),
    ('build/p29/verify/idf-app/partition_table/partition-table.bin','images/idf-partitions.bin'),
    ('build/p29/verify/idf-app/ota_data_initial.bin','images/idf-ota-data.bin'),
    ('build/p29/verify/idf-app/sdkconfig','configuration/idf-sdkconfig'),
    ('build/p29/verify/idf-app/flash_args','configuration/idf-flash-args'),
    ('build/p28/evidence/upload.log','provenance/arduino-original-upload.log'),
    ('platformio.ini','configuration/platformio.ini'),
    ('examples/common/BoardPins.h','configuration/BoardPins.h'),
    ('examples/common/BuildConfig.h','configuration/BuildConfig.h'),
    ('examples/probe_idf/sdkconfig.defaults','configuration/sdkconfig.defaults')):
    add(path,name)
manifest={'source_commit':'658beaad1709e2d42648cc606f859b36b4806e2f',
          'note':'Original Arduino aggregate FAIL retained. Separate corrected settings PASS; IDF aggregate PASS. Scripts are recorded finite procedures, not authorization for blind replay. Firmware source unchanged; baseline commits and hashes identify source/image.',
          'files':{name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for name,p in sorted(files.items())}}
target=Path('docs/reports/ess_release_29_2026-10-05_evidence.zip')
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in sorted(files.items()): z.write(p,name)
    z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    for name,row in manifest['files'].items(): assert hashlib.sha256(z.read(name)).hexdigest()==row['sha256'],name
print(target,len(files),'files',target.stat().st_size,'bytes',hashlib.sha256(target.read_bytes()).hexdigest())
