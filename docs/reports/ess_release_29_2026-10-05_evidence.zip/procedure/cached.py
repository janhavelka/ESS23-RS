import sys,json
from pathlib import Path
sys.path.insert(0,str(Path('scripts').resolve()))
from bench_probe import Console,Evidence,open_port
from bench_session import snapshot
prefix=Path('build/p29/evidence')/(sys.argv[1]+'-cached')
with prefix.with_suffix('.jsonl').open('x',encoding='utf8') as log:
    with open_port('COM13',115200,5) as port:
        c=Console(port,on_event=Evidence(log)); c.drain_startup(.5); c.identify()
        result=snapshot(c)
        prefix.with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
        assert not result['drv']['busy'] and not result['drv']['retained'] and not result['drv']['pending'] and not result['drv']['recovery_required']
        print(json.dumps({'stats':result['stats'],'memory':result['memory'],'load':result['load']}))
