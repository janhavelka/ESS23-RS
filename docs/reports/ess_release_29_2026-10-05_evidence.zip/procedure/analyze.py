import json,math,hashlib
from pathlib import Path
root=Path('build/p29/evidence')
out={'source_commit':'658beaad1709e2d42648cc606f859b36b4806e2f','platforms':{}}
def percentile(v,p): return sorted(v)[max(0,math.ceil(len(v)*p)-1)]
def position(blocks):
    if isinstance(blocks,dict): blocks=blocks['state_blocks']
    return next(b['raw_position'] for b in blocks if b['block']==2)
for platform in ('arduino','idf'):
    file=root/(platform+'.json')
    if not file.exists() or not file.stat().st_size: continue
    r=json.loads(file.read_text()); raw=[]; first=None; windows=[]; stops=[]; seen=set()
    traffic={}; bad=[]
    for line in (root/(platform+'.jsonl')).open():
        e=json.loads(line); event=e['event']; reply=e.get('response',{})
        if event=='iteration' and e.get('mode')=='load' and e['number']==1:
            raw=[]; seen=set(); first=e['elapsed_s']
        if first is not None and event=='reply' and reply.get('ok') and 'duration_us' in reply and reply.get('operation_id') not in seen:
            seen.add(reply['operation_id']); raw.append(reply['duration_us'])
        if event=='summary' and e.get('mode')=='load':
            assert len(raw)==100,(platform,len(raw))
            w=r['windows'][len(windows)]; l=w['load_snapshot']; m=w['memory']
            windows.append(dict(command=w['command'],load=w['load'],count=len(raw),duration_s=round(e['elapsed_s']-first,3),
                latency_us=dict(min=min(raw),p50=percentile(raw,.5),p95=percentile(raw,.95),p99=percentile(raw,.99),max=max(raw),mean=sum(raw)/len(raw)),
                capture_pct=round(100*l['capture_us']/l['elapsed_us'],3),capture_us=l['capture_us'],elapsed_us=l['elapsed_us'],samples=l['capture_samples'],callbacks=l['timer_callbacks'],
                capture_gap_us=l['capture_gap_max_us'],owner_gap_us=l['owner_gap_max_us'],cpu0_scheduler_pct=l['cpu0_busy_pct'],cpu1_scheduler_pct=l['cpu1_busy_pct'],
                console_lines=l['console_lines'],console_dropped=l['console_dropped'],internal_free=m['internal_free'],psram_free=m['psram_free'],owner_stack_free=m['stack_free_bytes'],worker_stack_free=l['work_stack_free_bytes']))
            first=None
        if event=='phase_command' and e['phase'].startswith('stop-') and e['command']=='stop':
            s=e['result']; stops.append(dict(phase=e['phase'],operation_id=s['operation_id'],firmware_observation_us=s['serviced_us']-s['started_us'],completion=s['completion'],execution=s['execution']))
        if event=='reply' and reply.get('ok') is False:
            bad.append({k:reply.get(k) for k in ('command','operation_id','result','outcome','transport','tx_bytes','execution_unknown')})
        if event=='traffic' and reply.get('kind')=='TX' and reply.get('complete'):
            frame=bytes.fromhex(reply['raw_hex']); key=f'{frame[1]:02X}/{len(frame)}'
            if frame[1] in (3,16): key+=f'/{int.from_bytes(frame[2:4],"big"):04X}/{int.from_bytes(frame[4:6],"big")}'
            traffic[key]=traffic.get(key,0)+1
    end=json.loads((root/(platform+'-cached.json')).read_text()) if (root/(platform+'-cached.json')).exists() else r.get('after',r.get('failure_diagnostics'))
    p=dict(ok=r['ok'],error=r.get('error'),elapsed_s=r['elapsed_s'],image=r['firmware_artifact'],windows=windows,stops=stops,
           memory_trend=r['memory_trend'],before_stats=r['before']['stats'],after_stats=end['stats'],
           frame_delta=end['stats']['frames']-r['before']['stats']['frames'],started_delta=end['stats']['started']-r['before']['stats']['started'],
           debug_drop_delta=r['debug']['after']['dropped']-r['debug']['before']['dropped'],debug_capture_dropped=r['debug']['after']['capture_dropped'],
           bad_replies=bad,traffic_shapes=traffic,final_memory=end['memory'],final_owner=end['drv'],final_load=end['load'],
           features=[dict(phase=f['phase'],cleanup=f.get('cleanup'),position_before=position(list(f['state_before'].values())) if isinstance(f['state_before'],dict) else position(f['state_before']),
                         position_after=position(list(f['state_after'].values())) if isinstance(f.get('state_after'),dict) else None,
                         move_outcome=f.get('move',{}).get('outcome'),move_completion=f.get('move',{}).get('completion'),restoration=f.get('restoration',{}).get('restored')) for f in r['features']])
    out['platforms'][platform]=p
Path('build/p29/measurements.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:{'ok':v['ok'],'frames':v['frame_delta'],'seconds':v['elapsed_s'],'stops':v['stops'],'windows':len(v['windows'])} for k,v in out['platforms'].items()},indent=2))
