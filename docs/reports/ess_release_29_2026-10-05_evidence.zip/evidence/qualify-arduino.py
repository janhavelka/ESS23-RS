"""Recorded prompt29 procedure using the production Console and finite scenarios."""
import json,sys,time,statistics
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,str(Path('scripts').resolve()))
import bench_probe as probe
import bench_motion as motion
from bench_session import checked,run_recorded
from bench_scenarios import _setting,_same_configuration

platform,image=sys.argv[1:]
prefix=Path('build/p29/evidence')/platform
loads=((0,0,0),(2000,5000,128),(5000,5000,256))
plan=dict(platform=platform,windows=[dict(load=x,command=c,count=100,interval_s=.2)
    for x in loads for c in ('probe','capture-read')],
    limits=dict(read_latency_us=100000,capture_gap_us_exclusive=85,owner_gap_us_exclusive=15000,
        internal_median_decline_bytes=1024,psram_median_decline_bytes=0,owner_stack_min_bytes=1024,
        worker_stack_min_bytes=2048,per_image_deadline_s=600),
    negative_owner_delay=dict(load=[0,20000,0],command='probe',expected='TX_TIMEOUT before TX',
        cleanup=['restore original host load','explicit recover','one distinct probe']),
    pressure='retain8 probes; ninth results_full; one stopped direct stop through reserved capacity; inspect/release all',
    features=[motion.phase_plan(p) for p in ('actions','forward','forward','stop-normal','stop-direct')],
    settings='lock-delay200->201->200 with checked readback and explicit restoration',
    physical_exclusions=['several-hour soak','moving link loss','motor restart','external I/O','velocity','homing','unsupported writes'])
prefix.with_name(platform+'-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps(plan,indent=2),flush=True)

def require(value,message):
    if not value: raise probe.BenchError(message)

def release_restored(c,r):
    view=checked(c,'motion-profile',host_args=('inspect',))
    r.setdefault('snapshot_releases',[]).append(view)
    if view['saved']:
        require(view['restored'] and view['original']==view['current'] and not view['pending']
                and not view.get('restore_unsettled',False),'unsettled prior snapshot: do not erase it')
        checked(c,'motion-profile',host_args=('forget',))

def run(c,r):
    started=time.monotonic()
    def budget(): require(time.monotonic()-started < 600,'predeclared600s image budget exhausted')
    def pause(s): budget(); time.sleep(s)
    original=tuple(r['before']['load'][name] for name in probe.LOAD_FIELDS)
    require(original==(0,0,0),'initial fixture load must be explicitly unloaded')
    require(not r['before']['drv']['retained'] and not r['before']['drv']['pending'],'initial owner results not empty')
    require(probe.drive_reported_stopped(r['before']['state']),'fresh standstill required')
    r['windows']=[]
    # Warm up every response/display shape before comparing fixed memory samples.
    checked(c,'probe',address=1); checked(c,'capture-read',address=1)
    checked(c,'memory')
    try:
        for selection in plan['windows']:
            budget(); window=dict(selection)
            probe.campaign(c,'load',count=100,interval_s=.2,timeout_s=5,address=1,
                           load=tuple(selection['load']),read_command=selection['command'],sleeper=pause)
            window['summary']=dict(r['campaigns'][-1])
            window['load_snapshot']=checked(c,'load')
            window['memory']=checked(c,'memory')
            window['stats']=checked(c,'stats')
            r['windows'].append(window)
            lat=window['summary']['latency_us']; load=window['load_snapshot']; mem=window['memory']
            require(lat['max'] <100000,'read latency exceeded predeclared100ms threshold')
            require(load['capture_gap_max_us'] <85 and not load['sample_gap_exceeded'],'capture gap envelope exceeded')
            require(load['owner_gap_max_us'] <15000,'active owner gap exceeded15ms')
            require(mem['stack_free_bytes']>=1024 and load['work_stack_free_bytes']>=2048,'stack headroom below limit')
            for key in ('failed','timeouts','capture_faults','rx_errors'):
                require(window['stats'][key]==r['before']['stats'][key],'unexpected '+key)
            print('PASS window',selection,lat,flush=True)
    finally:
        if c.synchronized: r['load_restored']=checked(c,'load',load=original)
    for key,allowed in (('internal_free',1024),('psram_free',0)):
        values=[w['memory'][key] for w in r['windows']]
        decline=statistics.median(values[:3])-statistics.median(values[-3:])
        r.setdefault('memory_trend',{})[key]=dict(samples=values,median_decline=decline,limit=allowed)
        require(decline<=allowed,'steady-phase memory decline exceeds predeclared limit')
    budget()
    # Expected host scheduling fault, stopped and read-only; never a motor retry.
    checked(c,'load',load=(0,20000,0))
    fault=c.command('probe',address=1)
    r['owner_delay_fault']=fault
    require(not fault['ok'] and fault.get('transport')=='TX_TIMEOUT' and fault.get('tx_bytes')==0
            and not fault.get('execution_unknown',True),'unexpected20ms delay disposition')
    owner=checked(c,'drv'); r['owner_delay_before_recovery']=owner
    require(owner['recovery_required'] and not owner['transmit_enabled'],'fault interlock/DE disposition missing')
    checked(c,'load',load=original)
    r['explicit_recovery']=checked(c,'recover')
    checked(c,'probe',address=1)
    checked(c,'read-config',address=1); probe.observe_stopped(c,address=1,timeout_s=5)
    # Ordinary retained capacity may not erase results or consume urgent stop capacity.
    held=[]; r['pressure_results']=[]
    for _ in range(8):
        h=c.begin('probe',address=1); result=c.wait(h)
        require(result['ok'],'retained pressure probe failed'); held.append(h)
        r['pressure_results'].append(result)
    ninth=c.command('probe',address=1); r['pressure_rejection']=ninth
    require(not ninth['ok'] and ninth.get('result')=='results_full','ninth ordinary admission changed full queue')
    r['pressure_stop']=checked(c,'stop',stop_policy='direct',address=1)
    require(r['pressure_stop']['completion']=='observed','reserved stop completion missing')
    for h in held:
        saved=checked(c,'result',operation_id=h.operation_id)
        require(saved['operation_id']==h.operation_id and saved['ok'],'retained result changed under urgent pressure')
        checked(c,'release',operation_id=h.operation_id)
    require(not checked(c,'drv')['retained'],'retained pressure results leaked')
    budget(); release_restored(c,r)
    r['features']=[]
    for phase in ('actions','forward','forward','stop-normal','stop-direct'):
        budget(); record={'phase':phase}; r['features'].append(record)
        motion.run_phase(c,phase,record)
        if phase in motion.MOTION_PHASES:
            require(record['cleanup']=='stopped_and_restored','finite feature cleanup incomplete')
            if phase.startswith('stop-'):
                stop_results=[x['result'] for x in record['events'] if x['command']=='stop']
                require(stop_results and stop_results[-1]['serviced_us']-stop_results[-1]['started_us']<500000,
                        'stop observation exceeds500ms firmware action bound')
            release_restored(c,r)
        print('PASS feature',phase,flush=True)
    control=checked(c,'control',driver_args=('read',),address=1)
    require(control['observation']['raw'][7]==200,'reviewed lock-delay baseline differs')
    _setting(c,SimpleNamespace(setting='lock-delay',value=201,address=1,timeout=5),r)
    require(r['setting']['restored'],'lock-delay restoration incomplete')
    _same_configuration(r['before']['config'],checked(c,'read-config',address=1))
    probe.observe_stopped(c,address=1,timeout_s=5)
    probe.campaign(c,'stress',count=10,interval_s=.05,timeout_s=5,address=1)
    r['workload_verified']=True

run_recorded(port='COM13',out=prefix,scenario='prompt29 bounded load/fault/feature qualification',inputs=plan,
             run=run,address=1,timeout_s=5,debug='decoded',firmware=Path(image),refresh=True,
             max_records=200000,max_bytes=64*1024*1024)
print('PASS image',platform,flush=True)
