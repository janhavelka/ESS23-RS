﻿import sys
from pathlib import Path
sys.path.insert(0,'scripts')
from bench_session import run_recorded,checked

def run(c,r):
 r['move219']=c.command('result',operation_id=219)
 r['axis']=checked(c,'axis',host_args=('config',))
 r['profile']=checked(c,'motion-profile',host_args=('inspect',))
 r['workload_verified']=True
run_recorded(port='COM13',out=Path('build/completion_followup/retained'),scenario='retained-completion-inspection',inputs={'motor_writes':0,'motor_reads':0},run=run,refresh=False)
