import sys
from pathlib import Path
sys.path.insert(0,'scripts')
from bench_session import run_recorded,checked

def run(c,r):
 r['stop347']=c.command('result',operation_id=347)
 if not r['stop347'].get('ok') or r['stop347'].get('completion')!='observed': raise RuntimeError('stop347 not confirmed')
 r['reviewed']=[]
 for op in range(230,348):
  v=c.command('result',operation_id=op)
  if v.get('result')=='not_found':continue
  if 'state' not in v:continue
  r['reviewed'].append(v)
  if v['state'] in ('succeeded','failed'): checked(c,'release',operation_id=op)
 r['workload_verified']=True
run_recorded(port='COM13',out=Path('build/completion_followup/reviewed-results'),scenario='explicit-review-and-release-test-results',inputs={'user_move219_retained':True,'motor_writes':0},run=run,refresh=False)
