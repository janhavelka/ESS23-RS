import sys,time
from pathlib import Path
sys.path.insert(0,'scripts')
from bench_session import run_recorded,checked
from bench_probe import observe_stopped,BenchError
from bench_motion import profile_snapshot,restore_profile
from human_helpers import subdivision

def run(c,r):
 r['setting1600']=subdivision(c,1600)[0]
 r['config']=checked(c,'read-config',address=1)
 r['profile']=profile_snapshot(c)
 r['before_state']=observe_stopped(c,address=1,timeout_s=5)
 r['cases']=[]
 for rpm in (2000,):
  case={'rpm':rpm,'native_displacement':4000,'samples':[]};r['cases'].append(case)
  move=None
  try:
   move=c.begin('move-relative',move_args=('4000','steps','native',str(rpm),'configured'),address=1,timeout_s=15)
   case['admission']={'accepted':move.accepted,'operation_id':move.operation_id}
   if not move.accepted: raise BenchError('move rejected')
   for i in range(18):
    case['samples'].append(checked(c,'read-state',address=1));time.sleep(.1)
  finally:
   if c.synchronized:
    case['stop']=checked(c,'stop',address=1,stop_policy='fast')
    case['stopped']=observe_stopped(c,address=1,timeout_s=5)
    if move is not None and move.accepted: case['move']=c.wait(move,release=False)
   else:case['cleanup']='unknown; framing lost'
  if not case['stopped']['ok']:raise BenchError('stop unconfirmed')
 r['restore']=restore_profile(c)
 r['final_state']=observe_stopped(c,address=1,timeout_s=5)
 r['setting_restore']=subdivision(c,51200)[0]
 r['final_state']=observe_stopped(c,address=1,timeout_s=5)
 r['workload_verified']=True
run_recorded(port='COM13',out=Path('build/completion_followup/lower-subdivision-comparison'),scenario='bounded-completion-speed-comparison',inputs={'subdivision':1600,'restore_subdivision':51200,'speeds':[2000],'native_displacement':4000,'sample_count':18,'sample_interval_s':.1,'cleanup':'fast stop after each finite trial'},run=run,refresh=False)
