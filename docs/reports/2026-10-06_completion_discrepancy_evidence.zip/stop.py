import sys
from pathlib import Path
sys.path.insert(0,'scripts')
from bench_session import run_recorded,checked
from bench_probe import observe_stopped

def run(c,r):
 r['stop']=checked(c,'stop',address=1,stop_policy='normal')
 r['state']=observe_stopped(c,address=1,timeout_s=5)
 r['workload_verified']=True
run_recorded(port='COM13',out=Path('build/completion_followup/explicit-stop'),scenario='explicit-normal-stop',inputs={'motion_replay':False},run=run,refresh=False)
