import sys
from pathlib import Path
sys.path.insert(0,'scripts')
from bench_session import run_recorded,checked
from bench_probe import observe_stopped

def run(c,r):
 r['identity']=checked(c,'read-identity',address=1)
 r['state']=observe_stopped(c,address=1,timeout_s=5)
 r['axis']=checked(c,'axis',host_args=('config',))
 r['user_move219']=c.command('result',operation_id=219)
 r['workload_verified']=True
run_recorded(port='COM13',out=Path('build/completion_followup/final'),scenario='final-identity-and-standstill',inputs={'motor_writes':0},run=run,refresh=False)
