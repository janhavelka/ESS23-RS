import sys,json
from pathlib import Path
sys.path.insert(0,'scripts')
from bench_session import run_recorded,checked

def run(c,r):
 r['reviewed']=c.command('result',operation_id=359)
 assert r['reviewed']['ok'] and r['reviewed']['completion']=='observed'
 r['release']=checked(c,'release',operation_id=359)
 r['workload_verified']=True
run_recorded(port='COM13',out=Path('build/completion_followup/release-test-success'),scenario='release-reviewed-test-success',inputs={'motor_writes':0,'user219_retained':True},run=run,refresh=False)
