# Features implementation tasks and open questions

This is the working backlog for `MotorControl-RS`. The three-layer architecture
is accepted; implemented blocks supply units, register metadata and checked
ESS codecs with a minimal probe. Checked design decisions below remain documentation milestones,
not claims of complete motion API or hardware support. Keep this list current
after each completed logical block, and commit
and sync that block under [the repository guidance](../AGENTS.md).

## Accepted design

- [x] General framework/platform-independent common axis API, drive profiles
  and application integration; ESS first, Leadshine iEM-RS as design contrast.
  ESP32-S3 is the available standalone bench, not a required platform or product.
- [x] Scope the reference workflow to RS485 request/wait/result ownership.
  FieldCore's future motor device does not exist yet; its RS485 task is read-only
  integration reference. Other buses and product composition are outside scope.
- [x] Accept optional external motor I/O: distinguish wiring from drive function
  assignment, support explicit documented disable and require inputs only for
  operations that use them. Typed I/O setters remain planned; this records the design decision.
- [x] Keep CANopen in a separate future library, initially for the verified
  CL86-C subset; maintain one motion contract and independent bus ownership.
  Extract common units/types only after concrete reuse in both implementations.
- [x] Stateless bounded codecs and optional caller-owned finite sequencing;
  application-owned transport, timing, scheduling, retry policy and health.
- [x] Common step/count/angle/travel modes with explicit units, gearing,
  origin, rounding, limits and multi-turn versus wrapped-angle semantics.
- [x] Complete documented native command access per supported model/protocol/
  firmware, with typed extensions and API/CLI parity.
- [x] Separate acknowledgement, completion, uncertain execution, device state
  and communication/readiness/freshness health.
- [x] Interruptible stop with explicit deceleration/queue behavior; unsupported
  operations fail before transmission.
- [x] Discovery and minimal non-changing probe requirements for every drive
  profile/manufacturer grouping, with explicit capability/evidence gaps.
- [x] Record COM13 bench availability, free-shaft mounting and testing
  authorization in [hardware bench notes](hardware_bench.md).

The authoritative contracts are [architecture](architecture.md),
[axis API](axis_contract.md), [profiles](profile_contract.md),
[discovery](discovery_contract.md) and [CLI](cli_contract.md).

## Implementation blocks

1. **Completed ESS protocol core:** FC03/FC06 and four reviewed FC10 windows,
   checked replies, independent CRC/frame tests and raw word conversions.
   Probe reads model register 0x0000/one word. General FC10 limits and typed
   field meanings remain unresolved where documented; no hardware I/O occurred.
2. **Read-only ESP32-S3 bench bring-up:** runner, polling adapter, probe CLI, native tests
   and a 100-probe bench run are complete. Existing CO2control flash was backed
   up before upload. Next verify the RX timing assumptions with an external
   TX/RX/DE trace and resolve raw model `0x4EEA`; add explicit identity/state
   reads after reviewing their semantics. See the dated bench report.
   Develop the load-tolerant capture and bus-owner reference here before
   eventual FieldCore integration; see the staged transport work below.
3. **First motion and stop:** target quantization/reference/limits, required
   ESS setup and bounded operation sequencing, interrupting stop and uncertain
   outcomes. Test failure events natively before qualifying small step/angle
   moves and confirming the encoder/subdivision assumptions on the bench.
4. **Expand and integrate:** velocity/homing and complete native ESS operations,
   discovery scans and CLI parity; standalone Arduino/ESP-IDF qualification,
   then FieldCore integration in its own repository.

The package is `MotorControl-RS`; namespace/includes/CMake use `MotorControlRS`.
Metadata is prepared for the user's GitHub/folder rename to `MotorControl-RS`;
see the [rename steps](repository_rename.md). This does not change the API.

## Immediate next implementation block

The independent native wire fixture, ESP32-S3 load fixture and optional GPTimer
capture are implemented and have bench evidence in the
[capture/load audit](reports/2026-10-03_capture_load.md). External TX/RX/DE
measurements and the production CPU budget remain open.
[Prompt 04](reports/ess_release_04_2026-10-04.md) retains the measured 20-us
capture, enforces timer starvation failure and extends available read-only
bench evidence to fixed 37-byte replies. Cache-off capture is explicitly
unsupported. Prompts 05–06 implement typed identity/configuration/state reads
and separate health. [Prompt 07](reports/ess_release_07_2026-10-04.md) implements
exact host target preparation. Prompt 08 is next when separately dispatched;
physical actions retain their units, stop and timing prerequisites.
The [release roadmap](roadmap.md) defines the delivery order and release gates.

Release prompt 01 is implemented: [BusOwner](bus_owner.md) provides FIFO
admission, copied frames/expectations, reserved retained results, stable IDs,
checked parser settlement and absolute closure deadlines through the real Runner.
Native tests pass; the rebuilt Runner passed read-only bench regression.
Prompt 03 now connects the actual owner and has read-only timer bench evidence;
absolute boundary/fault combinations remain explicitly native where not injected live.
See [the prompt 01 handoff](reports/ess_release_01_2026-10-03.md).
Its [fresh independent audit](reports/ess_release_01_audit_2026-10-03.md)
corrected earlier-budget timeout precedence and retained final-gap evidence
on relative byte expiry; focused regressions and current-image probes pass.

Prompt 02 is implemented: cyclic producer fairness, deferred per-producer FIFO,
reserved urgent admission/results, local cancellation, sequence invalidation and
explicit recovery that cancels old queued work. Its separate recovery result
survives full ordinary/urgent result pressure; old writes never resume.
See [the prompt 02 handoff](reports/ess_release_02_2026-10-03.md). Owner hardware
is measured through the actual console in [prompt 03](reports/ess_release_03_2026-10-03.md).
Its [fresh independent audit](reports/ess_release_02_audit_2026-10-03.md) fixes
delayed cancellation versus later expiry and retains recovery timing evidence
across drain passes; native regressions and firmware builds pass.
FieldCore remains read-only; typed identity/state and motion/stop retain their gates.

## ESS source and profile work

- [x] Transcribe the complete ESS appendix, named choices/bitfields and indexed
  records into a canonical JSON ledger and generated C++ catalogue: 221 logical
  records / 242 words. Complete typed operational and CLI coverage remain unimplemented.
- [x] Implement checked raw ESS codecs and their reviewed access/window policy.
  Raw FC06 words are not typed value validation or complete native command coverage.
- [x] Audit every appendix address: 78 undocumented words in 15 intervals,
  16 explicitly reserved words and two words with unspecified access are
  recorded and checked by the generator. No missing named register was found.
- [x] Extend FC10 to the position, speed and homing examples on pp16/18/20;
  correct p16's CRC-valid but malformed request in independent fixtures.
- [x] Audit RTU framing and motion/configuration timing in the
  [timing reference](reference/09_timing_and_gap_audit.md). Keep unspecified
  response, save and startup deadlines for later hardware qualification.
- [x] Fix unit conversions to require gearing/lead only across relevant
  bases, and combine bounded scale/time factors before the input value to
  avoid intermediate underflow on binary64 `long double` platforms.
- [x] Re-audit original ESS wire/probe pages and document retained ambiguities;
  download/audit five contrasting serial manufacturers in the
  [protocol review](reference/08_serial_protocol_review.md).
- [ ] Resolve or explicitly retain every ambiguity in the
  [implementation reference](reference/01_implementation_reference.md), using
  original PDF pages and later exact-model readback.
- [ ] Establish read/write windows and counts, widths, signedness, ranges,
  paired-word order, reserved bits and exception semantics.
- [ ] Establish command/feedback/encoder units, speed and ramp scaling,
  host-origin mapping and configuration dependencies.
- [ ] Define typed ESS identity, telemetry, motion, homing, stop, auxiliary,
  I/O, segment, limits, tuning, communications and persistence operations.
- [ ] Implement explicit ESS input/output disable through documented function 0
  (`UNDEFINED`: no function), sharing the typed function setter with API/CLI.
  Preserve unknown output electrical state and serial/external-control precedence;
  cable absence and polarity inversion are not disabling. Prompt 15 owns setters.
- [ ] Verify serial-only operation with optional I/O unwired or explicitly
  disabled, using readback prerequisites from 05 and admission tests in 08/09.
  Never rewrite input functions implicitly during startup, probes or motion.
- [ ] Preserve external-input-only segment execution and model-specific I/O
  counts; expose available serial configuration without fictional triggers.
  Missing/disabled homing or trigger inputs block only dependent operations.
- [ ] Map common operations to ESS with exact prerequisites, completion
  evidence, read side effects, partial-write outcomes and replay rules.
- [ ] Complete the Leadshine design comparison before fixing common API
  signatures; implementation/hardware qualification remain separate work.

## Common API and desired modes

- [x] Implement pure displacement, velocity and acceleration conversions with
  independent unit preferences (including steps/s², degrees/s², radians/s²,
  rpm/s), caller-owned rational scales and documented bench defaults.
- [x] Record 1.8° / 200 full-step geometry, default 1000-line / 4000-count
  encoder evidence, scaled-feedback distinction and unknown encoder part.
- [x] Check conversion errors without mutating outputs; preserve exact native
  integers through separate range/narrowing helpers and exact rational target
  preparation, explicit rounding, checked origins and endpoint limits in 07.
- [x] Implement pure motor/load/native target preparation, identified encoder
  and configured travel mappings, precision provenance, generation checks and
  evidence-gated host configuration/origin APIs. Drive execution and wrapped
  angle path policy remain separate work.

- [ ] Implement capability/configuration inspection and exact native value
  preservation, with structured unsupported/unresolved/unimplemented reasons.
- [ ] Implement absolute/relative moves in command steps, full steps and
  identified encoder counts where mappings exist.
- [ ] Implement turns, degrees and radians: unwrapped multi-turn positioning
  and wrapped orientations with direction and half-turn tie policy.
- [ ] Prepare and execute configured linear-travel moves, initially mm, using
  the existing velocity/acceleration conversions and rational scale/gear/lead.
- [x] Implement conversion provenance, precision/rounding reports, overflow,
  effective-target/path limits and reference/configuration generations.
- [ ] Implement velocity/jog, explicit ramps and profile keepalive deadlines;
  optional torque/current modes only where the profile supports them.
- [ ] Implement enable/release, homing methods, host-origin changes, documented
  device-counter changes, alarm clear and state observations.
- [ ] Implement caller-owned contexts, operation correlation, retained
  uncertain outcomes, stop preemption and explicit queue disposition.
- [ ] Reserve same-axis operations across parameter staging/trigger/observation
  while allowing eligible unrelated bus work. Validate/reserve stop before
  superseding active work; rejected stop admission must not cancel it.
- [ ] Preserve per-field actual/commanded, valid/unknown/stale and raw/native
  evidence; keep application health and clock ownership outside the core.

## Discovery and minimal probes

- [ ] Record discovery/probe/identity support for every supported profile and
  manufacturer group, including explicit unsupported or unresolved entries.
- [x] Select and implement the smallest documented ESS query: FC03 model word
  0x0000/one word, with checked raw reply. No consuming side effect is documented.
- [ ] Qualify ESS probe latency, firmware behavior and communication-watchdog
  interaction on hardware before claiming a measured non-changing fast probe.
- [ ] Design the contrasting Leadshine query with the same requirements;
  do not consume its read-to-clear status as a generic presence probe.
- [ ] Implement `getDiscoveryCapabilities`, `prepareProbe` and structured
  responsiveness/identity/ambiguity results separately from full identity reads.
- [ ] Implement application-owned bounded address/baud/format discovery with
  profile/manufacturer filters, limits, cancellation and partial results.
- [ ] Validate compatible query candidate sets; never assume safe automatic
  protocol mixing or infer a manufacturer from a valid CRC alone.
- [ ] Preserve host settings/selection and restore them after scans; expose
  restoration failure, collisions and unresolved matches.
- [x] Add read-only CLI `probe`/`ping` through the existing public ESS probe
  builder and checked parser. The common discovery preparation API is still planned.
- [ ] Add CLI catalog, explicit `read identity` and bounded `discover` through
  the same public APIs as upper firmware.
- [ ] Qualify latency and non-changing behavior per exact model/firmware;
  retain one-attempt quick probing and explicit bounded scan retry policies.

## Standalone examples packaging and integration

- [x] Revisit current ownership and dependency boundaries and record the
  [architecture report](architecture_report.md), including the actual file
  map, debugging flow and current FieldCore integration gaps.
- [x] Add real public headers/source, native tests, version/package metadata,
  CMake builds and an offline desktop/Arduino units preview.
- [x] Record the standalone ESP32-S3 bench settings and RS485 pins TX47/RX48/DE21
  in [bench configuration](reference/04_esp32_bench.md). Adapter configuration is
  example-owned; no FieldCore product or other bus defines the motor API.
- [ ] Implement common CLI inventory/dispatch and full native command coverage
  through public APIs, cached status/health and retained operation results.
- [x] Implement example-owned RTU runner with fake callback tests: physical
  TX drain, wire-timed receive framing, explicit echo, exception length,
  cancellation, retained diagnostics and recovery admission.
- [x] Implement the ESP32-S3 UART adapter with physical TX-idle intervals, RX
  capture intervals, UART error reporting and actual-source SDK fake tests.
- [ ] Externally qualify RX FIFO/stop sampling and idle-watermark assumptions,
  DE setup/hold and load tolerance. Probe success is not full timing qualification.
- [x] Allocate larger task-context trace/frame/cache storage in PSRAM in the
  standalone application; document fallback, retain required internal storage, and
  record free/minimum/largest-block memory and stack measurements.
- [x] Add Python bounded probe/stress and cached health/memory watching with
  JSONL evidence, no retry/recovery and native fake serial tests.
- [x] Audit the adapter/console/harness path: fix RX silence races, fault-result
  availability, exception recovery policy, cached codec details and host
  evidence validation; test the actual application loop with shared SDK fakes.
  See the [0.5.1 audit](reports/2026-10-03_audit.md); external timing remains open.
- [ ] Extend automation to actual motor state once typed state reads exist.
- [ ] Build standalone ESP32-S2/S3 Arduino consumers and a first-class native
  ESP-IDF consumer with equivalent command semantics for equivalent features.
- [x] Verify framework-free native consumption, self-contained headers and
  a clean core source package; exclude vendor downloads from that package.
  Embedded package consumers beyond the compiled Arduino preview remain future work.
- [ ] Add later FieldCore adapter work in that repository: typed motor control,
  FC06 echo handling, larger TX frames, exception framing, exact integers,
  receive timing evidence, scheduling and stop priority. Standalone work must
  not depend on this step. A future motor device and selected platform wiring
  belong to that integration; the current test board does not define them.

## Standalone RS485 workflow and later integrations

Major transport-reference development and testing belong here, with the public
motor library independent of the application bus owner and platform adapter.
FieldCore is a read-only RS485 workflow reference for the current session; the
same core and request/wait/result pattern must also work for other consumers. See the
[development route](reference/10_runner_platform_review.md#develop-the-integration-reference-here).

- [x] Extend native fixtures for delayed task service and captured wire events;
  check lost timing, UART overflow, late replies and bounded terminal results.
- [x] Add an ESP32-S3 task/USB/load fixture and measure service gaps, CPU cost, errors,
  transaction latency and memory. Implement GPTimer capture and physical DE
  release while the owner sleeps; retain atomic completion/release observations.
- [x] Review capture cost and retain the single 20-us sampler; expose timer/sample
  work separately and enforce starvation faults. Fixed non-consuming 0x0130/16
  read has native and physical 37-byte reply evidence in
  [prompt 04](reports/ess_release_04_2026-10-04.md).
  Its [fresh audit](reports/ess_release_04_audit_2026-10-04.md) requires complete
  capture diagnostics and rejects sticky sampling-gap violations in the host
  qualification campaign; repeated read-only hardware tests pass.
- [ ] Independently qualify TX/RX/DE, final stop-bit publication, idle and echo
  assumptions; characterize physical interrupt starvation and decide the
  production CPU budget. Analyzer evidence is NOT RUN; cache-off operation
  during capture is unsupported. FC06/FC10 physical frames remain gated by
  typed operations and relevant timing prerequisites.
- [x] Build the bounded cooperative FIFO owner with copied requests, reserved
  retained results, exact generation IDs and checked parser settlement. Native
  multi-request/failure tests pass; owner board integration is delivered by prompt 03.
- [x] Extend the owner with producer fairness, cancellation and urgent reservation
  (prompt 02); native mixed-producer/fault/pressure tests pass. No ESS stop yet.
- [x] Integrate the bounded responsive console, retained result/cancel/driver
  commands and owner recovery policy; timer read-only/load/interleaved hardware
  evidence is in [prompt 03](reports/ess_release_03_2026-10-03.md).
  Its [fresh independent audit](reports/ess_release_03_audit_2026-10-04.md)
  corrects deadline-gated adapter recovery, result reuse/inspection and cache
  attribution under failed reads and output pressure; new-image regression PASS.
- [x] Enforce immutable absolute deadlines through queue/setup/TX/closure without
  losing qualified on-time captured evidence; native evidence in prompts 01–02.
- [x] Extend recovery/cancellation generation disposition: terminally cancel old
  queued work, invalidate continuations, preserve unread results, settle TX and
  boundedly discard stale traffic; no implicit queued writes after recovery.
- [x] Separate qualified observation age, delivery and recovery-settlement in
  the probe application; delayed timer service and repeated cached queries keep
  historical age. Unsent cancellation and retained recovery preserve new data.
- [x] Exercise FC06 echo/identical acknowledgement, all four reviewed FC10 sizes,
  checked exceptions, malformed replies and deadline/late-capture behavior with
  fake responders through the actual owner/Runner (prompt 01).
- [ ] Add physical write qualification only with reviewed typed motor operations
  and their prerequisites; fake writes do not qualify the motor.
- [ ] Qualify longer reviewed non-consuming reads and the supported frame-size
  envelope separately from seven-byte model replies; preserve unavailable
  physical long-frame/write cases as open evidence.
- [ ] Package repeatable scenarios and a mapping to FieldCore's request/result,
  module and backend boundaries. Preserve its other serial framing modes in
  future integration regressions; do not clone the whole FieldCore task here.
- [ ] Later, under separate authorization, adapt FieldCore's existing owner
  and test real concurrency, sensor regressions and application load there.
  Do not add its unrelated bus abstractions or product registry to this library.

## Verification and COM13 bench work

- [ ] Add one repeatable full verification command and CI for native suites,
  generated files, header isolation and package consumption. Require Python
  checks for repository/release validation; ordinary C++ consumers remain
  independent of Python. Record the supported compiler/platform matrix.
- [x] Inspect COM13's CO2control firmware, preserve flash, build/upload the standalone
  probe and establish communication at address 1, 115200 8N1, TX47/RX48/DE21.
- [x] Record the first minimal model read, raw frames, interval evidence and
  explicit 304 us bench turnaround exception; complete repeated probe tests.
- [ ] Establish exact motor/firmware identity and echo behavior for writes.
  Raw model `0x4EEA` differs from the manual example; no mapping is invented.
- [x] Validate codec golden frames and malformed inputs with unchanged payload
  outputs on errors; test exception/echo/word-order/count boundaries.
- [ ] Validate conversion, angular-path, capability, sequencing and interruption
  behavior independently of hardware; exercise failure/timeout events.
- [ ] Qualify small moves in steps/angle/travel, velocity, homing where available,
  enable/release, stopping, limits and stale/reference handling on the bench.
- [ ] Qualify native I/O/segment configuration, tuning and persistence commands
  as applicable, recording the before/after active and saved configuration.
- [ ] Exercise lost acknowledgements, partial setup, late replies, cancellation,
  power/reconnect and communication changes without accidental motion replay.
- [ ] Record exact hardware/firmware/build/settings and distinguish software
  test success, protocol observations and physical motion outcomes.

## Open questions

Resolve from references, existing firmware and bench observations where
possible. This list is not a request for the user to answer everything now.

| Question | Evidence or next action |
| --- | --- |
| When does the GitHub repository URL change? | Metadata is prepared for `janhavelka/MotorControl-RS`; the user performs the GitHub rename, then updates the clone's origin. Folder/cache steps are in [the rename guide](repository_rename.md). Package/API identity is already complete. |
| What motor/model/firmware is actually connected? | Read documented identity; compare model markings if identity is insufficient. The project's RS20 target is not a bench measurement. |
| What firmware/host path is active on COM13? | Latest recorded bench: MotorControl-RS 0.6.0 JSONL probe/load console with timer capture, with original CO2control backup retained. Recheck identity at each new hardware session; it is not a raw RTU bridge. |
| What are the board pins, DE/RE polarity, echo topology and bus wiring? | Bench pins are TX47/RX48/DE21, UART2/active-high DE; the selected example config owns them. Live polarity, echo and wiring qualification remain. |
| Which address/baud/format is active despite reported defaults? | Replies are observed at node 1, 115200 8N1. Typed configuration and raw DIP readback now have prompt05/06 evidence; DIP mapping and bounded discovery remain pending. |
| Is the selected ESS probe qualified on the connected firmware? | Repeated checked FC03 0x0000/one-word replies have bench evidence. Exact model/firmware, external timing and communication-watchdog interaction remain unqualified. |
| Can discovery distinguish a manufacturer/model or only a responder? | Record exact reply evidence and retain ambiguous candidates; no guessed selection. |
| Which candidate protocols can be probed on the same bus? | Review query effects for the actual attached families; use an isolated target when compatibility is unknown. |
| What are the actual ESS command/feedback subdivisions and signed limits? | Resolve p69-70 inconsistencies with configuration readback and measured movement. |
| What are the speed/ramp units and valid ranges? | Reconcile command prose and ESS appendix before physical-unit conversion. |
| What are the exact FC10 limits and partial-write effects? | Vendor evidence plus bounded firmware qualification; do not use generic maximums as device facts. |
| Which state/alarm/completion reads are non-consuming and correlated to a new operation? | Three reviewed non-consuming state blocks are implemented and tested in prompt06. Their reads are independent; correlation to future motion completion still requires controlled sequencing tests. |
| Which optional inputs are wired, disabled or still assigned an active function? | Read exact drive function/polarity/state settings and record external wiring separately. ESS function 0 means no function; serial/external release precedence remains unresolved. Gate only dependent operations. |
| What persists, applies immediately, waits for save or needs a power cycle? | Resolve access notation and test exact firmware; retain unknown application state after lost writes. |
| How do collision-homing duplicate parameters and outside-map references apply? | Reconcile original pages/model scope; no guessed aliases or addresses. |
| What happens on communication loss, release, restart and external shaft motion? | Qualify per profile; update stop/reference/keepalive contracts with observations. |
| Which Leadshine model/firmware and hardware will qualify the contrast? | Select a concrete target before advertising support; current comparison is documentary. |

## Later extensions

- [x] Assess adding selected CANopen/CiA 402 drives alongside Modbus RTU;
  [feasibility review](reference/07_canopen_feasibility.md) records the accepted
  separate-library boundary and the user's Lichuan CL86-C candidate.
- [ ] In the separate future CANopen library: obtain firmware-matched CL86-C
  manual/EDS, qualify a CAN transport/stack adapter, define its event/state/stop
  contracts, then implement identity/position/stop against the shared motion
  vocabulary. Keep host-streamed cyclic modes and cross-bus synchronization separate.
  Manufacturer manual/EDS listings were found; direct downloads were unavailable
  during review, so exact object semantics and loss-of-controller behavior remain open.
- [ ] Once the second library implements real operations, verify matching
  motion semantics and extract genuinely shared units/types with independent
  protocol dependencies. No speculative common package is needed now.

- [ ] Qualify additional explicit families from the
  [manufacturer review](reference/03_multi_vendor_feasibility.md), with full
  native coverage and their own discovery/probe evidence.
- [ ] Add non-Modbus framing only for a concrete profile, preserving common
  API semantics and independently reviewing shared-bus compatibility.
- [ ] Consider blending, online target updates, queued paths and advanced
  ramps as declared capabilities rather than silent approximations.
- [ ] Treat coordinated multi-axis timing/trajectories as a separate design
  with explicit bus and device guarantees.

## Bench tooling issue from the platform-boundary audit

- [ ] Resolve repeated esptool 5.3.0 USB bootloader flash-read truncation at
  188,416 completed bytes of the tested application-region read. Traced and
  direct-file reruns reproduce an incomplete SLIP packet; exact cause remains
  open. Compare stub/ROM reads and capture USB at that packet before claiming
  a fix. Motor firmware is not running during this failure. Final-image upload
  verification and read-only RS485 regression pass independently; see the
  [audit and evidence](reports/2026-10-03_platform_scope_audit.md).

## Prompt 05 typed read handoff

The [fresh audit](reports/ess_release_05_audit_2026-10-04.md) rechecked the actual
public/core/application paths and retained evidence. No implementation defect
was confirmed; stale profile/discovery API descriptions were corrected.
Native/package/build checks and 16 additional non-changing COM13 transactions
passed on the unchanged image.

- [x] Pure caller-owned identity/configuration operations, exact gap-safe FC03 windows, checked atomic publication and copied provenance; installed-core consumer verification.
- [x] Same public preparation/event/decoder APIs through common/profile console routes and strict Python correlation, retention and release.
- [x] Complete ledger-linked operation inventory with separate source/model/read/write/action/API/CLI/native/hardware dispositions; generated descriptors remain unchanged.
- [ ] Resolve model `0x4EEA`/firmware/DIP mapping, subdivision physical interpretation and physical encoder evidence. Readback alone does not resolve these.
- [x] Prompt 06 state/input-level evidence; retain specific input-dependent homing, limit, enable/stop and trigger prerequisites without requiring external I/O for independent serial-only operations.
- [ ] Typed I/O changes remain for 15; no configuration writes, save or motion were added in 05.

See [the typed read API](ess_reads.md) and [current report](reports/ess_release_05_2026-10-04.md) for exact readback and independent hardware disposition.

## Prompt06 disposition

- [x] Typed non-consuming MOTION/IO/FEEDBACK preparation and checked block decoders,
  retaining unknown alarms/bits and unresolved position/speed interpretation.
- [x] Per-block application cache with exact generations, independent attempts,
  conservative age, failure retention and passive status/health.
- [x] Explicit health check and finite disabled-by-default polling through the
  existing owner; cancellation, urgent scheduling and pressure tests pass.
- [x] Installed C++11 consumer and stationary COM13 raw/decoded evidence;
  [report](reports/ess_release_06_2026-10-04.md) distinguishes native and hardware.
- [ ] Establish algorithm3 semantics, feedback sign/scale, speed units and actual
  versus commanded source; these block dependent completion/conversion claims.
- [ ] External electrical capture, physical encoder/motion/stop qualification.

Logical input levels0 do not establish external wiring or limit/stop effects.
Identity success and clear alarms do not prove readiness or settle an uncertain
operation. Prompt07 adds host arithmetic without promoting that evidence into
physical coordinate, standstill or motion qualification.

The [fresh06 audit](reports/ess_release_06_audit_2026-10-04.md) separates historical feedback interpretation from raw freshness after new configuration readback and rejects contradictory/missing cached JSON fields. Native, package/build and50-frame read-only COM13 checks pass. Qualification limits above are unchanged.

## Prompt07 disposition

- [x] Installed `Axis.h` configuration/reference/request/result APIs; exact
  rational preparation shares factor selection with existing units conversions.
- [x] Native integer extremes, origin overflow, all rounding modes/ties, limits,
  source-dependent encoder/travel conversions, bounded radians and stale evidence
  tested; independent integer oracles verify rounding and binary64 allowances.
- [x] Existing console exposes strict host `axis`/`prepare` routes through the
  same public API, independent unit preferences and no bus traffic.
- [x] Native/package/four firmware builds and 23-frame read-only COM13 campaign
  pass; drive configuration unchanged. See [report](reports/ess_release_07_2026-10-04.md)
  and [preparation contract](axis_preparation.md).
- [ ] Resolve ESS source/sign/command mapping before using feedback to establish
  a native origin or physical endpoint. Operator scales remain assumptions.
- [ ] Qualify machine travel, encoder, physical limits, motion and stop with
  suitable fixtures and reviewed profile semantics; free shaft is insufficient.

The operation ledger gets no read/write/action credit for host arithmetic.
Reduced exact intermediates use bounded uint64 storage and reject overflow;
there is no implicit approximate fallback. Prompt08 is not executed here.

The [fresh07 audit](reports/ess_release_07_audit_2026-10-04.md) fixes requested
relative-displacement range checking with a reference, zero-radian exactness,
normal cancellation onto zero and malformed decimal fraction operands. Native,
installed consumer, four firmware builds and a repeated 23-frame read-only COM13
campaign pass; no device setting or qualification claim changed.
