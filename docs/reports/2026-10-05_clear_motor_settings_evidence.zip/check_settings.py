import sys, time, re, json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'scripts'))
from bench_probe import BenchError, observe_stopped
from bench_session import run_recorded, checked
from bench_motion import restore_profile

def human(c, text, terminal=None, timeout=7):
    assert not c.pending and not c.buffer
    c.emit('human_command', text=text)
    c.port.write((text+'\n').encode())
    end=time.monotonic()+timeout; quiet=end; data=bytearray()
    while time.monotonic()<end:
        chunk=c.port.read(8192)
        if chunk:
            data.extend(chunk); quiet=time.monotonic()+.1
        decoded=data.decode('utf-8')
        if data and time.monotonic()>=quiet and (terminal is None or terminal in decoded):
            c.emit('human_output', text=decoded); print(text+'\n'+decoded,flush=True); return decoded
        time.sleep(.005)
    c.emit('human_output',text=data.decode('utf-8',errors='replace'))
    raise BenchError('human terminal missing for '+text)

def campaign(c,r):
    r['help']=human(c,'help')
    assert 'settings' in r['help'] and 'driver read' not in r['help'] and 'help advanced' in r['help']
    r['trials']=[]; last=0; attempted=False
    def move(command):
        nonlocal last, attempted
        attempted=True
        output=human(c,command,'Details:',timeout=10)
        wrapper=int(re.search(r'operation (\d+)',output).group(1)); last=wrapper
        assert 'Move complete' in output and 'Drive reported running, then target reached.' in output
        assert len(output)<500 and 'staging_evidence' not in output
        child=int(re.search(r'Details: @1 result (\d+)',output).group(1))
        evidence=checked(c,'result',operation_id=child)
        assert evidence['completion']=='observed' and evidence['running_observed'] and not evidence['uncertain']
        r['trials'].append(dict(command=command,output=output,evidence=evidence,wrapper=wrapper))
    def settings():
        nonlocal last
        output=human(c,'settings','Details:')
        last=int(re.search(r'Details: @1 result (\d+)',output).group(1))
        assert 'Microstep / subdivision: 1000' in output
        assert 'Next move (host preferences' in output and 'host declaration' in output
        assert len(output)<1800 and 'provenance' not in output and 'staging_evidence' not in output
        return output
    try:
        # No speed/ramp/scale commands or initial motor reads: exercise boot defaults.
        move('moveby 100 steps')
        r['settings_after_boot_move']=settings()
        for command in ('speed 3000','accel 2000','decel 0'):
            assert 'Next move:' in human(c,command)
        r['maximum_intent_only']=settings()
        assert 'Speed: 3000 rpm' in r['maximum_intent_only']
        for command in ('speed 90','accel 100','decel 100'):
            human(c,command)
        move('moveby 100 steps')
        human(c,'speed 60')
        move('moveby 300 steps')
        move('moveby 36 deg')
        r['settings_final']=settings()
        r['workload_verified']=True
    finally:
        if attempted and c.synchronized:
            r['stop']=checked(c,'stop',stop_policy='direct',address=1)
            r['stopped']=observe_stopped(c,address=1,timeout_s=5)
            if last: checked(c,'release',operation_id=last)
            r['restored']=restore_profile(c)
            r['final_state']=observe_stopped(c,address=1,timeout_s=5)
            r['probes']=[checked(c,'probe',address=1) for _ in range(3)]

plan=dict(moves=4,maximum_increments=300,maximum_test_rpm=90,deadline_s=10,
          local_range_checks='3000 rpm, 2000 ms accel, 0 ms decel; no move at these extremes',
          success='all terminals delivered; running then arrived; settings shows actual subdivision separate from intent',
          cleanup='one direct stop, zero speed, original profile restore once, three probes',
          electrical_and_shaft_observation='unmeasured',automatic_write_replay=False)
print(json.dumps(plan),flush=True)
run_recorded(port='COM13',out=Path(sys.argv[1]),scenario='consolidated-settings-boot-motion',
             inputs=plan,run=campaign,refresh=False,
             firmware=Path('build/clear_settings/pio/bench_s3_load_timer/firmware.bin'))
