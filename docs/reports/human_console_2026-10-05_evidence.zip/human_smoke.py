from pathlib import Path
import json, time, re, sys
sys.path.insert(0, 'scripts')
from bench_probe import open_port
out = Path('build/bench/human_console')
records = []
with open_port('COM13', 115200, 5) as port:
    def exchange(command=None):
        if command is not None:
            port.write((command+'\n').encode('ascii'))
        data = bytearray(); deadline = time.monotonic()+5; last = time.monotonic()
        while time.monotonic()<deadline:
            part=port.read(max(1,port.in_waiting))
            if part:
                data.extend(part); last=time.monotonic()
                if len(data)>65536: raise RuntimeError('output limit')
            elif time.monotonic()-last>.35: break
        text=data.decode('utf-8',errors='replace')
        records.append(dict(command=command,output=text))
        (out/'human-transcript.json').write_text(json.dumps(records,indent=2)+'\n')
        if command and not text: raise RuntimeError('No output: '+command)
        return text
    exchange()
    exchange('debug off')
    assert '[Getting started]' in exchange('help')
    assert '[Diagnostics]' in exchange('?')
    assert 'Usage:' in exchange('help stop')
    assert 'Usage:' in exchange('probe nope')
    assert 'help' in exchange('nonesuch')
    assert '[OK] status' in exchange('status')
    assert '"id":501' in exchange('@501 version')
    for mode in ('raw','decoded'):
        assert '[OK] debug' in exchange('debug '+mode)
        response=exchange('probe')
        assert '[WAIT] probe' in response and 'Outcome: success' in response, response
        assert 'Expected request hex: (empty)' not in response
        assert '[TX] transaction' in response and '[RX] transaction' in response, response
        operation=re.search(r'Operation: (\d+)',response).group(1)
        assert 'Operation: '+operation in exchange('result '+operation)
        exchange('release '+operation)
    exchange('debug off')
    for command in ('read identity','read config','read state'):
        response=exchange(command)
        assert '[WAIT]' in response and 'State: succeeded' in response, response
        operation=re.search(r'Operation: (\d+)',response).group(1)
        exchange('release '+operation)
    for command in ('status','health','drv','memory','stats'):
        response=exchange(command)
        assert '[OK]' in response and 'formatting failed' not in response, response
(out/'human-transcript.txt').write_text('\n'.join('> '+str(r['command'])+'\n'+r['output'] for r in records))
print('Human console read-only checks PASS:',len(records)-1,'commands')
