#include <MotorControlRS/MotorControlRS.h>
#include <cassert>
#include <cstdio>
int main(){MotorControlRS::ReadTarget t;t.id=t.address=t.generation=1;MotorControlRS::PreparedProbe p;
assert(MotorControlRS::prepareProbe(p,MotorControlRS::DriveProfile::ESS_RS,t,1,0,1000));assert(p.length==8);
std::printf("PreparedProbe=%zu ProbeObservation=%zu\n",sizeof(p),sizeof(MotorControlRS::ProbeObservation));}
