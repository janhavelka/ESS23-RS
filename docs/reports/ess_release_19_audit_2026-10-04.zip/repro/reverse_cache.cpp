#define main driver_fixture_main
#include "../../test/driver_app_test.cpp"
#undef main
#include <cstdio>
int main() {
    fresh(); readConfig(); qualify();
    const auto generation = app->axis.generation;
    Probe::HostRequest change; change.tuple.baud = 9600;
    Probe::HostSnapshot serial;
    assert(host(app).hostSerial(app, &change, serial) == Probe::Action::OK);
    Probe::HostRequest restore; restore.restore = true;
    assert(host(app).hostSerial(app, &restore, serial) == Probe::Action::OK);
    assert(app->configuration.target.id && !app->configuration.operationId);
    assert(!app->driverSettings.target.id);
    readSettings(0,1,1200);
    std::printf("config baseline direction=%u subdivision=%u; fresh driver direction=%u subdivision=%u; axis generation before=%u after=%u; origin=%d command scale=%u polarity=%d\n", app->configuration.raw.direction, app->configuration.raw.subdivision, app->driverSettings.raw[0], app->driverSettings.raw[1], generation, app->axis.generation, app->axis.originKnown, app->axis.units.commandStepsPerMotorTurn.numerator, app->commandPolarityKnown);
    assert(app->axis.generation == generation && app->axis.originKnown && app->axis.units.commandStepsPerMotorTurn.numerator == 1000 && app->commandPolarityKnown);
}
