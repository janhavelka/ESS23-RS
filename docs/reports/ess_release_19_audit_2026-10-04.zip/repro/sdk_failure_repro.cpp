#include "Esp32S3Uart.h"
#include "Hardware.h"
#include <cstdio>
using namespace MotorControlRSExample;
int main() {
    for (unsigned stage : {2U, 7U}) {
        resetHardware(); hardware.clockStep = 0;
        // Intentionally retain the unrepaired object until process exit.
        // Its destructor correctly aborts when it cannot clean up its timer.
        auto* uart = new Esp32S3Uart;
        if (!uart->begin({47, 48, 21, true}) || !uart->startCapture()) return 2;
        advanceHardware(2000);
        hardware.timerFailCalls = {hardware.timerCalls + stage};
        HostTuple changed; changed.baud = 9600;
        const bool change = uart->reconfigure(changed);
        hardware.timerFailCalls.clear();
        const bool repair = uart->reconfigure(HostTuple());
        std::printf("stage=%u change=%d explicit_repair=%d sdk_enabled=%d writes=%u\n", stage, change, repair, hardware.timerEnabled, hardware.writes);
        if (change || !repair || hardware.writes) return 3;
    }
}

