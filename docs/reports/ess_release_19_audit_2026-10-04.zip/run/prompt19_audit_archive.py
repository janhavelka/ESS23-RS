import hashlib,json,subprocess,zipfile
from pathlib import Path
root=Path.cwd(); bench=root/'build/bench'; reports=root/'docs/reports'
stem='ess_release_19_audit_2026-10-04'; path=reports/(stem+'.json')
data=json.loads(path.read_text(encoding='utf-8')); s=data['snapshots']
assert s['campaign_error']=='AssertionError()' # Preserve the failed harness assertion.
assert len(s['tuple_setups'])==16 and s['tuple_restore']['ok']
for command in ('read-identity','read-config','read-state'):
    assert [step['rx'] for step in s['after_'+command]['steps']]==[step['rx'] for step in s['before_'+command]['steps']]
for command in ('driver','io','control'):
    assert s['before_'+command]['observation']==s['after_'+command]['observation']
assert s['final_host']['active']==dict(baud=115200,format='8N1')
assert s['final_host']['active_known'] and not s['final_host']['blocked']
assert all(not s['final_drv'][k] for k in ('busy','transmit_enabled','recovery_required','pending','retained','reserved','input_dropped','output_blocked','output_short_writes','output_queued'))
assert s['final_stats']['started']-s['initial_stats']['started']==53
assert s['final_stats']['frames']-s['initial_stats']['frames']==51
assert s['final_stats']['failed']-s['initial_stats']['failed']==2
assert s['mismatch_9600_terminal']['transport']=='NO_RESPONSE'
assert s['mismatch_38400_terminal']['transport']=='RX_ERROR'
assert s['final_stats']['capture_faults']==s['final_stats']['rx_errors']==1
assert not s['final_stats']['sample_gap_exceeded']
for baud in (9600,38400):
    assert s['mismatch_'+str(baud)+'_recover']['ok'] and s['mismatch_'+str(baud)+'_restore']['ok']
    assert s['mismatch_'+str(baud)+'_restored_probe']['ok']
stress=[e for e in data['events'] if e['event']=='summary' and e.get('mode')=='stress']
assert len(stress)==1 and stress[0]['ok'] and stress[0]['probes_attempted']==stress[0]['probes_passed']==10
assert '100% tests passed' in (bench/'prompt19_audit_native_tests.log').read_text(encoding='utf-16')
assert 'Ran 184 tests' in (bench/'prompt19_audit_python_tests.log').read_text(encoding='utf-16')
assert '4 succeeded' in (bench/'prompt19_audit_build.log').read_text(encoding='utf-16')
data['verification']=dict(final_commit='The commit introducing this report',native_suites=47,python_cases=184,
    generator_cases=18,operation_inventory_cases=21,installed_consumer='PASS: C++11, installed prefix, no example include path',
    firmware_builds={key:'PASS' for key in ('bench_s3_units','bench_s3_probe','bench_s3_load_poll','bench_s3_load_timer')},
    fieldcore_read_only_commit='6debce7c44af9bc36f00fbcaccdfa47631846cce',
    target_sizes=dict(App=181024,Record=7768,Console=18448,Esp32S3Uart=1720,Runner=320,BusOwner=144,HostTuple=8,HostTiming=60,HostSnapshot=120),
    independent_review=['SDK/framing reviewer checked other-author final owner/CLI/tests and hardware report',
                        'Configuration-ownership reviewer checked other-author final adapter/fakes/Python against pinned SDK',
                        'CLI reviewer checked malformed mismatch failure disposition; lead reviewed integrated diff/evidence'],
    hardware=dict(host_only_sixteen_setups='PASS',strict_no_response_campaigns='FAIL: LENGTH/F9 and LENGTH/E5; retained failed artifacts',
        diagnostic_campaign_process='FAIL: zero cumulative UART-error assertion after deliberate parity mismatch; preserved',
        diagnostic_recovery_restore='PASS',unchanged_motor_readback='PASS',short_probe_regression='PASS',
        malformed_byte_uart_error_source='UNRESOLVED: missing raw UART error bitmap and wire measurement',
        alternate_motor_communication='NOT RUN',external_electrical_timing='NOT RUN',physical_sdk_failure_injection='NOT RUN'),
    offline_evidence_validation='PASS: matched raw readbacks, exact failure/restoration evidence, final original tuple/settled owner and ten checked probes; does not reclassify failed campaigns')
backup=bench/'co2control_com13_before.bin'; backup_hash=hashlib.sha256(backup.read_bytes()).hexdigest()
assert backup.stat().st_size==16777216 and backup_hash=='85c089bc3956b22037af7e6f0d7945f6ed778bb1a0526fb5b2ba3e8fea02d0c1'
data['original_backup']=dict(bytes=backup.stat().st_size,sha256=backup_hash,preserved=True)
path.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
members={}
for name in ('build','native_build','native_tests','python_tests','installed_tests','generator','inventory','version','catalogue','contrasts','upload','campaign','diagnose'):
    file=bench/('prompt19_audit_'+name+'.log'); members['run/'+file.name]=file.read_bytes()
for name in ('preflight.json','failed_campaign.json','failed_campaign.log','failed_19200_campaign.json','failed_19200_campaign.log','diagnose.json','preflight.py','campaign.py','diagnose.py','archive.py','timer_firmware.bin'):
    file=bench/('prompt19_audit_'+name); members['run/'+file.name]=file.read_bytes()
for file in (bench/'prompt19_sizes.py',bench/'ess_format_manual_page69.png',root/'build/audit19sdk/sdk_failure_repro.cpp',root/'build/audit19_owner/cross_cache.cpp',root/'build/audit19_owner/reverse_cache.cpp'):
    members['repro/'+file.name]=file.read_bytes()
members['run/evidence.json']=path.read_bytes()
members['run/report.md']=(reports/(stem+'.md')).read_bytes()
members['firmware/bench_s3_load_timer/firmware.elf']=(root/'.pio/build/bench_s3_load_timer/firmware.elf').read_bytes()
members['source/tracked_audit.diff']=subprocess.check_output(['git','diff','--','README.md','examples','scripts','test','docs',':!docs/reports'])
for relative in ('examples/common/HostSerial.h','examples/common/Esp32S3Uart.cpp','examples/probe_cli/main.cpp','test/host_app_test.cpp','test/driver_app_test.cpp','test/esp32_uart_test.cpp','test/bench_probe_test.py','test/fakes/esp32_uart/FakeEsp.cpp','scripts/bench_probe.py','docs/host_serial.md','docs/prompts/ess_release/19_host_serial_tuple_support.md','docs/prompts/ess_release/execution_contract.md'):
    members['source/'+relative]=(root/relative).read_bytes()
manifest={key:dict(bytes=len(value),sha256=hashlib.sha256(value).hexdigest()) for key,value in members.items()}
archive=reports/(stem+'.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as zipped:
    for key,value in members.items(): zipped.writestr(key,value)
    zipped.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as zipped:
    assert zipped.testzip() is None
    for key,item in manifest.items(): assert hashlib.sha256(zipped.read(key)).hexdigest()==item['sha256']
print('Offline evidence validation PASS; archive',archive.stat().st_size,'bytes;',len(manifest),'verified members')
