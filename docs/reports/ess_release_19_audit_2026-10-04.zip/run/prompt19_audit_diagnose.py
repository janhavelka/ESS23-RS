import json, sys, time
from pathlib import Path
sys.path.insert(0, 'scripts')
from bench_probe import Console, open_port

events=[]; snapshots={}
def log(kind, **data):
    events.append(dict(event=kind, host_monotonic_s=time.monotonic(), **data))
with open_port('COM13',115200,3) as port:
    original_write=port.write
    def write(data):
        log('exact_command_wire',wire=bytes(data).decode('ascii'))
        return original_write(data)
    port.write=write
    c=Console(port,on_event=log); snapshots['version']=c.identify()
    def inspect(label):
        for command in ('host','drv','stats','load','memory'):
            snapshots[label+'_'+command]=c.command(command)
    def recover_restore(label):
        # Explicit diagnostic settlement, not automatic replay after framing failure.
        snapshots[label+'_recover']=c.command('recover',timeout_s=3)
        assert snapshots[label+'_recover']['ok']
        snapshots[label+'_restore']=c.command('host',host_args=('restore',))
        assert snapshots[label+'_restore']['ok']
    inspect('failed_campaign')
    recover_restore('initial')
    for index in range(2):
        label='reproduction_'+str(index)
        snapshots[label+'_baseline']=c.command('probe',address=1,timeout_s=3)
        assert snapshots[label+'_baseline']['ok']
        snapshots[label+'_select']=c.command('host',host_args=('set','9600','8N1'))
        assert snapshots[label+'_select']['ok']
        snapshots[label+'_mismatch']=c.command('probe',address=1,timeout_s=3)
        inspect(label)
        assert not snapshots[label+'_mismatch']['ok']
        recover_restore(label)
        snapshots[label+'_restored_probe']=c.command('probe',address=1,timeout_s=3)
        assert snapshots[label+'_restored_probe']['ok']
    inspect('final')
Path('build/bench/prompt19_audit_diagnose.json').write_text(json.dumps(dict(snapshots=snapshots,events=events),indent=2)+'\n',encoding='utf-8')
for key,value in snapshots.items():
    if 'mismatch' in key or key.startswith('final_') or key=='failed_campaign_drv': print(key,json.dumps(value))
