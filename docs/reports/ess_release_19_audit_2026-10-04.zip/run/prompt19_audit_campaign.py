import hashlib,json,sys,time
from pathlib import Path
sys.path.insert(0,'scripts')
from bench_probe import Console,open_port,campaign,host_check_campaign

events=[]; snapshots={}
def log(kind,**data): events.append(dict(event=kind,host_monotonic_s=time.monotonic(),**data))
def read(c,command):
    item=c.command(command,address=1,timeout_s=3)
    assert item['ok'],item
    return item
def settings(c,command):
    item=c.command(command,driver_args=('read',),address=1,timeout_s=3)
    assert item['ok'],item
    return item

try:
    with open_port('COM13',115200,3) as port:
        original_write=port.write
        def write(data):
            log('exact_command_wire',wire=bytes(data).decode('ascii'))
            return original_write(data)
        port.write=write
        c=Console(port,on_event=log); snapshots['version']=c.identify()
        for command in ('host','config','load','drv','memory','stats'):
            snapshots['initial_'+command]=c.command(command)
        snapshots['host_capabilities']=c.command('host',host_args=('caps',))
        # Deliberate settlement of the retained failed19200 run, after inspection.
        snapshots['diagnostic_recovery']=c.command('recover',timeout_s=3)
        assert snapshots['diagnostic_recovery']['ok']
        snapshots['diagnostic_restore']=c.command('host',host_args=('restore',))
        assert snapshots['diagnostic_restore']['ok']
        assert all(not snapshots['initial_load'][key] for key in ('workload_us','owner_delay_us','console_bytes'))
        assert all(not snapshots['initial_drv'][key] for key in ('busy','transmit_enabled','pending','retained'))
        for command in ('read-identity','read-config','read-state'):
            snapshots['before_'+command]=read(c,command)
        for command in ('io','driver','control'):
            snapshots['before_'+command]=settings(c,command)

        # A terminal result may remain unread during a settled host change.
        handle=c.begin('probe',address=1,timeout_s=3)
        original=c.wait(handle)
        assert original['ok']; snapshots['historical_probe']=original
        snapshots['tuple_setups']=[]
        before_started=c.command('stats')['started']
        for baud in (9600,19200,38400,115200):
            for fmt in ('8N1','8N2','8E1','8O1'):
                selected=c.command('host',host_args=('set',str(baud),fmt))
                assert selected['ok'] and selected['active']==dict(baud=baud,format=fmt)
                snapshots['tuple_setups'].append(selected)
                # Serialization is passive and cannot reinterpret an old result.
                retained=c.command('result',operation_id=handle.operation_id)
                assert retained['host_serial']==original['host_serial']
                assert retained['transport']==original['transport']
        snapshots['tuple_restore']=c.command('host',host_args=('restore',))
        assert snapshots['tuple_restore']['ok']
        assert c.command('stats')['started']==before_started
        assert c.command('release',operation_id=handle.operation_id)['ok']
        snapshots['post_tuple_status']=c.command('status')
        assert snapshots['post_tuple_status']['raw_model'] is None
        assert not snapshots['post_tuple_status']['last_probe_known']

        # Diagnostic scenarios inspect actual transport failures. Unlike the
        # stricter production host-check, no claim of zero received bytes is
        # made: malformed traffic was reproduced and remains unqualified.
        for baud,fmt in ((9600,'8N1'),(38400,'8E1')):
            label='mismatch_'+str(baud)
            snapshots[label+'_baseline']=read(c,'probe')
            snapshots[label+'_select']=c.command('host',host_args=('set',str(baud),fmt))
            assert snapshots[label+'_select']['ok']
            terminal=c.command('probe',address=1,timeout_s=3)
            snapshots[label+'_terminal']=terminal
            assert not terminal['ok'] and terminal['outcome']=='transport'
            assert terminal['tx_bytes']==8 and terminal['codec']=='NOT_CHECKED'
            assert terminal['execution_unknown'] and terminal['raw_model'] is None
            snapshots[label+'_drv']=c.command('drv')
            snapshots[label+'_load']=c.command('load')
            snapshots[label+'_recover']=c.command('recover',timeout_s=3)
            assert snapshots[label+'_recover']['ok']
            snapshots[label+'_restore']=c.command('host',host_args=('restore',))
            assert snapshots[label+'_restore']['ok']
            snapshots[label+'_restored_probe']=read(c,'probe')
            snapshots['after_mismatch_'+str(baud)]=c.command('host')

        for command in ('read-identity','read-config','read-state'):
            snapshots['after_'+command]=read(c,command)
            assert [step['rx'] for step in snapshots['after_'+command]['steps']]==[step['rx'] for step in snapshots['before_'+command]['steps']]
        for command in ('io','driver','control'):
            snapshots['after_'+command]=settings(c,command)
            assert snapshots['after_'+command]['observation']==snapshots['before_'+command]['observation']
        campaign(c,'stress',count=10,interval_s=.05,timeout_s=3,address=1)
        for command in ('host','stats','load','drv','memory','status','health','caps'):
            snapshots['final_'+command]=c.command(command)
        assert snapshots['final_host']['active']==snapshots['initial_host']['original']
        assert all(not snapshots['final_drv'][key] for key in ('busy','transmit_enabled','recovery_required','pending','retained','reserved','input_dropped','output_blocked','output_short_writes'))
        assert snapshots['final_stats']['failed']-snapshots['initial_stats']['failed']==2
        assert all(not snapshots['final_stats'][key] for key in ('capture_faults','rx_errors','cancelled','echo_bytes','discarded'))
except BaseException as error:
    snapshots['campaign_error']=repr(error);raise
finally:
    image=Path('build/bench/prompt19_audit_timer_firmware.bin')
    Path('docs/reports/ess_release_19_audit_2026-10-04.json').write_text(json.dumps(dict(prompt=19,baseline_commit='1322cfd',preflight=json.loads(Path('build/bench/prompt19_audit_preflight.json').read_text()),firmware=dict(bytes=image.stat().st_size,sha256=hashlib.sha256(image.read_bytes()).hexdigest()),snapshots=snapshots,events=events),indent=2)+'\n',encoding='utf-8')
    print('Logged',len(events),'events',len(snapshots),'snapshots')
    for key in ('final_host','final_stats','final_memory','final_drv','final_load'):
        if key in snapshots: print(key,json.dumps(snapshots[key]))
