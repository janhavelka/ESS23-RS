﻿#include <MotorControlRS/profiles/ess_rs/Position.h>
#include <cstdio>
int main() { using namespace MotorControlRS::ESS_RS; std::printf("{\"MoveContext\":%zu,\"PreparedMove\":%zu,\"MovePrerequisites\":%zu}\n", sizeof(MoveContext), sizeof(PreparedMove), sizeof(MovePrerequisites)); }
