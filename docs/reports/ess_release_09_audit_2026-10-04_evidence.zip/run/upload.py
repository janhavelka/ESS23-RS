﻿from pathlib import Path
import subprocess,json,sys
sys.stdout.reconfigure(encoding='utf-8')
here=Path.cwd()/'build/bench/ess09_audit'
command=['cmd','/c','scripts\\pio.cmd','run','-e','bench_s3_load_timer','-t','upload','--upload-port','COM13']
p=subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
(here/'upload.log').write_bytes(p.stdout)
(here/'upload.json').write_text(json.dumps({'command':command,'exit':p.returncode},indent=2)+'\n')
print(p.stdout.decode('utf-8',errors='replace')[-2600:]); raise SystemExit(p.returncode)
