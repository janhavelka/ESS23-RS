﻿from pathlib import Path
import subprocess, json
root=Path.cwd(); here=root/'build/bench/ess09_audit'
command=['cmd','/c','scripts\\pio.cmd','run','-e','bench_s3_units','-e','bench_s3_probe','-e','bench_s3_load_poll','-e','bench_s3_load_timer']
p=subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
(here/'firmware-build.log').write_bytes(p.stdout)
(here/'firmware-build.json').write_text(json.dumps({'command':command,'exit':p.returncode},indent=2)+'\n')
print(p.stdout.decode('utf-8',errors='replace')[-4500:]); raise SystemExit(p.returncode)
