import hashlib
import json
from pathlib import Path
import sys
import time
from serial.tools import list_ports

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'scripts'))
from bench_probe import Console, Evidence, open_port, relative_move_campaign, BenchError
HERE = Path(__file__).resolve().parent
summary = {'physical_moves': 'NOT RUN', 'physical_dynamic_stop': 'NOT RUN',
           'reason': 'Independent timing/echo and sign/basis/ramp/input qualification absent'}
ports = [{'device': p.device, 'hwid': p.hwid, 'serial': p.serial_number, 'description': p.description}
         for p in list_ports.comports()]
summary['ports'] = ports
assert any(p['device'] == 'COM13' and '303A:1001' in p['hwid'] for p in ports)
with (HERE / 'final.jsonl').open('x', encoding='utf-8') as log, open_port('COM13', 115200, 3) as port:
    console = Console(port, on_event=Evidence(log))
    console.drain_startup(.5)
    summary['version'] = console.identify()
    def checked(command, **kwargs):
        result = console.command(command, **kwargs)
        assert result['ok'], result
        return result
    summary['config'] = checked('config')
    summary['stats_start'] = checked('stats')
    summary['load_before'] = checked('load')
    assert [summary['load_before'][k] for k in ('workload_us', 'owner_delay_us', 'console_bytes')] == [0, 0, 0]
    summary['caps'] = checked('caps')
    assert summary['caps']['motion'] and not summary['caps']['actions_qualified']
    summary['identity'] = checked('read-identity', address=1)
    summary['configuration_before'] = checked('read-config', address=1)
    summary['state_before'] = checked('read-state', address=1)
    summary['stats_before_gates'] = checked('stats')
    summary['move_gates'] = []
    for value in ('20', '-20'):
        result = console.command('move-relative', move_args=(value, 'steps', 'native', '60', 'configured'), address=1)
        assert not result['ok'] and result['result'] == 'timing_unqualified' and result['operation_id'] == 0, result
        summary['move_gates'].append(result)
    # Exercise the actual finite harness: a rejected move has no cleanup writes.
    try:
        relative_move_campaign(console, move_args=('20', 'steps', 'native', '60', 'configured'),
                               cleanup_stop='normal', timeout_s=3, address=1)
    except BenchError as exc:
        assert str(exc) == 'move rejected or failed: timing_unqualified'
        summary['finite_harness_gate'] = str(exc)
    else:
        raise AssertionError('Unqualified move was admitted')
    summary['action_gates'] = []
    for command, policy in [('enable', None), ('motor-release', None), ('alarm-clear', None), ('stop', 'normal'), ('stop', 'direct')]:
        result = console.command(command, address=1, stop_policy=policy)
        assert not result['ok'] and result['result'] == 'timing_unqualified' and result['operation_id'] == 0, result
        summary['action_gates'].append(result)
    summary['stats_after_gates'] = checked('stats')
    assert summary['stats_before_gates'] == {**summary['stats_after_gates'], 'id': summary['stats_before_gates']['id']}
    summary['capture_read'] = checked('capture-read', address=1)
    summary['probes'] = [checked('probe', address=1) for _ in range(10)]
    summary['state_after'] = checked('read-state', address=1)
    summary['configuration_after'] = checked('read-config', address=1)
    for name in ('configuration', 'state'):
        assert [x['rx'] for x in summary[name + '_before']['steps']] == [x['rx'] for x in summary[name + '_after']['steps']], name
    summary['cached_first'] = {name: checked(name) for name in ('status', 'health')}
    time.sleep(.05)
    summary['cached_second'] = {name: checked(name) for name in ('status', 'health')}
    for command in ('stats', 'memory', 'load', 'drv', 'caps'):
        summary['final_' + command] = checked(command)
    drv = summary['final_drv']
    assert not any(drv[k] for k in ('busy', 'transmit_enabled', 'recovery_required', 'pending', 'retained', 'reserved'))
    assert not summary['final_caps']['axis_reserved'] and not summary['final_load']['sample_gap_exceeded']
    assert summary['final_stats']['frames'] - summary['stats_start']['frames'] == 28
    assert summary['final_stats']['rx_bytes'] - summary['stats_start']['rx_bytes'] == 288
    summary['ok'] = True
image = ROOT / '.pio/build/bench_s3_load_timer/firmware.bin'
summary['firmware_bytes'] = image.stat().st_size
summary['firmware_sha256'] = hashlib.sha256(image.read_bytes()).hexdigest()
(HERE / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: summary[k] for k in ('ok', 'firmware_bytes', 'firmware_sha256', 'final_stats', 'final_memory', 'final_load', 'final_drv')}, indent=2))
