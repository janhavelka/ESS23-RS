﻿import hashlib,json,subprocess,zipfile,re
from pathlib import Path
root=Path.cwd(); here=root/'build/bench/ess09_audit'; reports=root/'docs/reports'; stem='ess_release_09_audit_2026-10-04'
sha=lambda data:hashlib.sha256(data).hexdigest()
summary={key:json.loads((here/name).read_text()) for key,name in [('preflight','preflight.json'),('campaign','summary.json'),('ending','ending.json'),('sizes','sizes.json'),('verification_commands','verify-final.json'),('firmware_build','firmware-build.json'),('upload','upload.json')]}
ending=summary['ending']; campaign=summary['campaign']
assert ending['stats']['frames']==38 and ending['stats']['rx_bytes']==358
for group,keys in [('stats',('failed','timeouts','cancelled','capture_faults','rx_errors','echo_bytes','discarded')),('drv',('busy','transmit_enabled','recovery_required','pending','retained','reserved','input_dropped','output_blocked','output_short_writes'))]:
    assert not any(ending[group][k] for k in keys)
assert ending['memory']['stack_free_bytes']==3604 and ending['load']['work_stack_free_bytes']==3268
assert [ending['load'][k] for k in ('workload_us','owner_delay_us','console_bytes')]==[0,0,0]
assert not ending['caps']['actions_qualified'] and not ending['caps']['axis_reserved']
for cmd in ('status','health'):
    for first,second in zip(campaign['cached_first'][cmd]['state_blocks'],campaign['cached_second'][cmd]['state_blocks']):
        assert first['observed_earliest_us']==second['observed_earliest_us'] and first['observed_latest_us']==second['observed_latest_us']
        assert second['age_us']>first['age_us']
for name in ('configuration','state'):
    assert [s['rx'] for s in campaign[name+'_before']['steps']]==[s['rx'] for s in campaign[name+'_after']['steps']]
for result in summary['verification_commands']: assert result['exit']==0
assert summary['firmware_build']['exit']==summary['upload']['exit']==0
probe_us=[p['duration_us'] for p in campaign['probes']]
summary['audit']={
 'baseline':'47e9575','final_commit':'The commit introducing this audit report and evidence',
 'native':{'result':'PASS','ctest_suites':23,'python_cases':137,'generator_cases':8,'inventory_cases':13,'compiler':'GCC15.1.0','language':'C++11','flags':'-Werror'},
 'installed_consumer':{'result':'PASS','tests':1,'example_include_path':False},
 'firmware_environments':{env:'PASS' for env in ('bench_s3_units','bench_s3_probe','bench_s3_load_poll','bench_s3_load_timer')},
 'hardware':{'readonly':'PASS','zero_TX_gates':'PASS','positive_negative_motion':'NOT RUN','independent_shaft_observation':'NOT RUN','dynamic_stop_latency':'NOT RUN'},
 'probe_runner_duration_us':{'minimum':min(probe_us),'maximum':max(probe_us)},
 'fieldcore_read_only_head':'7c356aff59132ab7ab7be6e3ec26a599ede6b99e',
 'public_layout_changed':False,'maximum_move_line_bytes':3995,'move_line_capacity':4096,
 'findings':['Immutable readiness budget across stage/trigger queue/setup/TX/closure and deferred expiry','Consumed coordinate reference evaluated at operation time and covering the write budget','Inclusive valid timestamp boundaries with strict retained evidence and poll correlation','Interrupted begin/wait poisons session and preserves unknown cleanup','Complete move callbacks required by help/caps'],
 'backup':{'bytes':16777216,'sha256':summary['preflight']['backup_sha256']},
 'owner_loop_frame_bytes':784,'historical_owner_loop_frame_bytes':768,
 'historical_stack_free_bytes':3636,'current_stack_free_bytes':3604,
 'scope':'Prompt09 fresh audit only; no motor settings/motion writes or physical claims; prompt10 not started'
}
(reports/(stem+'.json')).write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
(here/'audit.diff').write_bytes(subprocess.check_output(['git','diff','--','.',':!docs/reports/*']))
members={}
def add(path,name): members[name]=path.read_bytes()
for p in here.iterdir():
    if p.is_file() and p.suffix not in ('.exe','.o'): add(p,'run/'+p.name)
for directory in ('src','include','examples','scripts','test'):
    for p in (root/directory).rglob('*'):
        if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc': add(p,'source/'+p.relative_to(root).as_posix())
for name in ('CMakeLists.txt','platformio.ini','library.json','AGENTS.md','README.md','docs/ess_position.md','docs/ess_actions.md','docs/axis_contract.md','docs/profile_contract.md','docs/cli_contract.md','docs/hardware_bench.md','docs/backlog.md','docs/roadmap.md','docs/reference/ess_rs_operations.json','docs/reference/01_implementation_reference.md','docs/reference/09_timing_and_gap_audit.md','docs/prompts/ess_release/09_first_relative_motion.md','docs/prompts/ess_release/execution_contract.md','docs/prompts/ess_release/README.md'):
    add(root/name,'source/'+name)
for env in summary['audit']['firmware_environments']:
    for name in (('firmware.bin','firmware.elf') if env=='bench_s3_load_timer' else ('firmware.bin',)):
        add(root/'.pio/build'/env/name,'firmware/'+env+'/'+name)
for path,name in [('build/native/Testing/Temporary/LastTest.log','native.log'),('build/native/CMakeCache.txt','native_cache.txt'),('build/installed_consumer09/Testing/Temporary/LastTest.log','installed_consumer.log')]: add(root/path,'verification/'+name)
for p in (root/'build/bench/ess09').glob('manual_*.png'): add(p,'reference_review/'+p.name)
add(reports/(stem+'.md'),'report.md'); add(reports/(stem+'.json'),'report.json')
manifest={name:{'bytes':len(data),'sha256':sha(data)} for name,data in sorted(members.items())}
archive=reports/(stem+'_evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(members.items()): z.writestr(name,data)
    z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,expected in manifest.items():
        data=z.read(name); assert len(data)==expected['bytes'] and sha(data)==expected['sha256']
print(json.dumps({'bytes':archive.stat().st_size,'members':len(manifest),'sha256':sha(archive.read_bytes())}))
