﻿import subprocess,re,json
from pathlib import Path
root=Path.cwd(); here=root/'build/bench/ess09_audit'
p=subprocess.run(['C:/pio/packages/toolchain-xtensa-esp32s3/bin/xtensa-esp32s3-elf-objdump.exe','-d','-C','.pio/build/bench_s3_load_timer/firmware.elf'],stdout=subprocess.PIPE,check=True)
lines=p.stdout.decode('utf-8',errors='replace').splitlines(); frames=[]
for i,line in enumerate(lines):
    if re.match(r'^[0-9a-f]+ <.+>:$',line):
        for instruction in lines[i+1:i+4]:
            m=re.search(r'entry\s+a1,\s*(0x[0-9a-f]+|[0-9]+)',instruction)
            if m: frames.append((int(m.group(1), 0),line)); break
(here/'stack-frames.txt').write_text('\n'.join(str(size)+' '+name for size,name in sorted(frames,reverse=True))+'\n')
for size,name in frames:
    if name.endswith('<loop()>:') or 'prepareMoveRelative(' in name: print(size,name)

