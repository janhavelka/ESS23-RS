﻿import json, hashlib, sys
from pathlib import Path
from serial.tools import list_ports
root = Path.cwd()
here = root / 'build/bench/ess09_audit'
sys.path.insert(0, str(root / 'scripts'))
from bench_probe import Console, Evidence, open_port
ports = [{'device': p.device, 'hwid': p.hwid, 'serial': p.serial_number} for p in list_ports.comports()]
assert any(p['device'] == 'COM13' and '303A:1001' in p['hwid'] for p in ports)
with (here/'preflight.jsonl').open('x', encoding='utf-8') as log, open_port('COM13', 115200, 3) as port:
    c = Console(port, on_event=Evidence(log)); c.drain_startup(.5)
    data = {'ports': ports, 'version': c.identify()}
    for cmd in ('config','stats','load','drv','memory','caps'):
        data[cmd] = c.command(cmd); assert data[cmd]['ok']
backup = root/'build/bench/co2control_com13_before.bin'
data['backup_sha256'] = hashlib.sha256(backup.read_bytes()).hexdigest()
assert data['backup_sha256'] == '85c089bc3956b22037af7e6f0d7945f6ed778bb1a0526fb5b2ba3e8fea02d0c1'
(here/'preflight.json').write_text(json.dumps(data, indent=2)+'\n', encoding='utf-8')
print(json.dumps(data, indent=2))
