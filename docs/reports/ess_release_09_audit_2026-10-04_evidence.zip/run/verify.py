import json
import pathlib
import subprocess
root = pathlib.Path(__file__).resolve().parents[3]
here = pathlib.Path(__file__).resolve().parent
commands = [
 ['cmake','--build','build/native'],
 ['ctest','--test-dir','build/native','--output-on-failure'],
 ['python','test/generator_test.py'],
 ['python','test/bench_probe_test.py'],
 ['python','test/operations_inventory_test.py'],
 ['python','scripts/generate_version.py','check'],
 ['python','scripts/generate_ess_registers.py','--check'],
 ['python','scripts/prepare_serial_contrasts.py','--check'],
 ['cmake','--install','build/native','--prefix','build/install09'],
 ['cmake','--build','build/installed_consumer09'],
 ['ctest','--test-dir','build/installed_consumer09','--output-on-failure'],
 ['git','diff','--check'],
]
results=[]
with (here/'verify-final.log').open('wb') as log:
 for command in commands:
  p=subprocess.run(command,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  log.write(('COMMAND '+repr(command)+'\n').encode()); log.write(p.stdout)
  results.append({'command':command,'exit':p.returncode})
  print('PASS' if p.returncode==0 else 'FAIL', ' '.join(command))
  if p.returncode:
   print(p.stdout.decode('utf-8',errors='replace')); raise SystemExit(p.returncode)
(here/'verify-final.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
