import sys
from pathlib import Path
sys.path.insert(0,str(Path('scripts').resolve()))
from bench_session import run_recorded,checked
from bench_probe import BenchError
from bench_motion import profile_snapshot

def finish(console,record):
    record['profile']=profile_snapshot(console)
    record['control']=checked(console,'control',driver_args=('read',))
    record['state']=checked(console,'read-state',address=1)
    record['end']={key:checked(console,key) for key in ('host','drv','status','monitor','debug','load','memory','stats')}
    end=record['end']; drv=end['drv']; state=record['state']['state_blocks']
    if (drv['busy'] or drv['transmit_enabled'] or drv['recovery_required'] or any(drv[k] for k in ('pending','retained','reserved')) or state[0]['raw_alarm'] or state[0]['running'] or state[2]['raw_speed'] or end['status']['monitoring']!='disabled' or any(end['load'][k] for k in ('workload_us','owner_delay_us','console_bytes'))):
        raise BenchError('final bench is not settled')
    record['workload_verified']=True
run_recorded(port='COM13',out='build/bench/p30-audit-ending-01',scenario='candidate-audit-ending',inputs={'motor_writes':False},run=finish,refresh=False)
