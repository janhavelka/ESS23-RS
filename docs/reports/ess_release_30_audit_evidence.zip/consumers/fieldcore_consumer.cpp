﻿#include <MotorControlRS/MotorControlRS.h>
#include <MotorControlRS/profiles/ess_rs/Discovery.h>
#include <MotorControlRS/profiles/ess_rs/Position.h>
#include <TunnelMonitor/rs485/Rs485OwnerTransaction.h>
#include <TunnelMonitor/rs485/Rs485DeviceBinding.h>
#include <TunnelMonitor/rs485/Rs485Backend.h>
#include <type_traits>
static_assert(!std::is_same<MotorControlRS::Status, TunnelMonitor::ErrorDetail>::value, "independent statuses");
static_assert(!std::is_same<MotorControlRS::ReadTarget, TunnelMonitor::DeviceCommand>::value, "independent requests");
int main() {
    MotorControlRS::ReadTarget target; target.id=1; target.address=1; target.generation=1;
    MotorControlRS::ESS_RS::PreparedProbe work;
    const MotorControlRS::Status status = MotorControlRS::prepareProbe(work, MotorControlRS::DriveProfile::ESS_RS, target,1,100,100000);
    TunnelMonitor::Rs485BusTransaction transaction{};
    return status && work.length==8 && sizeof(transaction.txBytes)==8 ? 0 : 1;
}
