#include <MotorControlRS/profiles/ess_rs/Discovery.h>
int main() {
    MotorControlRS::ReadTarget target;
    target.id = 1;
    target.address = 1;
    target.generation = 1;
    MotorControlRS::ESS_RS::PreparedProbe probe;
    MotorControlRS::Status status = MotorControlRS::prepareProbe(
        probe, MotorControlRS::DriveProfile::ESS_RS, target, 1, 100, 100000);
    // On success, probe.bytes[0..probe.length) is one FC03 request. No I/O occurred.
    return status && probe.length == 8 ? 0 : 1;
}
