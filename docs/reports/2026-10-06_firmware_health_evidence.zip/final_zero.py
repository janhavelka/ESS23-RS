import sys,time,re
from pathlib import Path
sys.path.insert(0,'scripts')
from bench_session import run_recorded,checked
from bench_probe import BenchError,observe_stopped

def run(c,r):
    r['config']=checked(c,'read-config',address=1)
    r['initial']=observe_stopped(c,address=1,timeout_s=5)
    assert r['initial']['state_blocks'][2]['pair_known']
    c.emit('human_command',text='moveto 0 deg')
    c.port.write(b'moveto 0 deg\n')
    end=time.monotonic()+12
    data=bytearray()
    while time.monotonic()<end:
        data.extend(c.port.read(2048))
        if len(data)>8192:
            c.synchronized=False
            raise BenchError('human reply limit exceeded')
        if re.search(rb'Details: @1 result \d+\.\r?\n',data):
            break
        time.sleep(.005)
    else:
        c.synchronized=False
        raise BenchError('human reply timeout')
    text=data.decode()
    c.emit('human_output',text=text)
    r['zero']=text
    assert 'Requested target already satisfied' in text
    assert 'No new motion command was sent' in text
    operation=int(re.search(r'operation (\d+)',text).group(1))
    r['release']=checked(c,'release',operation_id=operation)
    r['axis']=checked(c,'axis',host_args=('config',))
    r['final']=observe_stopped(c,address=1,timeout_s=5)
    assert r['axis']['origin_native']==r['initial']['state_blocks'][2]['raw_position']
    r['workload_verified']=True

run_recorded(port='COM13',out=Path(sys.argv[1]),scenario='controller-reset-session-zero',inputs={'motor_writes':0,'request':'moveto 0 deg'},run=run,refresh=False,firmware=Path('build/firmware_health/pio/bench_s3_load_timer/firmware.bin'))
