// Temporary HIL fixture: real application, one deliberately blocked owner,
// no UART requests/motor commands. Restored to ordinary firmware after testing.
#include "../probe_cli/ProbeApp.h"
#include "../common/BoardPins.h"
#include <esp_system.h>
#include <esp_timer.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
using namespace MotorControlRSExample;
static bool inject = false;
void setup() {
    inject = esp_reset_reason() != ESP_RST_TASK_WDT;
    beginApplication({Board::kRs485TxPin, Board::kRs485RxPin, Board::kRs485DeRePin,
                      Board::kRs485DeReActiveHigh}, Board::kRs485ReceiverDisabledDuringTransmit);
}
void loop() {
    serviceApplication();
    if (inject && esp_timer_get_time() > 3000000) {
        for (;;) vTaskDelay(1); // CPU/idle keep running, only the owner stops progressing.
    }
}
