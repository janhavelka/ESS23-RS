import json,sys,time
from pathlib import Path
sys.path.insert(0,'scripts')
from bench_probe import Console,open_port
from serial.tools import list_ports
result={'usb':[dict(device=p.device,vid=p.vid,pid=p.pid,serial=p.serial_number) for p in list_ports.comports() if p.device=='COM13']};events=[]
def log(kind,**data): events.append(dict(event=kind,host_monotonic_s=time.monotonic(),**data))
try:
    with open_port('COM13',115200,3) as port:
        c=Console(port,on_event=log);result['version']=c.identify()
        for command in ('host','config','load','monitor','drv','stats','memory'):
            result[command]=c.command(command)
        assert result['host']['active']==dict(baud=115200,format='8N1') and not result['host']['blocked']
        assert not result['drv']['busy'] and not result['drv']['transmit_enabled'] and not result['drv']['recovery_required']
        assert not result['monitor']['enabled']
        assert all(not result['load'][k] for k in ('workload_us','owner_delay_us','console_bytes'))
except BaseException as error:
    result['error']=repr(error);raise
finally:
    result['events']=events
    Path('build/bench/functional_motion/preflight.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='events'},indent=2))
