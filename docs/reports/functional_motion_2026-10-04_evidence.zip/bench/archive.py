﻿import hashlib, json, pathlib, subprocess, zipfile
root=pathlib.Path.cwd()
bench=root/'build/bench/functional_motion'
report=root/'docs/reports'
phases={p.stem:json.loads(p.read_text()) for p in sorted(bench.glob('final_*.json'))}
status=phases['final_status']
summary=dict(baseline='c7b53d4', final_revision='commit introducing this artifact',
 firmware_sha256=hashlib.sha256((bench/'final_firmware.bin').read_bytes()).hexdigest(),
 firmware_bytes=(bench/'final_firmware.bin').stat().st_size,
 final_phases={k:dict(ok=v['ok'],before=v.get('state_before'),after=v.get('state_after'),move=v.get('move'),restore=v.get('restore')) for k,v in phases.items()},
 final_stats=status['ending_stats'],final_load=status['ending_load'],final_memory=status['ending_memory'],
 final_driver=status['ending_drv'],final_host=status['ending_host'],
 configuration_restored=phases['final_inspect']['configuration_before']['config']==status['configuration_before']['config'],
 first_failure=json.loads((bench/'forward.json').read_text()),
 verification=dict(ctest='54/54 PASS',python_protocol='191 PASS',python_campaign='17 PASS',generator='18 PASS',firmware='5/5 PASS',installed_consumers='C++11/C++17 PASS'),
 electrical_timing='unmeasured',independent_shaft_observation='unmeasured',hours_soak='NOT RUN by user request')
(report/'functional_motion_2026-10-04.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
changed=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
entries={}
for p in sorted(bench.iterdir()):
 if p.is_file(): entries['bench/'+p.name]=p.read_bytes()
for name in sorted(set(changed+untracked)):
 if name.endswith('.zip'): continue
 p=root/name
 if p.is_file(): entries['source/'+name]=p.read_bytes()
entries['working.diff']=subprocess.check_output(['git','diff','--no-ext-diff'],stderr=subprocess.DEVNULL)
manifest={k:dict(bytes=len(v),sha256=hashlib.sha256(v).hexdigest()) for k,v in entries.items()}
with zipfile.ZipFile(report/'functional_motion_2026-10-04_evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for k,v in entries.items(): z.writestr(k,v)
 z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
print(len(entries),'artifacts archived; configuration equal:',summary['configuration_restored'])
