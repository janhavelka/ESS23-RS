import sys
sys.path.insert(0,'scripts')
from bench_session import run_recorded,checked
def ending(console,record):
    record['profile']=checked(console,'motion-profile',host_args=('inspect',))
    record['debug_status']=checked(console,'debug')
    record['monitor_status']=checked(console,'monitor')
    if not record['profile']['restored'] or record['profile']['current'] != record['profile']['original']:
        raise ValueError('exact original session profile not retained')
    record['workload_verified']=True
run_recorded(port='COM13',out='build/p24/ending-02',scenario='passive-ending-evidence',inputs={'motor_reads':0,'motor_writes':0},run=ending,refresh=False,firmware='.pio/build/bench_s3_load_timer/firmware.bin')
