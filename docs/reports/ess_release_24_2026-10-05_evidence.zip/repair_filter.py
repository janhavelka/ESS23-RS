import sys
sys.path.insert(0, 'scripts')
from bench_session import checked, run_recorded
from bench_probe import observe_stopped
def repair(console, record):
    record['filters']=checked(console,'tuning',driver_args=('filters','read'),address=1)
    record['io']=checked(console,'io',driver_args=('read',),address=1)
    if record['filters']['observation']['raw'][0] != 3:
        raise ValueError('known applied filter3 required; no repair write')
    observe_stopped(console,address=1,timeout_s=5)
    record['repair']=checked(console,'tuning',driver_args=('filters','set','input-filter','2'),address=1)
    record['after_filters']=checked(console,'tuning',driver_args=('filters','read'),address=1)
    if record['after_filters']['observation']['raw'][0]!=2: raise ValueError('restoration disagrees')
    record['workload_verified']=True
run_recorded(port='COM13',out='build/p24/filter-repair-02',scenario='explicit-known-filter-restoration',inputs={'from':3,'to':2,'source':'filter-02 checked application; refused restoration was not admitted'},run=repair,firmware='.pio/build/bench_s3_load_timer/firmware.bin')
