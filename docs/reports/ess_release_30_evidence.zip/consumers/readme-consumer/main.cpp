#include <MotorControlRS/profiles/ess_rs/Codec.h>
int main() {
    uint8_t bytes[8] = {};
    return MotorControlRS::ESS_RS::buildProbe(1, bytes, sizeof(bytes)) == 8 ? 0 : 1;
}
