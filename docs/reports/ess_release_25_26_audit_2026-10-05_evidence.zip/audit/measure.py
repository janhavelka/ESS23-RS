import hashlib
import json
from pathlib import Path

base = Path('build/audit2526')
def read(name):
    return json.loads((base / (name + '.json')).read_text())

def delta(start, end):
    before, after = read(start)['before']['stats'], read(end)['after']['stats']
    snapshot = read(end)['after']
    steps = [step for kind in ('identity', 'config', 'state')
             for step in snapshot.get(kind, {}).get('steps', [])]
    assert all(step['status'] == 'OK' for step in steps)
    frames, rx = len(steps), sum(step['received_length'] for step in steps)
    return {'started': after['started'] + frames - before['started'],
            'frames': after['frames'] + frames - before['frames'],
            'failed': after['failed'] - before['failed'],
            'rx_bytes': after['rx_bytes'] + rx - before['rx_bytes'],
            'reads_after_stats': frames, 'rx_after_stats': rx,
            'provenance': 'One boot, stats difference plus actual final explicit read steps after stats; no counter reset'}

record = dict(baseline_commit='b4f91b98d7147562a46306454ae158bb86e4a9e0', prompts=[25, 26],
              revision='commit containing this report', platforms={},
              verification={'ctest_suites': 69, 'ctest': 'PASS', 'python_probe_cases': 233,
                            'generator_version_register_contrast': 'PASS',
                            'three_arduino_builds': 'PASS', 'clean_native_idf': 'PASS',
                            'actual_sdk_forced_debug_negative_compile': 'PASS (expected rejection)',
                            'installed_all27_header_runtime_consumer': 'PASS',
                            'clean_core_component_s3_s2': 'compile/link PASS; not hardware',
                            'clean_portable_owner_console_s2': 'compile/link PASS; not hardware',
                            'reset_under_uncertain_tx_and_blocked_output': 'both real application adapters PASS'},
              fixes=['Reject forced GPTimer debug logging, which bypasses global SDK log filtering',
                     'Regression covers ordinary reset preserving unknown trigger, recovery interlock and DE settlement',
                     'Narrow USB input-discard counter claims; correct stale current architecture/board text'],
              qualification='short functional drive-report evidence; no independent physical/electrical measurement',
              fieldcore={'commit': 'd19758865852f4e215ea05c6572d060edc4f0c66', 'access': 'read-only',
                         'differences': 'sensor TX8/prefix echo stripping/retry vocabulary; standalone TX32/checked replies/retained uncertainty'},
              backup={'path': 'build/p25/original-image/flash-16mb-v4.bin',
                      'sha256': '09b0700e6b4f392e9bc3dbf4d935029cdacd0d2fe3d96d2be1613614680ea408',
                      'preserved': True, 'rollback': 'NOT RUN'},
              remaining=['USB RX saturation/loss visibility', 'independent shaft/electrical measurements',
                         'endurance', 'S2 hardware/adapter', 'external switches/loads/homing/segments',
                         'unqualified negative/continuous velocity/linear motion', 'restart/persistence',
                         'other SDKs/tuples', 'earlier owning-prompt native-family gaps'])

for platform, prefix, image, ending in [
    ('arduino', 'arduino', Path('build/p26/arduino-image/firmware.bin'), 'arduino-ending'),
    ('idf', 'idf2', base / 'idf-image/motorcontrol_probe.bin', 'idf2-final')]:
    final = read(ending)['after']
    assert final['drv']['pending'] == final['drv']['reserved'] == final['drv']['retained'] == 0
    assert not final['drv']['transmit_enabled'] and not final['drv']['recovery_required']
    assert not final['host']['blocked'] and final['host']['active'] == {'baud': 115200, 'format': '8N1'}
    assert [final['load'][k] for k in ('workload_us', 'owner_delay_us', 'console_bytes')] == [0, 0, 0]
    blocks = {b['block']: b for b in final['state']['state_blocks']}
    assert not blocks[0]['raw_alarm'] and not blocks[0]['running'] and blocks[2]['raw_speed'] == 0
    out = {'image_sha256': hashlib.sha256(image.read_bytes()).hexdigest(), 'image_bytes': image.stat().st_size,
           'sdk': 'ESP-IDF5.5.5', 'framework': 'Arduino3.3.11/pioarduino55.03.311' if platform == 'arduino' else 'Native ESP-IDF5.5.5',
           'tuple': 'requested115200 8N1; divider-reported115211 baud',
           'final': final, 'quick_latency_us': read(prefix + '-quick')['campaigns'][0]['latency_us'],
           'loaded': {}, 'motion': {}, 'fault': read(prefix + '-fault-mismatch')['negative']}
    for shape in ('probe', 'capture-read'):
        campaign = read(prefix + '-capture-' + shape)
        assert campaign['ok'] and not campaign['window']['sample_gap_exceeded']
        out['loaded'][shape] = {'latency_us': campaign['campaigns'][0]['latency_us'], 'window': campaign['window'],
                               'console_level_discards': campaign['after']['drv']['input_dropped'],
                               'usb_rx_transport_loss': 'unmeasured; SDK does not expose overflow'}
    for phase in (('position-ready', 'stop', 'stop-normal') if platform == 'arduino' else ('position', 'stop-direct', 'stop-normal')):
        campaign = read(prefix + '-' + phase)
        assert campaign['ok']
        motion = campaign['motion']
        out['motion'][phase] = {key: motion[key] for key in
            ('move', 'state_before', 'state_after', 'cleanup', 'restoration') if key in motion}
    settings = read(prefix + '-settings')
    assert settings['ok']
    out['setting'] = settings['setting']
    out['counter_segments'] = ([delta('arduino-quick', 'arduino-fault-mismatch'),
                                delta('arduino-restored-quick', 'arduino-final'),
                                delta('arduino-ending', 'arduino-ending')]
                               if platform == 'arduino' else [delta('idf2-quick', 'idf2-final')])
    record['platforms'][platform] = out

record['retained_rejected_attempt'] = {'file': 'arduino-position.jsonl', 'outcome': 'FAIL before any motion/profile write',
    'cause': 'previous restored local snapshot retained old host/binding generation; motion-profile read correctly refused',
    'diagnosis': read('arduino-snapshot-release')['retained_snapshot'],
    'resolution': 'explicit inspect verifies known/restored snapshot; local forget; new checked snapshot and finite scenario',
    'automatic_motor_replay': False}
record['intermediate_native_build'] = {'prefix': 'idf-*',
    'image_sha256': 'ef9373aa50385c39891bc2721f6ede5ede844f785e0aa418c37a16111ace83d0',
    'disposition': 'pre-final-comment incremental build; raw evidence retained, image not separately retained; final image qualification uses idf2-* only'}
record['ending'] = {'platform': 'Arduino', 'raw_position': 3644, 'profile': [30,100,100,60,0,250],
    'lock_delay': 200, 'load': [0,0,0], 'debug': 'off', 'monitor': 'off',
    'standstill': 'fresh drive reports alarm0/runningfalse/raw_speed0; independent observation unmeasured'}
target = Path('docs/reports/ess_release_25_26_audit_2026-10-05.json')
target.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
for name, platform in record['platforms'].items():
    print(name, platform['counter_segments'], platform['final']['state']['state_blocks'][2]['raw_position'])
