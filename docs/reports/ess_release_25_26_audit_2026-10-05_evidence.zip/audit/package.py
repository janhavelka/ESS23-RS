from pathlib import Path
import hashlib
import json
import zipfile

base = Path('build/audit2526')
reports = Path('docs/reports')
files = {p: 'audit/' + p.name for p in base.iterdir() if p.is_file()}
for p in (base / 'idf-image').iterdir():
    if p.is_file():
        files[p] = 'idf-image/' + p.name
for name in ('firmware.bin', 'firmware.elf'):
    files[Path('build/p26/arduino-image') / name] = 'arduino-image/' + name
for folder, binary in [('core-esp32s3', 'motorcontrol_core_consumer.bin'),
                       ('core-esp32s2', 'motorcontrol_core_consumer.bin'),
                       ('s2-portable', 'motorcontrol_portable_consumer.bin')]:
    for name in (binary, 'sdkconfig', 'compile_commands.json', 'project_description.json'):
        files[base / folder / name] = folder + '/' + name
files[base / 'installed-consumer/compile_commands.json'] = 'installed-consumer/compile_commands.json'
files[base / 'idf-clean/compile_commands.json'] = 'idf-image/compile_commands.json'
for name in ('sdkconfig', 'config/sdkconfig.h', 'compile_commands.json'):
    files[base / 'idf-debug-rejected' / name] = 'rejected-sdk-config/' + name
for name, source in [
    ('qio_opi/sdkconfig.h', 'C:/pio/packages/framework-arduinoespressif32-libs/esp32s3/qio_opi/include/sdkconfig.h'),
    ('versions.txt', 'C:/pio/packages/framework-arduinoespressif32-libs/versions.txt'),
    ('framework-package.json', 'C:/pio/packages/framework-arduinoespressif32/package.json'),
    ('platformio.ini', 'platformio.ini'), ('board.json', 'boards/bench_s3_n16r8.json')]:
    files[Path(source)] = 'arduino-image/' + name
files[Path('build/p25/idf-tools/espidf.constraints.v5.5.txt')] = 'tools/espidf.constraints.v5.5.txt'
for name in ('ess_release_25_26_audit_2026-10-05.md', 'ess_release_25_26_audit_2026-10-05.json',
             'ess_release_26_2026-10-05.md'):
    files[reports / name] = 'reports/' + name
for source in ('examples/probe_idf/main/IdfPlatform.cpp', 'examples/probe_idf/main/main.cpp',
               'examples/probe_idf/sdkconfig.defaults', 'examples/probe_cli/ProbePlatform.h',
               'examples/probe_cli/ArduinoPlatform.cpp', 'test/idf_config_test.py', 'test/move_app_test.cpp',
               'scripts/bench_scenarios.py', 'scripts/bench_motion.py', 'scripts/bench_probe.py',
               'scripts/bench_session.py', 'test/idf_consumer/README.md', 'test/portability_consumer/README.md'):
    files[Path(source)] = 'source/' + source

manifest = []
archive = reports / 'ess_release_25_26_audit_2026-10-05_evidence.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as output:
    for path, name in sorted(files.items(), key=lambda pair: pair[1]):
        data = path.read_bytes()
        output.writestr(name, data)
        manifest.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    output.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None
    assert set(check.namelist()) == {row['path'] for row in manifest} | {'manifest.json'}
    for row in manifest:
        data = check.read(row['path'])
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
print('Verified archive:', len(manifest), 'payloads;', archive.stat().st_size, 'bytes')
