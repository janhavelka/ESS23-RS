import sys
sys.path.insert(0, 'scripts')
import bench_probe as probe
from bench_session import run_recorded, checked

platform, image, shape = sys.argv[1:]
load = (2000, 5000, 128)
def run(console, record):
    original = tuple(record['before']['load'][name] for name in probe.LOAD_FIELDS)
    try:
        probe.campaign(console, mode='load', count=10, interval_s=.05,
                       timeout_s=5, load=load, read_command=shape)
        record['window'] = checked(console, 'load')
        record['workload_verified'] = True
    finally:
        if console.synchronized:
            record['load_restore'] = checked(console, 'load', load=original)
run_recorded(port='COM13', out=f'build/audit2526/{platform}-capture-{shape}',
             scenario='capture-load', inputs={'load':load, 'read_command':shape, 'count':10},
             run=run, firmware=image, debug='decoded')
