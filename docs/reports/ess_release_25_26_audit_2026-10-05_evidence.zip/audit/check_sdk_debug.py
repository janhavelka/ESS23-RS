import json
from pathlib import Path
import subprocess

build = Path('build/audit2526/idf-debug-rejected').resolve()
config = (build / 'config/sdkconfig.h').read_text()
assert '#define CONFIG_GPTIMER_ENABLE_DEBUG_LOG 1' in config
assert '#define CONFIG_LOG_DEFAULT_LEVEL 0' in config
commands = json.loads((build / 'compile_commands.json').read_text())
row = next(row for row in commands if row['file'].endswith('IdfPlatform.cpp'))
(build / 'esp-idf/main/CMakeFiles/__idf_main.dir').mkdir(parents=True, exist_ok=True)
result = subprocess.run(row['command'], cwd=row['directory'], capture_output=True, text=True)
(build.parent / 'idf-debug-rejected.log').write_text(result.stdout + result.stderr)
assert result.returncode != 0, 'Unsafe actual SDK configuration compiled'
assert 'SDK logging must remain disabled' in result.stderr, result.stderr
print('Actual IDF5.5.5 generated configuration: global logging0, GPTimer debug1; adapter rejected')
