import sys
sys.path.insert(0, 'scripts')
from bench_session import run_recorded, checked

def run(console, record):
    view = checked(console, 'motion-profile', host_args=('inspect',))
    record['retained_snapshot'] = view
    assert view['saved'] and view['restored'] and not view['pending'] and not view['execution_unknown']
    assert not record['before']['drv']['pending'] and not record['before']['drv']['reserved']
    record['release'] = checked(console, 'motion-profile', host_args=('forget',))
    assert not record['release']['saved']
    record['workload_verified'] = True

run_recorded(port='COM13', out='build/audit2526/arduino-snapshot-release',
             scenario='explicit-local-restored-snapshot-release',
             inputs={'commands': ['motion-profile inspect', 'motion-profile forget'], 'motor_writes': 0},
             run=run, refresh=False, firmware='build/p26/arduino-image/firmware.bin')
