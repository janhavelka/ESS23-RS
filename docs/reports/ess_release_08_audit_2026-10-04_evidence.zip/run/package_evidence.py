import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
REPORTS = ROOT / 'docs/reports'
STEM = 'ess_release_08_audit_2026-10-04'

def sha(data):
    return hashlib.sha256(data).hexdigest()

verification = {
    'baseline': '980a4d94f56bd3ddc65a1a046328e8fed66fe67b',
    'final_commit': 'The commit introducing this evidence',
    'scope': 'Fresh prompt08 audit; no prompt09 implementation or physical motor write',
    'native': {'result': 'PASS', 'suites': 21, 'compiler': 'GCC 15.1.0', 'flags': '-Werror',
               'python_harness_cases': 123, 'inventory_negative_cases': 13},
    'generator_negative_suite': {'result': 'PASS', 'cases': 8},
    'contrast_snapshots': {'result': 'PASS', 'references': 5},
    'installed_consumer': {'result': 'PASS', 'tests': 1},
    'firmware': {env: 'PASS' for env in ('bench_s3_units', 'bench_s3_probe', 'bench_s3_load_poll', 'bench_s3_load_timer')},
    'hardware': {'read_only': 'PASS', 'action_rejection_without_TX': 'PASS',
                 'independent_TX_RX_DE_and_FC06_echo': 'NOT RUN', 'physical_actions': 'NOT RUN', 'motion': 'NOT RUN'},
    'backup': {'bytes': 16777216, 'sha256': '85c089bc3956b22037af7e6f0d7945f6ed778bb1a0526fb5b2ba3e8fea02d0c1'},
    'fieldcore_read_only_commit': '47f52e5519725ee16a43da576f4ba52d78b50551',
    'host_verification_notes': [
        'Initial CTest regex incorrectly used executable suffixes and selected zero tests; corrected before the full21 run.',
        'Initial new app fixtures failed release assertion because no console delivery correlation was registered; fixed CLI routes, rebuilt, both tests and full suite passed.',
        'PowerShell stderr wrapper reported failure despite four PIO successes. Python actual exit check passed0 after replacing a relative batch path with an absolute path.',
        'Upload completed with verified data/SUCCESS. Host CP1252 printing then raised UnicodeEncodeError; raw UTF8 upload.log retained, no repeat flash.',
        'Non-author review corrected harness FrameError::EXCEPTION from0 to10 before final suite.',
    ],
}
(HERE / 'verification.json').write_text(json.dumps(verification, indent=2) + '\n', encoding='utf-8')
summary = {name: json.loads((HERE / filename).read_text(encoding='utf-8')) for name, filename in
           [('preflight', 'preflight.json'), ('campaign', 'summary.json'), ('ending', 'ending.json'), ('verification', 'verification.json')]}
assert summary['ending']['stats']['frames'] == 38
assert summary['ending']['stats']['rx_bytes'] == 358
assert not any(summary['ending']['stats'][name] for name in ('failed', 'timeouts', 'cancelled', 'capture_faults', 'rx_errors'))
(REPORTS / (STEM + '.json')).write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
diff = subprocess.run(['git', 'diff', '--', '.', ':!docs/reports/*'], cwd=ROOT, check=True, stdout=subprocess.PIPE).stdout
(HERE / 'audit.diff').write_bytes(diff)

members = {}
def add(path, name):
    members[name] = path.read_bytes()

for path in HERE.iterdir():
    if path.is_file():
        add(path, 'run/' + path.name)
for folder in ('src', 'include', 'examples', 'scripts', 'test'):
    for path in (ROOT / folder).rglob('*'):
        if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc':
            add(path, 'source/' + path.relative_to(ROOT).as_posix())
for filename in ('CMakeLists.txt', 'platformio.ini', 'library.properties', 'library.json', 'AGENTS.md',
                 'README.md', 'docs/ess_actions.md', 'docs/profile_contract.md',
                 'docs/prompts/ess_release/08_operations_enable_release_and_stop.md',
                 'docs/prompts/ess_release/execution_contract.md', 'docs/axis_contract.md'):
    path = ROOT / filename
    if path.exists(): add(path, 'source/' + filename)
for env in verification['firmware']:
    for name in (('firmware.bin', 'firmware.elf') if env == 'bench_s3_load_timer' else ('firmware.bin',)):
        add(ROOT / '.pio/build' / env / name, 'firmware/' + env + '/' + name)
for path, name in [('build/native/Testing/Temporary/LastTest.log', 'native_final.log'),
                   ('build/native/CMakeCache.txt', 'native_cache.txt'),
                   ('build/installed_consumer_audit08/Testing/Temporary/LastTest.log', 'installed_consumer.log')]:
    add(ROOT / path, 'verification/' + name)
add(REPORTS / (STEM + '.md'), 'report.md')
manifest = {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(members.items())}
archive = REPORTS / (STEM + '_evidence.zip')
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as out:
    for name, data in sorted(members.items()): out.writestr(name, data)
    out.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive) as out:
    assert out.testzip() is None
    for name, expected in manifest.items():
        data = out.read(name)
        assert len(data) == expected['bytes'] and sha(data) == expected['sha256']
print(json.dumps({'archive_bytes': archive.stat().st_size, 'members': len(manifest), 'sha256': sha(archive.read_bytes())}))
