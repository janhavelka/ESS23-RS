import sys
from pathlib import Path
sys.path.insert(0,'scripts')
from bench_session import run_recorded,checked

def run(c,r):
    r['axis']=checked(c,'axis',host_args=('config',))
    r['profile']=checked(c,'motion-profile',host_args=('inspect',))
    r['retained']=[]
    latest=r['before']['drv']['operation_id']
    for op in range(max(1,latest-24),latest+1):
        result=c.command('result',operation_id=op)
        if result.get('ok'): r['retained'].append(result)
    r['workload_verified']=True
run_recorded(port='COM13',out=Path(sys.argv[1]),scenario='preflash-cached-only',inputs={'motor_writes':0,'motor_reads':0},run=run,refresh=False)
