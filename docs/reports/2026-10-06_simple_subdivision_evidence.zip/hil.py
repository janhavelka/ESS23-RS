import re,sys,time
from pathlib import Path
sys.path.insert(0,'scripts')
from bench_session import run_recorded,checked
from bench_probe import BenchError,observe_stopped,FAULT_TEXT
from bench_motion import profile_snapshot,restore_profile

def human(c,text,end):
    assert not c.pending and not c.buffer
    c.emit('human_command',text=text); c.port.write((text+'\n').encode())
    deadline=time.monotonic()+15; raw=bytearray(); quiet=deadline
    while time.monotonic()<deadline:
        part=c.port.read(4096)
        if part: raw.extend(part);quiet=time.monotonic()+.05
        output=raw.decode('utf-8')
        if len(raw)>32768 or FAULT_TEXT.search(output):
            c.synchronized=False; raise BenchError('fault/oversized human output')
        if end(output) and time.monotonic()>quiet:
            c.emit('human_output',text=output); print(output,flush=True)
            if '[ERROR]' in output or 'failed' in output.lower() or 'not confirmed' in output.lower():
                raise BenchError('human operation rejected/failed; no replay')
            return output
        time.sleep(.005)
    c.emit('human_incomplete',text=raw.decode(errors='replace'));c.synchronized=False
    raise BenchError('human timeout; no replay')

def subdivision(c,value=None):
    text='subdivision' if value is None else f'subdivision {value}'
    out=human(c,text,lambda s:'Subdivision:' in s and 'Details:' in s or '[ERROR]' in s or 'Subdivision failed' in s)
    actual=int(re.search(r'Subdivision: (\d+)',out).group(1))
    if value is not None: assert actual==value
    return out,actual

def move(c,text):
    out=human(c,text,lambda s:'Details:' in s or 'Move rejected' in s)
    assert 'Move complete' in out,out
    return out

def run(c,r):
    r['original_config']=checked(c,'read-config',address=1)
    r['stationary']=observe_stopped(c,address=1,timeout_s=5)
    r['original_profile']=profile_snapshot(c,timeout_s=5)
    r['original_subdivision'],original=subdivision(c)
    r['interactive_reads']=[]
    for i in range(12):
        out=human(c,'read state',lambda s:'State checked' in s and 'Details:' in s or '[ERROR]' in s)
        assert 'Tx:' not in out and len(out)<1000
        r['interactive_reads'].append(out)
    r['cases']=[]
    try:
        for value in (1600,51200,original):
            setting,_=subdivision(c,value)
            case={'requested':value,'setting':setting};r['cases'].append(case)
            case['zero']=move(c,'moveto 0 deg')
            if value!=original or len(r['cases'])==1:
                case['move']=move(c,'moveto 1 deg')
                case['return']=move(c,'moveto 0 deg')
                observe_stopped(c,address=1,timeout_s=5)
                case['profile_restore']=restore_profile(c,timeout_s=5)
        r['final_subdivision'],restored=subdivision(c)
        assert restored==original
        r['final_zero']=move(c,'moveto 0 deg')
        r['workload_verified']=True
    finally:
        if c.synchronized:
            r['cleanup_stop']=checked(c,'stop',address=1,stop_policy='normal')
            r['cleanup_state']=observe_stopped(c,address=1,timeout_s=5)
        else: r['cleanup']='unknown: framing lost; no write replay'
run_recorded(port='COM13',out=Path(sys.argv[1]),scenario='one-command-subdivision-and-interactive-results',
 inputs={'subdivision':[1600,51200,'original'],'moves_deg':[0,1,0],'read_state_repetitions':12,'manual_release':False},
 run=run,refresh=False,firmware=Path('build/ownership_fix/pio/bench_s3_load_timer/firmware.bin'))
