import sys, time, re, json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'scripts'))
from bench_probe import BenchError, observe_stopped
from bench_session import run_recorded, checked
from bench_motion import restore_profile

def human(c, text, terminal=None, timeout=7):
    assert not c.pending and not c.buffer
    c.emit('human_command', text=text)
    c.port.write((text+'\n').encode())
    end=time.monotonic()+timeout; quiet=end; data=bytearray()
    while time.monotonic()<end:
        chunk=c.port.read(8192)
        if chunk:
            data.extend(chunk); quiet=time.monotonic()+.1
        decoded=data.decode('utf-8')
        if data and time.monotonic()>=quiet and (terminal is None or terminal in decoded):
            c.emit('human_output', text=decoded); print(text+'\n'+decoded,flush=True); return decoded
        time.sleep(.005)
    c.emit('human_output',text=data.decode('utf-8',errors='replace'))
    raise BenchError('human terminal missing for '+text)

def campaign(c,r):
    r['help']=human(c,'help move')
    assert 'moveby' in r['help'] and 'move relative|' not in r['help']
    for command in ('speed 60','accel 100','decel 100'):
        assert 'Next move:' in human(c,command)
    r['trials']=[]; last=0; attempted=False
    try:
        for command in ('moveby 100 steps','moveby 100','stepsperturn 1000','moveby 36 deg','motion stored','moveby 36 deg'):
            if not command.startswith('moveby'):
                human(c,command); continue
            attempted=True
            output=human(c,command,'Details:')
            wrapper=int(re.search(r'operation (\d+)',output).group(1)); last=wrapper
            assert 'Move complete' in output and 'Drive reported running, then target reached.' in output
            assert len(output)<500 and 'staging_evidence' not in output
            child=int(re.search(r'Details: @1 result (\d+)',output).group(1))
            evidence=checked(c,'result',operation_id=child)
            assert evidence['completion']=='observed' and evidence['running_observed'] and not evidence['uncertain']
            r['trials'].append(dict(command=command,output=output,evidence=evidence,wrapper=wrapper))
        human(c,'motion write')
        # Existing example absolute bounds reject the far-away current coordinate.
        output=human(c,'moveto 100 steps','Details:')
        last=int(re.search(r'operation (\d+)',output).group(1))
        assert 'No motion command was sent.' in output and 'bounds' in output
        r['rejected_absolute']=output
        checked(c,'release',operation_id=last); last=0
        r['workload_verified']=True
    finally:
        if attempted and c.synchronized:
            r['stop']=checked(c,'stop',stop_policy='direct',address=1)
            r['stopped']=observe_stopped(c,address=1,timeout_s=5)
            if last: checked(c,'release',operation_id=last)
            r['restored']=restore_profile(c)
            r['final_state']=observe_stopped(c,address=1,timeout_s=5)
            r['scale_restored']=checked(c,'axis',host_args=('config','set','command','none'))
            r['probes']=[checked(c,'probe',address=1) for _ in range(3)]

plan=dict(moves=4,maximum_increments=100,rpm=60,deadline_s=7,
          success='all terminals delivered, running then arrived, compact human output, expected bounds rejection',
          cleanup='one direct stop, zero speed, original profile restore once, three probes',
          electrical_and_shaft_observation='unmeasured',automatic_write_replay=False)
print(json.dumps(plan),flush=True)
run_recorded(port='COM13',out=Path(sys.argv[1]),scenario='simple-human-motion-console',
             inputs=plan,run=campaign,refresh=False,
             firmware=Path('build/simple_cli/pio/bench_s3_load_timer/firmware.bin'))
