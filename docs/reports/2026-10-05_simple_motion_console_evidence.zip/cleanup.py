import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'scripts'))
from bench_probe import observe_stopped
from bench_session import run_recorded,checked
from bench_motion import restore_profile
def run(c,r):
    r['stop']=checked(c,'stop',address=1,stop_policy='direct')
    r['stopped']=observe_stopped(c,address=1,timeout_s=5)
    r['release']=checked(c,'release',operation_id=1)
    r['restore']=restore_profile(c)
    r['probe']=checked(c,'probe',address=1)
    r['workload_verified']=True
run_recorded(port='COM13',out=Path('build/simple_cli/evidence/first_run_cleanup'),
    scenario='explicit-cleanup-after-child-correlation-rejection',inputs={'no_move_replay':True},run=run)
