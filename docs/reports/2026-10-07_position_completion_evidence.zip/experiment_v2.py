import sys,time,json
from pathlib import Path
sys.path[:0]=['scripts','build/completion_followup']
from bench_session import run_recorded,checked
from bench_probe import observe_stopped,BenchError
from bench_motion import profile_snapshot,restore_profile
from human_helpers import human,move,subdivision
out=Path('build/motion_followup_20261007')
def compact(s):
 b={x['block']:x for x in s['state_blocks']}
 return dict(position=b[2]['raw_position'],speed=b[2]['raw_speed'],motion=b[0]['raw_motion'],alarm=b[0]['raw_alarm'])
def trial(c,case):
 r=dict(case=case,before=compact(observe_stopped(c,address=1,timeout_s=5)),samples=[])
 h=c.begin('move-relative',address=1,move_args=(str(case['steps']),'steps','native',str(case['rpm']),'configured'),timeout_s=45)
 if not h.accepted:raise BenchError('move rejected')
 start=time.monotonic()
 try:
  while time.monotonic()-start<8:
   s=compact(checked(c,'read-state',address=1));s['t']=round(time.monotonic()-start,6);r['samples'].append(s)
   if s['alarm']:raise BenchError('alarm')
   if h.terminal is not None:break
   time.sleep(.08)
 finally:
  if not c.synchronized:raise BenchError('framing lost; cleanup unknown')
  r['stop']=checked(c,'stop',address=1,stop_policy='fast')
  r['after']=compact(observe_stopped(c,address=1,timeout_s=5))
  r['result']=c.wait(h,release=True)
  r['cleanup']='drive_reported_stopped'
  assert r['result']['staging_words'][:3] == [case['ramp'],case['ramp'],case['rpm']], 'actual staging differs from case'
  c.emit('experiment_trial',trial=r)
  print(json.dumps({'case':case,'outcome':r['result']['outcome'],'samples':len(r['samples']),'delta_before_stop':r['samples'][-1]['position']-r['before']['position'],'last':r['samples'][-1]}),flush=True)
 return r

def run(c,r):
 r['identity']=checked(c,'read-identity',address=1)
 r['original_config']=checked(c,'read-config',address=1)
 r['original_profile']=profile_snapshot(c)
 original=51200 # Original before retained v1 failure; restore explicitly.
 groups=[(1600,100,[2000], [4000]),(12800,100,[2000],[32000]),(25600,100,[600,1200,2000],[64000]),(51200,100,[600,800,900,1200,2000],[12800,128000]),(51200,500,[900,1200,2000],[12800,128000]),(51200,2000,[1200,2000],[12800,128000])]
 r['trials']=[];snapshot_active=True
 try:
  for sub,ramp,speeds,distances in groups:
   if snapshot_active:
    observe_stopped(c,address=1,timeout_s=5);restore_profile(c);checked(c,'motion-profile',host_args=('forget',));snapshot_active=False
   subdivision(c,sub);profile_snapshot(c);snapshot_active=True
   for key,value in [('speed',60),('accel',ramp),('decel',ramp)]:human(c,f'{key} {value}',lambda s:'Use settings to compare' in s)
   move(c,'moveby 90 deg');profile_snapshot(c);observe_stopped(c,address=1,timeout_s=5)
   for rpm in speeds:
    for steps in distances:
     r['trials'].append(trial(c,dict(subdivision=sub,ramp=ramp,rpm=rpm,steps=steps)))
     time.sleep(.3)
  r['workload_verified']=True
 finally:
  if c.synchronized:
   r['final_stop']=checked(c,'stop',address=1,stop_policy='fast')
   for pending in list(c.pending.values()): c.wait(pending,release=True)
   observe_stopped(c,address=1,timeout_s=5)
   if snapshot_active:r['restore']=restore_profile(c);checked(c,'motion-profile',host_args=('forget',))
   subdivision(c,original);r['final_profile']=profile_snapshot(c)
   r['final_state']=compact(observe_stopped(c,address=1,timeout_s=5));r['cleanup']='drive_reported_stopped'
run_recorded(port='COM13',out=out/'boundary-matrix-v2',scenario='firmware-0029-position-boundaries',inputs={'observe_s':8,'stop':'one fast stop per case','group_count':6,'replay':False},run=run,max_records=200000,max_bytes=200*1024*1024,firmware=Path('build/usb_shared/pio/bench_s3_load_timer/firmware.bin'))
