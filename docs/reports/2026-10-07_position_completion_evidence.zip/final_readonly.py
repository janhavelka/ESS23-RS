import sys
from pathlib import Path
sys.path.insert(0,'scripts')
from bench_session import run_recorded,checked
from bench_probe import observe_stopped
from bench_motion import profile_snapshot

def run(c,r):
 r['identity']=checked(c,'read-identity',address=1)
 r['control']=checked(c,'control',address=1,driver_args=('read',))
 r['driver']=checked(c,'driver',address=1,driver_args=('read',))
 r['tuning']={g:checked(c,'tuning',address=1,driver_args=(g,'read')) for g in ('filters','current-loop','la')}
 r['profile']=profile_snapshot(c)
 r['state']=observe_stopped(c,address=1,timeout_s=5)
 r['monitor']=checked(c,'monitor')
 r['workload_verified']=True;r['cleanup']='drive_reported_stopped'
run_recorded(port='COM13',out=Path('build/motion_followup_20261007/final-readonly-v2'),scenario='firmware-and-settings-provenance',inputs={'motor_writes':False},run=run,firmware=Path('build/position_followup/pio/bench_s3_load_timer/firmware.bin'))
