import requests,json,hashlib,concurrent.futures
from pathlib import Path
out=Path('build/motion_followup_20261007')
refs=json.load(open('docs/reference/sources.json'))['references'][:3]
def fetch(r):
 name=Path(r['path']).name; remote=name.replace('V1.0_1_.pdf','V1.0_1.pdf')
 url='https://files.omc-stepperonline.com/'+remote
 x=requests.get(url,timeout=30); d={'url':url,'status':x.status_code,'bytes':len(x.content),'sha256':hashlib.sha256(x.content).hexdigest(),'original_sha256':r['sha256']};d['same']=d['sha256']==r['sha256']
 if x.status_code==200: (out/name).write_bytes(x.content)
 return d
results=list(concurrent.futures.ThreadPoolExecutor(3).map(fetch,refs));(out/'reference_recheck.json').write_text(json.dumps(results,indent=2)); print(json.dumps(results,indent=2))
