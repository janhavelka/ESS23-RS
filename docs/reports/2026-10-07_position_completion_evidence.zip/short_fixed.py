import sys,re,time
from pathlib import Path
sys.path[:0]=['scripts','build/completion_followup']
from bench_session import run_recorded,checked
from bench_probe import observe_stopped
from bench_motion import profile_snapshot,restore_profile
from human_helpers import human,move,subdivision

def run(c,r):
 r['original_profile']=profile_snapshot(c); r['cases']=[]
 try:
  checked(c,'motion-profile',host_args=('forget',)); subdivision(c,400); profile_snapshot(c)
  for key,value in [('speed',3000),('accel',100),('decel',100)]:human(c,f'{key} {value}',lambda s:'Use settings to compare' in s)
  for repeat in range(3):
   for steps in (1,2,5,10,20):
    before=observe_stopped(c,address=1,timeout_s=5)
    text=move(c,f'moveby {steps} steps');id=int(re.search(r'Details: @1 result (\d+)',text).group(1))
    result=checked(c,'result',operation_id=id)
    after=observe_stopped(c,address=1,timeout_s=5)
    before_pos=before['state_blocks'][2]['raw_position'];after_pos=after['state_blocks'][2]['raw_position']
    assert after_pos-before_pos == steps, (before_pos,after_pos,steps)
    assert result['ok'] and (result['position_confirmed'] or result['running_observed'])
    r['cases'].append(dict(repeat=repeat,steps=steps,delta=after_pos-before_pos,result=result))
    c.emit('short_move_checked',case=r['cases'][-1])
  r['workload_verified']=True
 finally:
  if c.synchronized:
   r['stop']=checked(c,'stop',address=1,stop_policy='fast');observe_stopped(c,address=1,timeout_s=5)
   r['restore']=restore_profile(c);checked(c,'motion-profile',host_args=('forget',))
   subdivision(c,51200)
   for key,value in [('speed',60),('accel',100),('decel',100)]:human(c,f'{key} {value}',lambda s:'Use settings to compare' in s)
   r['final']=observe_stopped(c,address=1,timeout_s=5);r['cleanup']='drive_reported_stopped'
run_recorded(port='COM13',out=Path('build/motion_followup_20261007/short-fixed-v2'),scenario='fresh-exact-endpoint-completion',inputs={'steps':[1,2,5,10,20],'repeats':3,'rpm':3000,'subdivision':400,'ramp':100},run=run,firmware=Path('build/position_followup/pio/bench_s3_load_timer/firmware.bin'))
