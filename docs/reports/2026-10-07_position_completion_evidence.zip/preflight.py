import sys
from pathlib import Path
sys.path.insert(0,'scripts')
from bench_session import run_recorded,checked
from bench_probe import observe_stopped

def run(c,r):
 checked(c,'load',load=(0,0,0)); checked(c,'debug',host_args=('off',))
 r['final_state']=observe_stopped(c,address=1,timeout_s=5)
 r['identity']=checked(c,'read-identity',address=1); r['workload_verified']=True;r['cleanup']='drive_reported_stopped'
run_recorded(port='COM13',out=Path('build/motion_followup_20261007/preflight'),scenario='final-readonly-standstill',inputs={'motor_write':False},run=run,firmware=Path('build/usb_shared/pio/bench_s3_load_timer/firmware.bin'))

