"""Human command boundary/recovery plus absolute-path regression, after matrix."""
import sys
from pathlib import Path
sys.path.insert(0,'scripts')
from bench_session import run_recorded,checked
from bench_probe import BenchError,observe_stopped
from bench_motion import profile_snapshot,restore_profile
from human_helpers import human,move,subdivision
ROOT=Path('build/position_limits_hil')
FIRMWARE=Path('build/position_limits/pio/bench_s3_load_timer/firmware.bin')
def run(c,r):
 checked(c,'stop',address=1,stop_policy='fast',timeout_s=8);observe_stopped(c,address=1,timeout_s=5)
 checked(c,'motion-profile',host_args=('forget',));r['original']=profile_snapshot(c)
 subdivision(c,51200);profile_snapshot(c)
 primary=None
 try:
  r['settings']=human(c,'settings',lambda s:'Position speed limit at this subdivision' in s and 'Details:' in s)
  if '234 rpm' not in r['settings']:raise BenchError('missing subdivision speed ceiling')
  r['rejected']=[]
  for speed,acc,dec in [(235,100,100),(234,99,100),(234,100,99)]:
   for key,value in [('speed',speed),('accel',acc),('decel',dec)]:human(c,f'{key} {value}',lambda s:'Use settings to compare' in s)
   try:human(c,'moveby 90 deg',lambda s:'Details:' in s or 'Move rejected' in s)
   except BenchError as e:
    if str(e)!='human operation rejected/failed; no replay' or not c.synchronized:raise
    r['rejected'].append([speed,acc,dec])
   else:raise BenchError('invalid simple move accepted')
   if profile_snapshot(c)['current']!=r['original']['current']:raise BenchError('invalid move changed profile')
   observe_stopped(c,address=1,timeout_s=5)
  for key,value in [('speed',234),('accel',100),('decel',100)]:human(c,f'{key} {value}',lambda s:'Use settings to compare' in s)
  r['relative']=move(c,'moveby 90 deg')
  r['absolute']=move(c,'moveto 360 deg')
  r['noop']=move(c,'moveto 360 deg')
  r['workload_verified']=len(r['rejected'])==3
 except BaseException as e:primary=e
 finally:
  r['cleanup']='unknown'
  try:
   if not c.synchronized:raise BenchError('framing lost; no automatic recovery')
   checked(c,'stop',address=1,stop_policy='fast',timeout_s=8);observe_stopped(c,address=1,timeout_s=5)
   r['restored']=restore_profile(c)
   for key,value in [('speed',60),('accel',100),('decel',100)]:human(c,f'{key} {value}',lambda s:'Use settings to compare' in s)
   r['final_state']=observe_stopped(c,address=1,timeout_s=5)
   r['final_driver']=checked(c,'drv')
   if any(r['final_driver'][k] for k in ('busy','transmit_enabled','recovery_required','pending','reserved')):raise BenchError('bus not settled')
   r['cleanup']='drive_reported_stopped_and_settings_restored'
  except BaseException as e:
   r['cleanup_error']=str(e)
   if primary is None:primary=e
 if primary:raise primary
run_recorded(port='COM13',out=ROOT/'usability',scenario='simple-position-boundary-absolute-regression',inputs={'subdivision':51200,'ceiling_rpm':234,'invalid_profiles':[[235,100,100],[234,99,100],[234,100,99]],'motion':['moveby 90 deg','moveto 360 deg','moveto 360 deg']},run=run,firmware=FIRMWARE)
