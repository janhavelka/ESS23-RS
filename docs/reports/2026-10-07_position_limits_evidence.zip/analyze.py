import json,csv,hashlib
from collections import Counter
from pathlib import Path
root=Path(__file__).resolve().parent
rows=[];counts=Counter();maximum_error=0;latencies=[]
with (root/'boundary-run.jsonl').open(encoding='utf-8') as f:
 for line in f:
  event=json.loads(line)
  if event['event']!='rate_trial':continue
  r=event['trial'];c=r['case'];counts[r['issue'] or ('interrupted' if c['interruption'] else 'observed')]+=1
  row=dict(index=r['index'],**c,delta=r.get('delta'),endpoint_error=r.get('endpoint_error'),issue=r['issue'],natural_stopped=r.get('natural_stopped'),elapsed_s=r['elapsed_s'])
  rows.append(row)
  if not c['interruption']:maximum_error=max(maximum_error,abs(r['endpoint_error']))
  latencies.append(r['elapsed_s'])
with (root/'matrix.csv').open('w',newline='',encoding='utf-8') as f:
 writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
summary=json.load((root/'boundary-run.json').open(encoding='utf-8'))
before,after=summary['before'],summary['after']
result=dict(cases=len(rows),counts=dict(counts),maximum_endpoint_error=maximum_error,active_s=summary['active_s'],cleanup=summary['cleanup'],rejections=summary['rejections'],stats_before=before['stats'],stats_after=after['stats'],memory_before=before['memory'],memory_after=after['memory'],load_before=before['load'],load_after=after['load'],identity=after['identity'],driver=after['drv'],final_state=summary['final_state'],original_profile=summary['original_profile'],final_profile=summary['final_profile'],firmware=summary.get('firmware'),per_case_elapsed_s={'minimum':min(latencies),'maximum':max(latencies),'mean':sum(latencies)/len(latencies)})
(root/'analysis.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:result[k] for k in ('cases','counts','maximum_endpoint_error','active_s','cleanup','rejections','per_case_elapsed_s')},indent=2))
