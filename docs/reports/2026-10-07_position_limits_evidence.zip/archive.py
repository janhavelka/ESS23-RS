import hashlib,json,subprocess,zipfile
from pathlib import Path
root=Path(__file__).resolve().parent
(root/'source.diff').write_bytes(subprocess.check_output(['git','diff','--','include','src','examples','test','docs/reference/ess_rs_operations.json']))
files=[p for p in root.rglob('*') if p.is_file() and not any(x in ('__pycache__','core-stage','core-package') for x in p.relative_to(root).parts)]
manifest={'baseline':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'files':[]}
for p in sorted(files):
 manifest['files'].append({'path':p.relative_to(root).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
out=Path('docs/reports/2026-10-07_position_limits_evidence.zip')
with zipfile.ZipFile(out,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files):z.write(p,p.relative_to(root).as_posix())
 z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'file':str(out),'bytes':out.stat().st_size,'members':len(files)+1,'sha256':hashlib.sha256(out.read_bytes()).hexdigest()},indent=2))
