import re,sys,time
from pathlib import Path
sys.path.insert(0,'scripts')
from bench_session import run_recorded,checked
from bench_probe import BenchError,observe_stopped,FAULT_TEXT
from bench_motion import profile_snapshot,restore_profile

def human(c,text,end):
    assert not c.pending and not c.buffer
    c.emit('human_command',text=text); sent=c.port.write((text+'\n').encode()); assert sent==len((text+'\n').encode()), 'short console write'
    deadline=time.monotonic()+15; raw=bytearray(); quiet=deadline
    while time.monotonic()<deadline:
        part=c.port.read(4096)
        if part: raw.extend(part);quiet=time.monotonic()+.05
        output=raw.decode('utf-8')
        if len(raw)>32768 or FAULT_TEXT.search(output):
            c.synchronized=False; raise BenchError('fault/oversized human output')
        if end(output) and time.monotonic()>quiet:
            c.emit('human_output',text=output); print(output,flush=True)
            if '[ERROR]' in output or 'failed' in output.lower() or 'not confirmed' in output.lower():
                raise BenchError('human operation rejected/failed; no replay')
            return output
        time.sleep(.005)
    c.emit('human_incomplete',text=raw.decode(errors='replace'));c.synchronized=False
    raise BenchError('human timeout; no replay')

def subdivision(c,value=None):
    text='subdivision' if value is None else f'subdivision {value}'
    out=human(c,text,lambda s:'Subdivision:' in s and 'Details:' in s or '[ERROR]' in s or 'Subdivision failed' in s)
    actual=int(re.search(r'Subdivision: (\d+)',out).group(1))
    if value is not None: assert actual==value
    return out,actual

def move(c,text):
    out=human(c,text,lambda s:'Details:' in s or 'Move rejected' in s)
    assert 'Move complete' in out,out
    return out

