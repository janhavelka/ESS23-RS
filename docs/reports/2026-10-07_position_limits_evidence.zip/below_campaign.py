﻿"""Bounded below/equal-200k experiment. No implicit recovery or move replay."""
import argparse,json,math,sys,time
from collections import Counter
from datetime import datetime,timezone
from pathlib import Path
sys.path.insert(0,'scripts')
from bench_session import run_recorded,checked,snapshot
from bench_probe import BenchError,observe_stopped
from bench_motion import profile_snapshot,restore_profile
from human_helpers import human,move,subdivision
from campaign import compact,FIRMWARE
ROOT=Path('build/rate_qualification_20261007/below')
ROOT.mkdir(exist_ok=True)

def status(**s):
 p=ROOT/'status.tmp';p.write_text(json.dumps(s,indent=2));p.replace(ROOT/'status.json')

def plan():
 groups=[]
 for accel,decel in ((500,500),(100,100),(2000,2000),(50,50),(100,500),(500,100)):
  for sub in (51200,25600,20000,12800,10000,8000,6400,4000,1600,400):
   ceiling=min(3000,12000000//sub)
   speeds=sorted(set([60]+[max(30,math.floor(ceiling*f)) for f in (.25,.5,.9,.99,1)]))
   cases=[]
   for rpm in speeds:
    for steps in (1,sub//4,sub*5):
     cases.append(dict(subdivision=sub,accel=accel,decel=decel,rpm=rpm,steps=steps,turns=steps/sub,rate=sub*rpm/60,interruption=None))
   for policy in ('normal','fast'):
    rpm=min(600,max(60,ceiling//2))
    cases.append(dict(subdivision=sub,accel=accel,decel=decel,rpm=rpm,steps=sub*10,turns=10,rate=sub*rpm/60,interruption=policy))
   groups.append(dict(subdivision=sub,accel=accel,decel=decel,cases=cases))
 return groups

def trial(c,case,index):
 r=dict(index=index,case=case,samples=[],cleanup='unknown',issue=None)
 started=time.monotonic();primary=None
 try:
  r['before']=compact(observe_stopped(c,address=1,timeout_s=5))
  h=c.begin('move-relative',address=1,move_args=(str(case['steps']),'steps','native',str(case['rpm']),'configured'),timeout_s=45)
  if not h.accepted: raise BenchError('move rejected: '+str(h.terminal))
  r['operation_id']=h.operation_id
  while time.monotonic()-started<max(8,case['turns']*60/case['rpm']+6):
   s=compact(checked(c,'read-state',address=1));s['t']=time.monotonic()-started;r['samples'].append(s)
   if s['alarm']: raise BenchError('drive alarm')
   if h.terminal is not None:
    if not case['interruption']:
     r['settlement_samples']=[]
     for _ in range(5):
      time.sleep(.15);x=compact(checked(c,'read-state',address=1));r['settlement_samples'].append(x)
      if x['alarm']: raise BenchError('alarm during settlement')
     r['natural_stopped']=all(not(x['motion']&4) and x['speed']==0 for x in r['settlement_samples'][-2:])
    break
   if case['interruption'] and time.monotonic()-started>=.2: break
   time.sleep(.12)
  policy=case['interruption'] or 'fast'
  r['stop']=c.command('stop',address=1,stop_policy=policy,timeout_s=8)
  if not r['stop']['ok']:
   if policy!='normal': raise BenchError('fast stop not confirmed')
   r['fallback_fast_stop']=checked(c,'stop',address=1,stop_policy='fast',timeout_s=8)
  r['after']=compact(observe_stopped(c,address=1,timeout_s=5))
  r['cleanup']='drive_reported_stopped';r['result']=c.wait(h,release=True)
  if r['result'].get('staging_words')!=[case['accel'],case['decel'],case['rpm'],case['steps']>>16,case['steps']&65535]:
   raise BenchError('staging differs from case')
  r['delta']=r['after']['position']-r['before']['position'];r['endpoint_error']=r['delta']-case['steps']
  if not case['interruption'] and not r['result']['ok']:
   r['issue']='persistent_running' if r['samples'] and r['samples'][-1]['motion']&4 else 'completion_unconfirmed'
  if r['result']['ok'] and r.get('natural_stopped') is False:r['issue']='completion_then_not_settled'
  if not r['stop']['ok']:r['issue']='normal_stop_unconfirmed'
  # Encoder-derived feedback is quantized. A one-command-increment move can
  # leave the observed encoder-derived position unchanged; never invent motion.
  if r['result']['ok'] and case['steps']>=case['subdivision']//4 and r['delta']<=0:r['issue']='completed_without_positive_feedback_change'
 except BaseException as e:
  primary=e;r['error']=str(e);r['issue']='fatal_error'
  # A recovery interlock is not skipped. Root must review and explicitly recover.
  if c.synchronized:
   try:
    r['failure_driver']=checked(c,'drv')
    r['failure_stats']=checked(c,'stats')
   except BaseException as diagnostic:r['diagnostic_error']=str(diagnostic)
 finally:
  r['elapsed_s']=time.monotonic()-started;c.emit('rate_trial',trial=r)
  with (ROOT/'trials.jsonl').open('a') as f:f.write(json.dumps({k:v for k,v in r.items() if k not in ('samples','settlement_samples','result','stop','before','after','failure_driver','failure_stats')})+'\n')
 if primary:raise primary
 return r

def run(c,r,duration):
 checked(c,'load',load=(0,0,0));checked(c,'debug',host_args=('off',));checked(c,'monitor',monitor=False)
 checked(c,'motion-profile',host_args=('forget',))
 r['original_profile']=profile_snapshot(c);r['original_subdivision']=subdivision(c)[1]
 r['started_utc']=datetime.now(timezone.utc).isoformat();start=time.monotonic();paused=0;i=0;counts=Counter();primary=None
 r['issues']=[];r['last_trials']=[];snapshot_active=True
 (ROOT/'plan.json').write_text(json.dumps(plan(),indent=2))
 try:
  while time.monotonic()-start-paused<duration:
   for group in plan():
    if time.monotonic()-start-paused>=duration:break
    observe_stopped(c,address=1,timeout_s=5);restore_profile(c);checked(c,'motion-profile',host_args=('forget',));snapshot_active=False
    subdivision(c,group['subdivision']);profile_snapshot(c);snapshot_active=True
    for key,value in [('speed',60),('accel',group['accel']),('decel',group['decel'])]:human(c,f'{key} {value}',lambda s:'Use settings to compare' in s)
    move(c,'moveby 90 deg');profile_snapshot(c);observe_stopped(c,address=1,timeout_s=5)
    for case in group['cases']:
     active=time.monotonic()-start-paused
     if active>=duration:break
     i+=1;status(state='running',index=i,case=case,active_s=active,duration_s=duration,counts=dict(counts))
     row=trial(c,case,i);counts[row['issue'] or ('interrupted' if case['interruption'] else 'observed')]+=1
     short={k:row.get(k) for k in ('index','case','delta','endpoint_error','issue','natural_stopped','elapsed_s')}
     print(json.dumps(short),flush=True);r['last_trials'].append(short);del r['last_trials'][:-16]
     if row['issue']:
      r['issues'].append(short);pause=time.monotonic()
      c.emit('issue_diagnostics',index=i,diagnostics=snapshot(c,address=1,refresh=False))
      status(state='paused_at_confirmed_standstill',index=i,case=case,issue=row['issue'],active_s=active,counts=dict(counts))
      decision=ROOT/f'continue-{i}.json'
      while not decision.exists():
       if (ROOT/'STOP').exists() or time.monotonic()-pause>900:raise BenchError('review ended or absent')
       time.sleep(.5)
      review=json.loads(decision.read_text(encoding='utf-8-sig'))
      if not review.get('continue_after_confirmed_stop'):raise BenchError('review rejected continuation')
      c.emit('issue_review',index=i,review=review);observe_stopped(c,address=1,timeout_s=5);paused+=time.monotonic()-pause
     if i%10==0:c.emit('rate_diagnostics',index=i,diagnostics=snapshot(c,address=1,refresh=False))
     if (ROOT/'STOP').exists():raise BenchError('operator ended experiment')
     time.sleep(.2)
  r['workload_verified']=i>0 and time.monotonic()-start-paused>=duration;r['all_moves_passed']=not r['issues']
 except BaseException as e:primary=e;r['primary_error']=str(e)
 finally:
  r['trial_count']=i;r['counts']=dict(counts);r['active_experiment_s']=time.monotonic()-start-paused;r['review_pause_s']=paused
  r['cleanup']='unknown'
  try:
   if not c.synchronized:raise BenchError('framing lost; explicit recovery required')
   drv=checked(c,'drv');r['final_driver_before_cleanup']=drv
   if drv.get('recovery_required') or drv.get('recovery_required',False):raise BenchError('transport recovery required; no automatic recovery or replay')
   r['final_stop']=checked(c,'stop',address=1,stop_policy='fast',timeout_s=8)
   for h in list(c.pending.values()):c.wait(h,release=True)
   observe_stopped(c,address=1,timeout_s=5)
   if snapshot_active:restore_profile(c);checked(c,'motion-profile',host_args=('forget',))
   subdivision(c,r['original_subdivision']);r['final_profile']=profile_snapshot(c)
   if r['final_profile']['current']!=r['original_profile']['current']:raise BenchError('profile restoration mismatch')
   r['final_state']=observe_stopped(c,address=1,timeout_s=5);r['cleanup']='drive_reported_stopped_and_settings_restored'
  except BaseException as e:
   r['cleanup_error']=str(e)
   if primary is None:primary=e
  status(state='failed' if primary else 'finished',index=i,active_s=r['active_experiment_s'],counts=dict(counts),cleanup=r['cleanup'],error=str(primary) if primary else None)
 if primary:raise primary

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--duration',type=float,default=14400);p.add_argument('--name',default='four-hour-below');a=p.parse_args()
 if not 0<a.duration<=14400:p.error('bounded duration required')
 run_recorded(port='COM13',out=ROOT/a.name,scenario='below-200k-finite-position-study',inputs={'duration_s':a.duration,'rate_ceiling':200000,'automatic_recovery':False},run=lambda c,r:run(c,r,a.duration),max_records=2000000,max_bytes=2*1024*1024*1024,firmware=FIRMWARE)
