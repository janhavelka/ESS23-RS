"""Finite default-boundary qualification; one serial owner, no replay/recovery."""
import json,sys,time
from collections import Counter
from pathlib import Path
sys.path.insert(0,'scripts')
from bench_session import run_recorded,checked,snapshot
from bench_probe import BenchError,observe_stopped
from bench_motion import profile_snapshot,restore_profile
from human_helpers import human,move,subdivision
import below_campaign as study
ROOT=Path('build/position_limits_hil');study.ROOT=ROOT
FIRMWARE=Path('build/position_limits/pio/bench_s3_load_timer/firmware.bin')
SUBS=(51200,51199,25600,20000,12800,10000,8000,6400,6001,6000,5999,4000,3200,1600,1000,800,400)
RAMPS=((100,100),(100,2000),(2000,100),(2000,2000))
def run(c,r):
 checked(c,'load',load=(0,0,0));checked(c,'monitor',monitor=False);checked(c,'debug',host_args=('off',))
 checked(c,'stop',address=1,stop_policy='fast',timeout_s=8);observe_stopped(c,address=1,timeout_s=5)
 checked(c,'motion-profile',host_args=('forget',))
 r['original_profile']=profile_snapshot(c);r['original_subdivision']=subdivision(c)[1]
 counts=Counter();i=0;rejections=0;primary=None;started=time.monotonic();saved=True
 try:
  for acc,dec in RAMPS:
   for sub in SUBS:
    if time.monotonic()-started>3600:raise BenchError('one-hour hard campaign bound reached')
    observe_stopped(c,address=1,timeout_s=5);restore_profile(c);checked(c,'motion-profile',host_args=('forget',));saved=False
    subdivision(c,sub);profile_snapshot(c);saved=True
    for key,value in [('speed',60),('accel',acc),('decel',dec)]:human(c,f'{key} {value}',lambda s:'Use settings to compare' in s)
    move(c,'moveby 90 deg');profile_snapshot(c);observe_stopped(c,address=1,timeout_s=5)
    ceiling=min(2000,12000000//sub)
    # A one-rpm excess must be refused locally, never a physical overspeed test.
    drv=checked(c,'stats')
    bad=c.begin('move-relative',address=1,move_args=(str(sub),'steps','native',str(ceiling+1),'configured'))
    if bad.accepted:
     checked(c,'stop',address=1,stop_policy='fast',timeout_s=8)
     raise BenchError('over-boundary request admitted unexpectedly')
    rbad=c.wait(bad)
    after=checked(c,'stats')
    if rbad.get('ok') or after['started']!=drv['started']:raise BenchError('invalid speed produced TX')
    rejections+=1;c.emit('boundary_rejection',subdivision=sub,rpm=ceiling+1,result=rbad)
    cases=[(ceiling-1,sub//4,None),(ceiling,sub//4,None),(ceiling,sub*5,None),(ceiling,sub*20,None),
           (min(600,ceiling),sub*10,'normal'),(min(600,ceiling),sub*10,'fast')]
    for rpm,steps,stop in cases:
     i+=1;case=dict(subdivision=sub,accel=acc,decel=dec,rpm=rpm,steps=steps,turns=steps/sub,rate=sub*rpm/60,interruption=stop)
     result=study.trial(c,case,i)
     counts[result['issue'] or ('interrupted' if stop else 'observed')]+=1
     with (ROOT/'progress.jsonl').open('a') as f:f.write(json.dumps(dict(index=i,case=case,counts=dict(counts),elapsed_s=time.monotonic()-started))+'\n')
     print(json.dumps(dict(index=i,case=case,issue=result['issue'])),flush=True)
     if result['issue']:raise BenchError('boundary issue: '+result['issue'])
     if i%12==0:c.emit('boundary_diagnostics',index=i,diagnostics=snapshot(c,address=1,refresh=False))
  r['workload_verified']=i==len(SUBS)*len(RAMPS)*6 and rejections==len(SUBS)*len(RAMPS)
 except BaseException as e:primary=e;r['primary_error']=str(e)
 finally:
  r.update(trial_count=i,rejections=rejections,counts=dict(counts),active_s=time.monotonic()-started,cleanup='unknown')
  try:
   if not c.synchronized:raise BenchError('framing lost; no automatic recovery')
   checked(c,'stop',address=1,stop_policy='fast',timeout_s=8);observe_stopped(c,address=1,timeout_s=5)
   for h in list(c.pending.values()):c.wait(h,release=True)
   if saved:restore_profile(c);checked(c,'motion-profile',host_args=('forget',))
   subdivision(c,r['original_subdivision']);r['final_profile']=profile_snapshot(c)
   if r['final_profile']['current']!=r['original_profile']['current']:raise BenchError('profile restoration mismatch')
   for key,value in [('speed',60),('accel',100),('decel',100)]:human(c,f'{key} {value}',lambda s:'Use settings to compare' in s)
   r['final_state']=observe_stopped(c,address=1,timeout_s=5);r['cleanup']='drive_reported_stopped_and_settings_restored'
  except BaseException as e:
   r['cleanup_error']=str(e)
   if primary is None:primary=e
 if primary:raise primary
run_recorded(port='COM13',out=ROOT/'boundary-run',scenario='default-position-policy-boundary',inputs={'subdivisions':SUBS,'ramps':RAMPS,'cases_per_group':6,'over_boundary_no_tx_checks':68},run=run,max_records=1000000,max_bytes=1024*1024*1024,firmware=FIRMWARE)
