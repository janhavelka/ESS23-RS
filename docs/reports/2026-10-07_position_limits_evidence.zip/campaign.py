"""Explicit four-hour finite position experiment; archived with its evidence.
Reuses production Console parsing, snapshots, strict correlation and stop APIs.
A move issue pauses at confirmed standstill for root-agent review; no write replay.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
import json, math, sys, time
from pathlib import Path
sys.path.insert(0,'scripts')
from bench_session import run_recorded, checked, snapshot
from bench_probe import BenchError, observe_stopped
from bench_motion import profile_snapshot, restore_profile
from human_helpers import human, move, subdivision

ROOT=Path('build/rate_qualification_20261007')
FIRMWARE=Path('build/position_followup/pio/bench_s3_load_timer/firmware.bin')

def compact(s):
    b={x['block']:x for x in s['state_blocks']}
    return dict(position=b[2]['raw_position'],speed=b[2]['raw_speed'],motion=b[0]['raw_motion'],
                alarm=b[0]['raw_alarm'],observation_us=s['steps'][2]['earliest_us'],
                delivered_us=s['serviced_us'],operation_id=s['operation_id'])

def plan():
    # Near-boundary groups first. Every case is finite; never a continuous-speed loop.
    subs=(51200,25600,20000,12800,10000,8000,6400,4000,1600,400)
    groups=[]
    for ramp in (100,500,2000,50):
        for sub in subs:
            limit=12000000/sub
            speeds=sorted(set([60]+[max(30,min(3000,math.floor(limit*f))) for f in (.25,.5,.9,.99,1,1.01,1.1,1.5)]))
            if sub==51200: speeds=sorted(set(speeds+[900,1200,2000]))
            cases=[]
            for rpm in speeds:
                for turns in (.25,2.5,5):
                    steps=int(sub*turns)
                    cases.append(dict(subdivision=sub,ramp=ramp,rpm=rpm,steps=steps,
                                      turns=turns,rate_numerator=sub*rpm,rate_denominator=60,
                                      below_200k=sub*rpm<=12000000,interruption=None))
            # Deliberate normal/fast interruption at a below-boundary rate.
            for policy in ('normal','fast'):
                rpm=max(60,min(600,math.floor(limit*.5)))
                cases.append(dict(subdivision=sub,ramp=ramp,rpm=rpm,steps=sub*10,turns=10,
                                  rate_numerator=sub*rpm,rate_denominator=60,
                                  below_200k=sub*rpm<=12000000,interruption=policy))
            groups.append(dict(subdivision=sub,ramp=ramp,cases=cases))
    return groups

def status(value):
    temp=ROOT/'status.tmp'
    temp.write_text(json.dumps(value,indent=2),encoding='utf-8')
    temp.replace(ROOT/'status.json')

def trial(c,case,index):
    r=dict(index=index,case=case,before=compact(observe_stopped(c,address=1,timeout_s=5)),samples=[])
    h=c.begin('move-relative',address=1,move_args=(str(case['steps']),'steps','native',str(case['rpm']),'configured'),timeout_s=45)
    if not h.accepted: raise BenchError('move not admitted: '+str(h.terminal))
    started=time.monotonic()
    window=max(8,case['turns']*60/case['rpm']+6)
    try:
        while time.monotonic()-started<window:
            s=compact(checked(c,'read-state',address=1));s['t']=round(time.monotonic()-started,6)
            r['samples'].append(s)
            if s['alarm']: raise BenchError('drive alarm; campaign ends')
            if h.terminal is not None:
                if not case['interruption']:
                    # Observe settlement before sending the planned cleanup stop.
                    # Completion may precede the next separate state read.
                    r['settlement_samples']=[]
                    for _ in range(5):
                        time.sleep(.15)
                        settled=compact(checked(c,'read-state',address=1))
                        r['settlement_samples'].append(settled)
                        if settled['alarm']: raise BenchError('alarm during settlement')
                    r['natural_stopped']=all(not (x['motion']&4) and x['speed']==0 for x in r['settlement_samples'][-2:])
                break
            if case['interruption'] and time.monotonic()-started>=.2: break
            time.sleep(.12)
    finally:
        if not c.synchronized: raise BenchError('framing lost; cleanup unknown, no further commands')
        policy=case['interruption'] or 'fast'
        r['stop']=c.command('stop',address=1,stop_policy=policy,timeout_s=8)
        if not r['stop']['ok']:
            if policy!='normal': raise BenchError('fast stop not confirmed; abort')
            # One separately planned fast stop, never replay the uncertain normal stop.
            r['fallback_fast_stop']=checked(c,'stop',address=1,stop_policy='fast',timeout_s=8)
        r['after']=compact(observe_stopped(c,address=1,timeout_s=5))
        r['result']=c.wait(h,release=True)
        r['elapsed_s']=time.monotonic()-started
        r['cleanup']='drive_reported_stopped'
        if r['result'].get('staging_words') != [case['ramp'],case['ramp'],case['rpm'],case['steps']>>16,case['steps']&65535]:
            raise BenchError('actual staging differs from requested case')
        r['delta']=r['after']['position']-r['before']['position']
        r['endpoint_error']=r['delta']-case['steps']
        r['issue']=None
        if not case['interruption'] and not r['result']['ok']:
            r['issue']='persistent_running' if r['samples'][-1]['motion']&4 else 'completion_unconfirmed'
        if r['result']['ok'] and r.get('natural_stopped') is False: r['issue']='completion_then_not_settled'
        if not r['stop']['ok']: r['issue']='normal_stop_unconfirmed'
        if r['result']['ok'] and r['delta']<=0: r['issue']='completed_without_positive_feedback_change'
        c.emit('rate_trial',trial=r)
    return r

def run(c,r,duration):
    checked(c,'load',load=(0,0,0));checked(c,'debug',host_args=('off',));checked(c,'monitor',monitor=False)
    r['original_profile']=profile_snapshot(c)
    r['original_subdivision']=subdivision(c)[1]
    r['identity']=checked(c,'read-identity',address=1)
    r['started_utc']=datetime.now(timezone.utc).isoformat()
    start=time.monotonic();paused=0;counts=Counter();i=0;snapshot_active=True
    r['last_trials']=[];r['issues']=[];r['groups_completed']=0
    planfile=ROOT/'plan.json'
    planfile.write_text(json.dumps(plan(),indent=2),encoding='utf-8')
    try:
        cycle=0
        while time.monotonic()-start-paused<duration:
            for group in plan():
                if time.monotonic()-start-paused>=duration: break
                if snapshot_active:
                    observe_stopped(c,address=1,timeout_s=5);restore_profile(c)
                    checked(c,'motion-profile',host_args=('forget',));snapshot_active=False
                subdivision(c,group['subdivision']);profile_snapshot(c);snapshot_active=True
                for key,value in [('speed',60),('accel',group['ramp']),('decel',group['ramp'])]:
                    human(c,f'{key} {value}',lambda s:'Use settings to compare' in s)
                move(c,'moveby 90 deg');profile_snapshot(c);observe_stopped(c,address=1,timeout_s=5)
                c.emit('rate_group',cycle=cycle,subdivision=group['subdivision'],ramp=group['ramp'])
                for case in group['cases']:
                    active=time.monotonic()-start-paused
                    if active>=duration: break
                    i+=1
                    status(dict(state='running',started_utc=r['started_utc'],active_s=active,duration_s=duration,index=i,case=case,counts=dict(counts)))
                    row=trial(c,case,i)
                    key=('below_or_equal' if case['below_200k'] else 'above')+'_'+(row['issue'] or ('interrupted' if case['interruption'] else 'observed'))
                    counts[key]+=1
                    compactrow={k:row[k] for k in ('index','case','delta','endpoint_error','elapsed_s','issue')}
                    compactrow['outcome']=row['result']['outcome']
                    compactrow['natural_stopped']=row.get('natural_stopped')
                    with (ROOT/'trials.jsonl').open('a',encoding='utf-8') as f: f.write(json.dumps(compactrow)+'\n')
                    print(json.dumps(compactrow),flush=True)
                    r['last_trials'].append(compactrow);del r['last_trials'][:-16]
                    if row['issue']:
                        pause_start=time.monotonic()
                        r['issues'].append(compactrow)
                        diagnostics=snapshot(c,address=1,refresh=False)
                        c.emit('rate_issue_diagnostics',index=i,diagnostics=diagnostics)
                        status(dict(state='paused_at_confirmed_standstill',index=i,case=case,issue=row['issue'],counts=dict(counts),active_s=active,duration_s=duration))
                        decision=ROOT/f'continue-{i}.json'
                        while not decision.exists():
                            if (ROOT/'STOP').exists(): raise BenchError('operator ended campaign after issue')
                            if time.monotonic()-pause_start>900: raise BenchError('issue review not received within 15 minutes')
                            time.sleep(.5)
                        disposition=json.loads(decision.read_text(encoding='utf-8-sig'))
                        if not disposition.get('continue_after_confirmed_stop'): raise BenchError('review ended campaign')
                        c.emit('rate_issue_review',index=i,disposition=disposition)
                        observe_stopped(c,address=1,timeout_s=5)
                        paused+=time.monotonic()-pause_start
                    if i%10==0:
                        c.emit('rate_diagnostics',index=i,diagnostics=snapshot(c,address=1,refresh=False))
                    if (ROOT/'STOP').exists(): raise BenchError('operator requested bounded end')
                    time.sleep(.2)
                r['groups_completed']+=1
            cycle+=1
        r['counts']=dict(counts);r['trial_count']=i;r['active_experiment_s']=time.monotonic()-start-paused;r['review_pause_s']=paused
        r['workload_verified']=i>0 and r['active_experiment_s']>=duration
        r['all_moves_passed']=not r['issues']
    finally:
        if c.synchronized:
            r['final_stop']=checked(c,'stop',address=1,stop_policy='fast',timeout_s=8)
            for handle in list(c.pending.values()): c.wait(handle,release=True)
            observe_stopped(c,address=1,timeout_s=5)
            if snapshot_active:
                r['restore']=restore_profile(c);checked(c,'motion-profile',host_args=('forget',))
            subdivision(c,r['original_subdivision'])
            r['final_profile']=profile_snapshot(c)
            if r['final_profile']['current']!=r['original_profile']['current']:
                raise BenchError('final profile does not equal session originals')
            for key,value in [('speed',60),('accel',100),('decel',100)]:
                human(c,f'{key} {value}',lambda s:'Use settings to compare' in s)
            r['final_state']=observe_stopped(c,address=1,timeout_s=5)
            r['cleanup']='drive_reported_stopped'
            r['counts']=dict(counts);r['trial_count']=i
            status(dict(state='finished',counts=dict(counts),trial_count=i,active_s=time.monotonic()-start-paused,issues=len(r['issues']),cleanup=r['cleanup']))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--duration',type=float,default=14400);p.add_argument('--name',default='four-hour');a=p.parse_args()
    if not 0<a.duration<=14400: p.error('duration must be positive and no greater than four hours')
    run_recorded(port='COM13',out=ROOT/a.name,scenario='200khz-finite-position-study',inputs={'duration_s':a.duration,'counterexample_review':'pause after confirmed stop','replay':False,'plan':'plan.json'},run=lambda c,r:run(c,r,a.duration),max_records=2000000,max_bytes=2*1024*1024*1024,firmware=FIRMWARE)
