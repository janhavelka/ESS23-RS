import sys
from pathlib import Path
sys.path.insert(0,'scripts')
from bench_session import run_recorded, checked
from bench_probe import observe_stopped

def run(c,r):
    r['config']=checked(c,'read-config',address=1)
    r['stationary']=observe_stopped(c,address=1,timeout_s=5)
    r['workload_verified']=True
run_recorded(port='COM13',out=Path('build/rounding_live_speed/before-flash'),scenario='read-only-preflash',inputs={'writes':0},run=run,refresh=False)
