import json, re, sys, time
from pathlib import Path
sys.path.insert(0, 'scripts')
from bench_session import run_recorded, checked
from bench_probe import BenchError, observe_stopped, FAULT_TEXT
from bench_motion import profile_snapshot, restore_profile

def send(c, text):
    assert not c.pending and not c.buffer
    c.emit('human_command', text=text)
    c.port.write((text+'\n').encode())

def receive(c, predicate, timeout=12):
    deadline=time.monotonic()+timeout; raw=bytearray(); quiet=deadline
    while time.monotonic()<deadline:
        part=c.port.read(4096)
        if part: raw.extend(part); quiet=time.monotonic()+.05
        text=raw.decode('utf-8')
        if len(raw)>32768 or FAULT_TEXT.search(text):
            c.synchronized=False
            raise BenchError('fault or excessive output during human command')
        if predicate(text) and time.monotonic()>=quiet:
            c.emit('human_output',text=text); print(text,flush=True); return text
        time.sleep(.005)
    c.synchronized=False
    c.emit('human_incomplete',text=raw.decode('utf-8',errors='replace'))
    raise BenchError('human command timeout; no replay')

def motion(c, text):
    send(c,text)
    out=receive(c,lambda s:'Details:' in s)
    assert 'Move complete' in out, out
    return out

def run(c,r):
    r['config']=checked(c,'read-config',address=1)
    r['baseline']=observe_stopped(c,address=1,timeout_s=5)
    r['profile']=profile_snapshot(c,timeout_s=5)
    try:
        r['rounded']=motion(c,'moveby 100 deg')
        assert 'Rounded native target: 278 command steps' in r['rounded']
        r['rounded_state']=observe_stopped(c,address=1,timeout_s=5)
        start=r['baseline']['state_blocks'][2]['raw_position']
        end=r['rounded_state']['state_blocks'][2]['raw_position']
        assert abs(end-start-278)<=2,(start,end)
        r['zero']=motion(c,'moveby 0.1 steps')
        assert 'Rounded native target: 0' in r['zero']
        assert 'No new motion command was sent' in r['zero']
        r['return']=motion(c,'moveto 0 deg')
        r['returned_state']=observe_stopped(c,address=1,timeout_s=5)
        assert abs(r['returned_state']['state_blocks'][2]['raw_position']-start)<=2
        r['workload_verified']=True
    finally:
        if c.synchronized:
            r['cleanup_stop']=checked(c,'stop',address=1,stop_policy='normal')
            r['cleanup_state']=observe_stopped(c,address=1,timeout_s=5)
            r['restored']=restore_profile(c,timeout_s=5)
        else:
            r['cleanup']='unknown: framing lost; no replay'

run_recorded(port='COM13',out=Path(sys.argv[1]),scenario='rounded-simple-motion',
    inputs={'move_deg':100,'expected_native':278,'zero_steps':'0.1','return_deg':0,'speed_rpm':60,'ramps_ms':100},run=run,refresh=False,
    firmware=Path('build/ownership_fix/pio/bench_s3_load_timer/firmware.bin'))
