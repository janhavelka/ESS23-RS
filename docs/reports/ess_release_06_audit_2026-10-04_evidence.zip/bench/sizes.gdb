set language c++
p sizeof('(anonymous namespace)::App')
p sizeof('(anonymous namespace)::App::Record')
p sizeof(MotorControlRSExample::Probe::Console)
p sizeof(MotorControlRS::ESS_RS::ReadContext)
p sizeof(MotorControlRS::ESS_RS::IdentityObservation)
p sizeof(MotorControlRS::ESS_RS::ConfigObservation)
p sizeof(MotorControlRSExample::Probe::StateCache)
p sizeof(MotorControlRS::ESS_RS::StateObservation)
quit
