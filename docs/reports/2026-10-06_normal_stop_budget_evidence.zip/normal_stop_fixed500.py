import sys,time,json
from pathlib import Path
sys.path.insert(0,'scripts')
from bench_session import run_recorded,checked
from bench_probe import observe_stopped
from bench_motion import profile_snapshot
sys.path.insert(0,'build/completion_followup')
from human_helpers import human,move,subdivision

def run(c,r):
 subdivision(c,1600)
 r['before_profile']=profile_snapshot(c)
 checked(c,'motion-profile',host_args=('forget',))
 for key,value in [('speed',60),('accel',100),('decel',500)]:human(c,f'{key} {value}',lambda s:'Use settings to compare' in s)
 move(c,'moveby 9 deg')
 checked(c,'stop',stop_policy='fast',address=1)
 checked(c,'motion-profile',host_args=('forget',))
 r['profile']=profile_snapshot(c);observe_stopped(c,address=1,timeout_s=5)
 m=c.begin('move-relative',address=1,move_args=('4000','steps','native','60','configured'),timeout_s=45)
 r['move_id']=m.operation_id
 for _ in range(20):
  s=checked(c,'read-state',address=1)
  if s['state_blocks'][0]['running']:break
  time.sleep(.05)
 st=c.begin('stop',address=1,stop_policy='normal',timeout_s=10)
 r['samples']=[];start=time.monotonic()
 try:
  for _ in range(32):
   s=checked(c,'read-state',address=1);b={x['block']:x for x in s['state_blocks']}
   r['samples'].append(dict(elapsed=time.monotonic()-start,motion=b[0]['raw_motion'],speed=b[2]['raw_speed'],position=b[2]['raw_position']))
   time.sleep(.1)
  r['stop']=c.wait(st,release=True);r['move']=c.wait(m,release=True)
  assert r['stop']['ok'] and r['stop']['completion']=='observed'
  r['workload_verified']=True
 finally:
  if c.synchronized:
   r['fast_stop']=checked(c,'stop',address=1,stop_policy='fast');r['final']=observe_stopped(c,address=1,timeout_s=5)
run_recorded(port='COM13',out=Path('build/night_20261006/normal-stop-fixed500'),scenario='normal-stop-observation-timing',inputs={'ramp_from_readback':True,'stop_attempts':1,'samples':25,'interval_s':.1,'final_cleanup':'separate fast stop'},run=run)
