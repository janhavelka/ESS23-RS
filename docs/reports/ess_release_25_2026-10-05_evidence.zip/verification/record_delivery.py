import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

root = Path.cwd()
work = root / 'build/p25'
report = root / 'docs/reports/ess_release_25_2026-10-05'

def read(name):
    return json.loads((work / name).read_text())

before = read('arduino-before.json')
quick = read('idf-release-quick.json')
control = read('idf-release-control.json')
assert before['ok'] and quick['ok'] and control['ok']
for family in ('identity', 'config', 'state'):
    original = [step['rx'] for step in before['after'][family]['steps']]
    final = [step['rx'] for step in control['after'][family]['steps']]
    assert original and original == final
    assert all(step['qualified'] and step['tx'].startswith('0103')
               for step in control['after'][family]['steps'])
assert control['after']['stats']['frames'] == 49
assert control['after']['stats']['failed'] == 0
assert not control['after']['drv']['transmit_enabled']
assert not control['after']['drv']['recovery_required']
assert all(control['after']['drv'][key] == 0 for key in ('pending', 'retained', 'reserved'))
assert control['after']['load']['workload_us'] == 0
assert control['after']['load']['owner_delay_us'] == 0
assert control['after']['load']['console_bytes'] == 0

# Passive stats precede the final typed diagnostic reads. Count terminal wire
# evidence rather than treating that sampled counter as the campaign total.
physical = {}
for log in ('idf-release-quick.jsonl', 'idf-release-control.jsonl'):
    for line in (work / log).read_text().splitlines():
        item = json.loads(line)
        if item.get('event') != 'line' or not item['text'].startswith('{'):
            continue
        record = json.loads(item['text'])
        kind = record['type']
        if kind == 'probe':
            assert record['ok'] and record['codec'] == 'OK' and record['transport'] == 'FRAME'
            assert record['tx_hex'].startswith('0103')
            evidence = [(0, record['rx_hex'])]
        elif kind == 'read':
            assert record['ok']
            evidence = []
            for step in record['steps']:
                assert step['qualified'] and step['status'] == 'OK' and step['tx'].startswith('0103')
                evidence.append((step['step'], step['rx']))
        elif kind == 'control':
            assert record['ok']
            evidence = []
            for values in record['evidence']:
                step = dict(zip(record['evidence_columns'], values))
                assert step['write'] is False and step['qualified'] and step['status'] == 'OK'
                assert step['detail'] == 0 and step['frame_error'] == 0
                evidence.append((step['step'], step['raw_hex']))
        else:
            continue
        for step, raw in evidence:
            assert raw.startswith('0103')
            key = (record['operation_id'], step)
            if key in physical:
                assert physical[key] == raw
            physical[key] = raw
assert len(physical) == 58
assert sum(len(raw) // 2 for raw in physical.values()) == 594

commands = json.loads((work / 'core-consumer/compile_commands.json').read_text())
isolated = [item for item in commands if 'core-package' in item['file'] or 'idf_consumer' in item['file']]
assert len(isolated) == 19
assert all('examples' not in item['command'] and 'vendor' not in item['command'] for item in isolated)

backup = read('original-image/manifest.json')
assert backup['application'] == '4ae880946615c4828992f864e983da36417123df39c15c82a045dd38f30487d3'
image = work / 'idf-final/motorcontrol_probe.bin'
assert hashlib.sha256(image.read_bytes()).hexdigest() == quick['firmware_artifact']['sha256']
sdkconfig = root / 'examples/probe_idf/sdkconfig'
summary = {
    'prompt': 25,
    'baseline': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'final_revision': 'commit containing this report',
    'implementation': 'PASS',
    'verification': {'ctest_suites': 66, 'ctest': 'PASS', 'generator_cases': 18,
                     'probe_python_cases': 233, 'arduino_environments': ['bench_s3_probe', 'bench_s3_load_poll', 'bench_s3_load_timer'],
                     'clean_native_firmware': 'PASS', 'clean_core_only_idf_consumer': 'PASS',
                     'isolated_public_headers': 27, 'isolated_compilation_units': 19},
    'sdk': {'idf': '5.5.5', 'xtensa': '14.2.0+20260121', 'esptool': '4.12.0',
            'sdkconfig_sha256': hashlib.sha256(sdkconfig.read_bytes()).hexdigest(),
            'sdkconfig_archive': 'native/sdkconfig'},
    'firmware': quick['firmware_artifact'],
    'previous_image_backup': backup,
    'physical_results': {'scope': 'read-only', 'final_image_frames': len(physical),
                         'final_image_rx_bytes': sum(len(raw) // 2 for raw in physical.values()),
                         'last_sampled_stats_frames': 49, 'last_sampled_stats_rx_bytes': 497,
                         'stats_sample_precedes_final_typed_reads': True,
                         'physical_terminal_evidence': [{'operation_id': op, 'step': step, 'rx': raw}
                                                       for (op, step), raw in physical.items()],
                         'probes': quick['campaigns'][0]['latency_us'],
                         'raw_identity_configuration_state_unchanged': True,
                         'first_startup_smoke': 'FAIL: retained bootloader fragment concatenated with version JSON',
                         'startup_root_cause_fixed': True,
                         'ending': control['after'],
                         'native_motion_load_parity': 'NOT RUN: prompt26',
                         'whole_flash_rollback': 'NOT RUN',
                         'shaft_electrical_evidence': 'unmeasured'},
    'storage_sizes': {'app_psram': 206528, 'uart_internal': 1720, 'load_internal': 4816,
                      'owner_stack_internal': 8192, 'owner_tcb_internal': 352},
    'core_isolation_commands': isolated,
    'automatic_motor_write_replay': False,
    'fieldcore_read_only_revision': 'd19758865852f4e215ea05c6572d060edc4f0c66',
}
report.with_suffix('.json').write_text(json.dumps(summary, indent=2) + '\n')

archive = Path(str(report) + '_evidence.zip')
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as bundle:
    for entry in sorted(work.iterdir()):
        if entry.is_file() and entry.suffix in ('.log', '.txt', '.json', '.jsonl'):
            bundle.write(entry, 'runs/' + entry.name)
    for name in ('manifest.json', 'firmware-original.bin', 'bootloader-region.bin', 'partition-region.bin'):
        bundle.write(work / 'original-image' / name, 'previous-image/' + name)
    for name in ('motorcontrol_probe.bin', 'motorcontrol_probe.elf', 'flasher_args.json', 'flash_args',
                 'bootloader/bootloader.bin', 'partition_table/partition-table.bin', 'ota_data_initial.bin', 'project_description.json'):
        bundle.write(work / 'idf-final' / name, 'native/' + name)
    bundle.write(sdkconfig, 'native/sdkconfig')
    bundle.write(root / 'examples/probe_idf/sdkconfig.defaults', 'native/sdkconfig.defaults')
    bundle.write(work / 'idf-tools/espidf.constraints.v5.5.txt', 'native/python-constraints.txt')
    for name in ('motorcontrol_core_consumer.bin', 'compile_commands.json'):
        bundle.write(work / 'core-consumer' / name, 'core-consumer/' + name)
print('Recorded final58 frames, exact unchanged FC03 raw data, verified image/backup, core-only isolation.')
print('Archive bytes:', archive.stat().st_size)
