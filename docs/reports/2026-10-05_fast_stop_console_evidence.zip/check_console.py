import sys, time, re, json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'scripts'))
from bench_probe import BenchError, observe_stopped
from bench_session import run_recorded, checked
from bench_motion import restore_profile

def human(c, text, terminal=None, timeout=7):
    assert not c.pending and not c.buffer
    c.emit('human_command', text=text)
    c.port.write((text+'\n').encode())
    end=time.monotonic()+timeout; quiet=end; data=bytearray()
    while time.monotonic()<end:
        chunk=c.port.read(8192)
        if chunk:
            data.extend(chunk); quiet=time.monotonic()+.1
        decoded=data.decode('utf-8')
        if data and time.monotonic()>=quiet and (terminal is None or terminal in decoded):
            c.emit('human_output', text=decoded); print(text+'\n'+decoded,flush=True); return decoded
        time.sleep(.005)
    c.emit('human_output',text=data.decode('utf-8',errors='replace'))
    raise BenchError('human terminal missing for '+text)

def campaign(c,r):
    menu=human(c,'help'); r['help']=menu
    for name in ('stop','moveby','moveto','settings','debug','driver'):
        assert len(re.findall(r'^  '+re.escape(name)+r'\s',menu,re.M))==1
    assert 'stop fast' not in menu or 'fast' in menu
    r['stop_help']=human(c,'help stop')
    assert 'normal|fast' in r['stop_help'] and 'without the ramp' in r['stop_help']
    assert 'direct' not in r['stop_help']
    before=checked(c,'stats'); r['removed']={}
    for old in ('?','ver','ping','reset','help advanced','health check','profile ess_rs enable','profile ess_rs driver read','stop direct'):
        output=human(c,old); r['removed'][old]=output
        assert 'ERROR' in output
    after=checked(c,'stats'); r['alias_stats']=[before,after]
    for key in ('started','frames','failed','timeouts','rx_bytes','capture_faults','rx_errors'):
        if key in before: assert before[key]==after[key]
    r['settings']=human(c,'settings','Details:')
    assert 'Microstep / subdivision: 1000' in r['settings']
    wrapper=int(re.search(r'Details: @1 result (\d+)',r['settings']).group(1))
    checked(c,'release',operation_id=wrapper)
    r['identity']=checked(c,'read-identity',address=1)
    r['config']=checked(c,'read-config',address=1)
    r['before_stop']=observe_stopped(c,address=1,timeout_s=5)
    r['fast_stop']=checked(c,'stop',stop_policy='fast',address=1)
    assert r['fast_stop']['completion']=='observed' and r['fast_stop']['execution']=='acknowledged' and not r['fast_stop']['write_evidence']['execution_unknown']
    r['after_stop']=observe_stopped(c,address=1,timeout_s=5)
    r['probes']=[checked(c,'probe',address=1) for _ in range(3)]
    r['workload_verified']=True

plan=dict(moves=0,stop_writes=1,probes=3,
          pass_criteria='unique help entries; removed aliases reject without traffic; actual subdivision displayed; fast stop completes; drive reports standstill; three probes pass',
          automatic_write_replay=False,electrical_and_shaft_observation='unmeasured')
print(json.dumps(plan),flush=True)
run_recorded(port='COM13',out=Path(sys.argv[1]),scenario='canonical-console-fast-stop',
             inputs=plan,run=campaign,refresh=False,
             firmware=Path('build/fast_cli/pio/bench_s3_load_timer/firmware.bin'))
