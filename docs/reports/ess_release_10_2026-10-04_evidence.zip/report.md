# Prompt10: absolute coordinates, wrapped paths and explicit device clear

Baseline `451a61d`, including the independently audited 07–09 APIs. The final
commit is the commit introducing this report and its evidence. Only prompt10
was executed; prompt11 was not started. Implementation, native/package/build
checks and available read-only COM13 regression: **PASS**. Physical absolute/
wrapped moves, equivalent-unit shaft comparisons and device clear: **NOT RUN**.
Independent electrical/FC06 source, command/feedback sign/basis, ramp and input
qualification, with usable physical stop evidence, remain prerequisites. Linear
travel is unqualified without a configured mechanism. No missing measurement
was replaced by an encoder-derived or simulated physical claim.

[Structured results](ess_release_10_2026-10-04.json) and
[evidence archive](ess_release_10_2026-10-04_evidence.zip) retain exact console
lines, raw FC03 traffic, source/tests, original-manual page renders, firmware,
diagnostics, verification commands and SHA-256 manifests. Historical evidence
and original vendor files are unchanged.

## Delivered APIs and ownership

`Axis.h` adds consumed `PositionRequest.wrapped`, `AnglePath` and `HalfTurnTie`
to the existing pure `preparePosition`. Ordinary absolute values preserve
turn count:720 degrees is two turns. Wrapped MOTOR/LOAD turns/degrees/radians
require host origin and fresh multi-turn command coordinates. Positive/negative
follow selected-frame polarity; shortest half-turn rejects unless an exact tie
direction is explicit. Same orientation stays in place for every path. Chosen
path/requested/rounded limits never cause a different revolution or direction.
EXACT remains default; all rounding uses the existing quantizer. Radians require
bounded explicit approximation; an interval crossing equality/half-turn/rounding
or limits rejects. Portable modular arithmetic is bounded to64 iterations and
supports rational turn periods and exact int64 references. Reduced products
outside fixed64-bit storage return overflow, never an approximate substitute.

`ESS_RS::prepareMoveAbsolute` and `prepareMoveAngle`, with common wrappers, reuse
`prepareMoveRelative`'s staging/trigger/observation executor in `Position.h`.
The shared helper validates the whole request before yielding work. Absolute
motion requires stationary established ACTUAL command coordinates; it does not
depend on unrelated relative-basis qualification. COMMANDED/QUEUED relative
execution remains unsupported. Both writes use the immutable readiness-capped
deadline; a consumed reference must cover that budget at supplied admission
time. `MoveContext.reference` owns an immutable copy; caller stack lifetime is
irrelevant. Later reads retain the original operation deadline, including
on-time physical trigger evidence delivered after starting-reference expiry.
The application keeps one cooperative UART owner, queue and same-axis
reservation; no second scheduler, framework API or retry path was added.

The reviewed FC10 window remains0x0021/count5. Trigger is0x0027/value1 relative
or value5 absolute (START|ABSOLUTE, no interrupt bit); checked echoes must match.
Completion still needs a new RUNNING observation followed by stopped/arrived,
not an old arrival, target equality or trigger acknowledgement. Applied setup,
uncertain trigger and failed completion retain distinct evidence. Stop uses
08's reserved path, with frame settlement and separate outcomes.

`ESS_RS::prepareSetDevicePosition` and its common wrapper in `Actions.h` are
explicit zero-only preparations. Nonzero counter requests reject unchanged.
Caller qualification and the application's separate semantic/readiness gate
precede the auxiliary clear0x002D/value49. A checked ACK is followed by new
FC03 current-position0x000A/count2 observations; both words must be zero.
`rawPosition` concatenates first wire word then second, without claiming decoded
word order or signed coordinates. Zero testing is independent of those unknowns.
Clear establishes neither homing, host origin nor command-feedback mapping.
A lost ACK stays UNKNOWN and never retries, including across recovery/release.

`setAxisOrigin` remains a host-only exact native integer operation with fresh
idle/stationary native evidence. `invalidateAxisReference` clears origins,
derived limits and reference confidence, preserving scales/preferences and
advancing generation. Zero/exhausted generations cannot revive or wrap. The
application invalidates accepted release/clear immediately, expired/lost
reference, observed external RUNNING or changed current-target feedback, and
relevant settings. Trigger TX immediately removes live native pose confidence;
terminal motion drops dependent origins/limits without altering the admitted
reference/result. Its starting-reference expiry cannot cancel an already
triggered move. Cached queries and origin updates never rejuvenate timestamps.

The existing console exposes `move relative|absolute|angle`, matching
`profile ess_rs move-relative|move-absolute|move-angle`, pure `prepare angle`,
and `position-clear` / `profile ess_rs clear-position`. All steps/fullsteps/
turns/degrees/radians/configured travel use the same public preparation, with
strict exact-number parsing. See [actual syntax](../ess_position.md),
[host previews](../axis_preparation.md) and [clear action](../ess_actions.md).
Python extends its existing one-attempt finite campaign to all three move kinds,
retained proof and explicit cleanup. It preserves strict correlation and poisons
framing on interrupted/malformed sessions; no automatic retry/recovery occurs.

## Requirement and failure coverage

| Requirement / failure scenario | Production path and actual API | Native/build evidence | Hardware result and artifact | Remaining proof |
| --- | --- | --- | --- | --- |
| Multi-turn absolute target, explicit frames and current reference | `preparePosition`, common/native `prepareMoveAbsolute`, copied `AxisReference` | 720-degree target2000 from1990 retains displacement10; signed extremes, rational factors, origin overflow, stale target/config/basis/age and unchanged output PASS | Absolute gate returns ID0 before TX PASS | Qualified actual command-coordinate source/sign and physical endpoint |
| Wrapped paths, half-turn ties, same-angle and limits | Shared exact/approximate angle branches in `Axis.cpp`; same absolute executor | More than51000 independent integer-oracle cases; fractional gear periods, negative polarity, int64 wrap extremes, all paths/ties, no alternative path on limits, zero after rounding, radian ambiguity PASS | Wrapped preview/origin reject missing evidence; move gate zero TX PASS | Independent shaft/path comparison |
| Observable relative bases only, no stale endpoint conversion | Existing relative-basis mask and profile ACTUAL-only preparation | COMMANDED/QUEUED execution unsupported; wrong/mismatched reference and generation reject; unbounded native relative needs no unrelated metadata PASS | Qualification gate retained PASS | Actual firmware relative basis |
| Shared mover, absolute flags, reservation and stop | Existing `nextMove`/`advanceMove`, application action loop/axis write adapter | Staging/trigger fault boundaries, absolute wrong-relative echo, uncertain writes/no replay, second-producer conflicts and existing stop/cancel/result-pressure suites PASS | Existing read-only traffic/configuration unaffected PASS | Physical trigger/completion and dynamic stop |
| Host origin separate from device zero clear | `setAxisOrigin`; zero-only `prepareSetDevicePosition`, existing action service | Actual application origin update emits no traffic, preserves old observation time; clear nonzero/false-qualified reject; ACK alone and nonzero pair never complete; stale/bad readback and lost ACK/recovery remain uncertain PASS | Host-origin gate and explicit clear timing gate emit zero TX PASS | Physical clear behavior and established command origin |
| Reference invalidation without cancelling timely triggered motion | `invalidateAxisReference`, `serviceCoordinates`, read/action harvesting | Repeated generation0/max invalidation cannot revive; released/external RUNNING, new current-target raw-position change, foreign-target isolation, settings and age loss; triggered move observes past starting-reference age PASS | Passive ages increase; raw zero never establishes reference PASS | Fresh physical position relation after release/clear/motion |
| All spatial units and common/native CLI/direct API parity | Existing console callback and shared preparation/mover | Actual application steps/fullsteps/turn/deg/rad/mm all resolve to same20-native target; common/profile paths and independent direct API compare PASS | Pure1-step/0.36-degree/0.006283185307179586-radian previews agree under ASSUMED1000 scale PASS | Physical equivalent-unit movement; real linear mechanism |
| Bounded storage, installed public API and strict Python proof | Caller-owned contexts; portable/public headers; bounded console | Installed consumer uses absolute/angle/clear/invalidation with no example include path;142 Python cases, maximum move line4287/4608; existing backpressure/reserved-stop tests PASS | Current memory/stack/gap diagnostics retained PASS | Future soak and moving-path resource qualification |

## Independent review and corrections

Coordinate/path and CLI/direct-API agents authored disjoint paths. The source/
manual reviewer independently inspected the final source/test diff and actual
callers, including code it did not author. Cross-review covered core/app
deadlines, reference lifetime, invalidation, numerical limits, help/dispatch,
correlation, no-change effects and simplicity. Root checked the actual findings.

- Wrapped requests now reject a reference whose basis differs from the request.
- Repeated invalidation initially revived disabled generation0; the shared
  increment guard rejects both0 andUINT32_MAX, with standalone and actual-app
  regressions.
- Live reference confidence is dropped at accepted trigger TX; expiring its
  admission witness no longer cancels the move's autonomous observation phase.
- Python initially expected clear value0x22; the documented0x31 ACK is now
  checked using a literal independently CRC-verified vector. Preview output now
  reports `wire_motion:not_requested` rather than stale `unimplemented`.
- Exact zero-radian requests retain an explicitly supplied approximation
  allowance in JSON without falsely claiming approximate arithmetic.
- Current-target feedback comparison cannot invalidate an axis using a foreign
  previous observation. Released state cannot qualify host stationary evidence.
- The missing-origin test now uses an engineering frame: native absolute steps
  legitimately need no unrelated host origin.

Final independent review found no further confirmed defects. Exact conversion
and quantization are shared; only explicit path policy/modular calculation was
added. Generated register/type files were not edited. The coverage inventory
remains ledger-linked:221 records,135 named choices,8 implemented choices and
127 not implemented. Reads do not count as writes/actions; hardware is separate.

Original function PDF physical pages13–16,26,68–72 were visually reviewed, with
fresh renders and source SHA-256 in the archive. Current FieldCore read-only
HEAD is `7c356aff59132ab7ab7be6e3ec26a599ede6b99e`. Actual
`Rs485OwnerTransaction.h`/`Rs485Task.cpp` retain request/WaitUntil, deadline-before-
configure/clear/write and bounded ownership vocabulary. Deliberate differences:
19-byte ESS staging, same-axis multi-step reservation, checked full FC06 echoes,
qualified physical closure and retained uncertainty, with no sensor retry or
prefix-echo policy and no FieldCore/product/framework types. FieldCore was not
edited.

## Verification, image and bench evidence

GCC15.1 C++11, warnings as errors:23 CTest suites PASS;142 Python harness cases,
eight generator negative cases and13 inventory cases PASS. Version/catalogue,
coverage and five contrasting-reference checks PASS. Installed-core consumer
build/test PASS. Four PlatformIO environments (`bench_s3_units`, `bench_s3_probe`,
`bench_s3_load_poll`, `bench_s3_load_timer`) build PASS; upload verified hashes.

COM13 USB303A:1001, serial3C:0F:02:CD:6B:98; firmware0.6.0/protocol2,
TX47/RX48/DE21, UART2, node1 at1152008N1,20-us timer capture. Image418432 bytes,
SHA-256 `371dd0eba5442bf60f2d82389cbc8293cdad4c3deeed1f7298f6477f2b532bbd`.
The original16MiB CO2control backup retains
`85c089bc3956b22037af7e6f0d7945f6ed778bb1a0526fb5b2ba3e8fea02d0c1`.
Preflight used local controls only, without fault/statistics reset or recovery.

The successful campaign performed28 FC03 frames/288 RX bytes, then10 further
one-attempt probes. Its earlier script attempt completed9 successful read-only
frames/97 bytes before a `KeyError`: the new helper expected nested `prepared`
instead of the existing top-level `effective_native`. Exact failed-attempt lines
are retained. Root corrected the helper, deliberately reran the bounded
read-only scenario and retained both runs. This was a report-script defect;
no transport/motor failure, hidden retry or uncertain motor write occurred.
Final counters47 frames/455 RX bytes, zero failures/timeouts/cancels, capture
faults/RX errors/echo/discarded bytes. Motor config/state reply payloads match
before/after: model4EEA, firmware0029, subdivision1000, encoder setting4000,
algorithm3 unknown, inputs1/2/3/0, raw alarm0/motion1 and position/speed0.
Raw non-running/zero values are drive reports, not independent physical proof.

Four move gates and six action gates rejected before TX, plus the finite harness
rejection with no cleanup write. Local host scale1000 and ACTUAL basis were
explicitly ASSUMED declarations. Pure equivalent previews resolved to1 native
increment; neither declarations nor raw readback lifted production qualification.
Origin0 and wrapped preview rejected missing command-coordinate evidence.
Repeated cached reports preserve observed timestamps while ages increase.
Ten campaign probes took5478–5693us in the runner. Raw console/host round trips,
closure bounds and delivery times are in JSONL; no stop-latency claim is made.

| Storage / memory | ESP32-S3 / native bytes |
| --- | ---: |
| `AxisConfig` / `AxisReference` |184/184 and64/64 |
| `PositionRequest` / `PreparedTarget` |64/64 and192/192 |
| `MoveContext` / `PreparedMove` / `MovePrerequisites` |888/1008,72/80,56/56 |
| `ActionContext` |360/432 |
| PSRAM `App` / record / console |81184 /2016 /10776 |
| Internal `Esp32S3Uart` |1704 (unchanged) |

Console line capacity increased512 bytes to4608 because reference/path provenance
made the existing4096 bound insufficient; tested maximum4287. Input remains
128 bytes including terminator/20 tokens,32 input and64 output bytes per loop.
The App holds ten bounded frontend records (eight ordinary, polling and reserved
stop), one existing owner and eight4609-byte output lines in PSRAM. No per-command
core/application heap, extra task/queue or stack increase was introduced.

Ending internal free/minimum336104/330944 bytes, largest278516; PSRAM
free/minimum8304172, largest8257524. Owner stack headroom3572, worker3268;
owner/capture maximum gaps143/56us, capture threshold85us, no exceedance.
Owner loop static frame784 bytes. New copied-reference/context and bounded
output storage increases PSRAM use by6144 bytes versus the audited09 image.
Moving-path stack/resource qualification remains separate from these read-only
measurements. Ending load0/0/0, monitor off, DE released, owner pending/retained/
reserved0, no axis reservation/recovery requirement and no input/output drops.
Read-only cleanup is settled; physical move/stop/clear cleanup was not exercised.

## Handoff to11

Reuse `Axis.h`, `MoveOperation.h`, `ESS_RS::Position.h` and `Actions.h`, their
supplied-event/caller-owned contracts, immutable original deadlines and the
existing application reservation/priority stop path. Preserve rational input,
requested/effective target, copied source/reference and original generation.
After device clear/release or lost pose confidence, obtain new qualified command
coordinates before reference-dependent work; a checked zero is not an origin.

Unknown algorithm3, firmware0029, negative encoding/command-feedback relation,
native speed/ramp scaling, external input effects, electrical/FC06 source proof
and independent physical stop remain unresolved hardware prerequisites.
Velocity/ramp semantics belong to11. Linear travel needs its real mechanism;
free-shaft motion cannot qualify it. Existing model/encoder specifications are
documented and user-confirmed; missing IC identification is not a prerequisite
for pure arithmetic. No setting or default was changed to hide missing evidence.
