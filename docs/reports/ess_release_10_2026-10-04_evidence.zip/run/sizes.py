﻿from pathlib import Path
import subprocess,re,json
root=Path.cwd(); here=root/'build/bench/ess10'
source=here/'core_sizes.cpp'
cached=(root/'build/native/CMakeCache.txt').read_text()
native=re.search(r'^CMAKE_CXX_COMPILER:FILEPATH=(.+)$',cached,re.M).group(1)
results={}
for label,compiler,nm in [('native',native,str(Path(native).with_name('nm.exe'))),('xtensa','C:/pio/packages/toolchain-xtensa-esp32s3/bin/xtensa-esp32s3-elf-g++.exe','C:/pio/packages/toolchain-xtensa-esp32s3/bin/xtensa-esp32s3-elf-nm.exe')]:
    obj=here/(label+'-sizes.o')
    subprocess.run([compiler,'-std=c++11','-Iinclude','-c',str(source),'-o',str(obj)],check=True)
    out=subprocess.check_output([nm,'-S','--radix=d',str(obj)]).decode()
    (here/(label+'-sizes.txt')).write_text(out)
    results[label]={m.group(2).strip():int(m.group(1)) for m in re.finditer(r'^\d+\s+(\d+)\s+B\s+(.+)$',out,re.M)}
subprocess.run([native,'-std=c++11','-Iinclude',str(here/'native_sizes.cpp'),'-o',str(here/'native_sizes.exe')],check=True)
results['native']=json.loads(subprocess.check_output([str(here/'native_sizes.exe')]).decode())
(here/'sizes.json').write_text(json.dumps(results,indent=2)+'\n'); print(results)
gdb=['C:/pio/packages/tool-xtensa-esp-elf-gdb/bin/xtensa-esp32s3-elf-gdb.exe','-q','-batch','-x',str(here/'sizes.gdb'),'.pio/build/bench_s3_load_timer/firmware.elf']
(here/'application-sizes.txt').write_bytes(subprocess.check_output(gdb))
