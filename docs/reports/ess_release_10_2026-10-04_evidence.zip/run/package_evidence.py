import hashlib, json, subprocess, zipfile
from pathlib import Path

root = Path.cwd()
here = root / 'build/bench/ess10'
reports = root / 'docs/reports'
stem = 'ess_release_10_2026-10-04'
sha = lambda data: hashlib.sha256(data).hexdigest()
summary = {key: json.loads((here / name).read_text()) for key, name in (
    ('preflight', 'preflight.json'), ('campaign', 'summary.json'), ('ending', 'ending.json'),
    ('sizes', 'sizes.json'), ('verification_commands', 'verify-final.json'),
    ('firmware_build', 'firmware-build.json'), ('upload', 'upload.json'),
    ('manual_review', 'manual_review_manifest.json'))}
ending, campaign = summary['ending'], summary['campaign']
assert ending['stats']['frames'] == 47 and ending['stats']['rx_bytes'] == 455
for group, keys in (
    ('stats', ('failed', 'timeouts', 'cancelled', 'capture_faults', 'rx_errors', 'echo_bytes', 'discarded')),
    ('drv', ('busy', 'transmit_enabled', 'recovery_required', 'pending', 'retained', 'reserved',
             'input_dropped', 'output_blocked', 'output_short_writes'))):
    assert not any(ending[group][key] for key in keys)
assert ending['memory']['stack_free_bytes'] == 3572 and ending['load']['work_stack_free_bytes'] == 3268
assert [ending['load'][key] for key in ('workload_us', 'owner_delay_us', 'console_bytes')] == [0, 0, 0]
assert not ending['caps']['actions_qualified'] and not ending['caps']['axis_reserved']
assert campaign['cached_second']['status']['monitoring'] == 'disabled'
for command in ('status', 'health'):
    for first, second in zip(campaign['cached_first'][command]['state_blocks'], campaign['cached_second'][command]['state_blocks']):
        assert first['observed_earliest_us'] == second['observed_earliest_us']
        assert first['observed_latest_us'] == second['observed_latest_us']
        assert second['age_us'] > first['age_us']
for name in ('configuration', 'state'):
    assert [step['rx'] for step in campaign[name + '_before']['steps']] == [step['rx'] for step in campaign[name + '_after']['steps']]
for result in summary['verification_commands']:
    assert result['exit'] == 0
assert summary['firmware_build']['exit'] == summary['upload']['exit'] == 0
assert all(item['effective_native'] == 1 for item in campaign['pure_equivalence'])
assert all(item['result'] == 'timing_unqualified' and item['operation_id'] == 0
           for item in campaign['move_gates'] + campaign['action_gates'])
probes = campaign['probes']
range_of = lambda values: {'minimum': min(values), 'maximum': max(values)}
summary['delivery'] = {
    'baseline': '451a61d', 'final_commit': 'The commit introducing this report and evidence',
    'scope': 'Prompt10 only. Prompt11 not started. No motor settings/motion/clear writes performed.',
    'native': {'result': 'PASS', 'ctest_suites': 23, 'python_cases': 142, 'generator_cases': 8,
               'inventory_cases': 13, 'compiler': 'GCC15.1.0', 'language': 'C++11', 'flags': '-Werror'},
    'installed_consumer': {'result': 'PASS', 'tests': 1, 'example_include_path': False},
    'firmware_environments': {env: 'PASS' for env in ('bench_s3_units', 'bench_s3_probe', 'bench_s3_load_poll', 'bench_s3_load_timer')},
    'hardware': {'readonly': 'PASS', 'zero_TX_gates': 'PASS', 'host_arithmetic_equivalence': 'PASS',
                 'absolute_wrapped_motion': 'NOT RUN', 'physical_steps_degrees_radians_equivalence': 'NOT RUN',
                 'physical_origin_clear_effects': 'NOT RUN', 'independent_shaft_comparison': 'NOT RUN',
                 'dynamic_stop': 'NOT RUN', 'linear_travel': 'NOT RUN'},
    'hardware_reason': 'Independent timing/FC06 source, sign/basis/ramp/input and physical stop qualification absent; linear mechanism unavailable.',
    'probe_runner_duration_us': range_of([p['duration_us'] for p in probes]),
    'probe_delivery_after_closure_us': range_of([p['delivered_us'] - p['observed_latest_us'] for p in probes]),
    'probe_closure_interval_width_us': range_of([p['observed_latest_us'] - p['observed_earliest_us'] for p in probes]),
    'fieldcore_read_only_head': '7c356aff59132ab7ab7be6e3ec26a599ede6b99e',
    'public_layout_changed': True, 'maximum_move_line_bytes': 4287, 'move_line_capacity': 4608,
    'psram_app_bytes': 81184, 'record_bytes': 2016, 'console_bytes': 10776, 'internal_capture_object_bytes': 1704,
    'owner_loop_frame_bytes': 784, 'backup': {'bytes': 16777216, 'sha256': summary['preflight']['backup_sha256']},
    'independent_review': ['coordinate/path reviewer', 'CLI/direct-API reviewer', 'source/manual reviewer of frozen integrated source and tests'],
    'script_failure': {'cause': 'Local campaign expected nested prepared instead of existing top-level effective_native.',
                       'artifact': 'run/campaign_script_failure.jsonl', 'frames': 9, 'rx_bytes': 97,
                       'transport_errors': 0, 'uncertain_motor_write': False, 'corrected_readonly_rerun': 'PASS'},
}
(reports / (stem + '.json')).write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
(here / 'integrated.diff').write_bytes(subprocess.check_output(['git', 'diff', '--', '.', ':!docs/reports/*']))
members = {}
def add(path, name):
    members[name] = path.read_bytes()
for path in here.iterdir():
    if path.is_file() and path.suffix not in ('.exe', '.o'):
        add(path, 'run/' + path.name)
for directory in ('src', 'include', 'examples', 'scripts', 'test'):
    for path in (root / directory).rglob('*'):
        if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc':
            add(path, 'source/' + path.relative_to(root).as_posix())
for name in ('CMakeLists.txt', 'platformio.ini', 'library.json', 'AGENTS.md', 'README.md', 'CHANGELOG.md',
             'docs/ess_position.md', 'docs/ess_actions.md', 'docs/axis_contract.md', 'docs/axis_preparation.md',
             'docs/architecture.md', 'docs/profile_contract.md', 'docs/cli_contract.md', 'docs/esp32_probe.md',
             'docs/hardware_bench.md', 'docs/backlog.md', 'docs/roadmap.md', 'docs/README.md',
             'docs/reference/ess_rs_operations.json', 'docs/reference/sources.json',
             'docs/reference/01_implementation_reference.md', 'docs/reference/09_timing_and_gap_audit.md',
             'docs/prompts/ess_release/10_absolute_angle_and_origins.md',
             'docs/prompts/ess_release/execution_contract.md', 'docs/prompts/ess_release/README.md'):
    add(root / name, 'source/' + name)
for env in summary['delivery']['firmware_environments']:
    for name in (('firmware.bin', 'firmware.elf') if env == 'bench_s3_load_timer' else ('firmware.bin',)):
        add(root / '.pio/build' / env / name, 'firmware/' + env + '/' + name)
for path, name in (('build/native/Testing/Temporary/LastTest.log', 'native.log'),
                   ('build/native/CMakeCache.txt', 'native_cache.txt'),
                   ('build/installed_consumer10/Testing/Temporary/LastTest.log', 'installed_consumer.log')):
    add(root / path, 'verification/' + name)
add(reports / (stem + '.md'), 'report.md')
add(reports / (stem + '.json'), 'report.json')
manifest = {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(members.items())}
archive = reports / (stem + '_evidence.zip')
assert not archive.exists(), 'Do not replace an existing evidence archive'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in sorted(members.items()):
        z.writestr(name, data)
    z.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name, expected in manifest.items():
        data = z.read(name)
        assert len(data) == expected['bytes'] and sha(data) == expected['sha256']
print(json.dumps({'bytes': archive.stat().st_size, 'members': len(manifest), 'sha256': sha(archive.read_bytes())}))
