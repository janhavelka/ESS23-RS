set language c++
p sizeof('(anonymous namespace)::App')
p sizeof('(anonymous namespace)::App::Record')
p sizeof(MotorControlRSExample::Probe::Console)
p sizeof(MotorControlRS::AxisConfig)
p sizeof(MotorControlRS::AxisReference)
p sizeof(MotorControlRS::PositionRequest)
p sizeof(MotorControlRS::PreparedTarget)
p sizeof(MotorControlRS::ESS_RS::MoveContext)
p sizeof(MotorControlRS::ESS_RS::PreparedMove)
p sizeof(MotorControlRS::ESS_RS::MovePrerequisites)
p sizeof(MotorControlRS::ESS_RS::ActionContext)
p sizeof(MotorControlRSExample::Esp32S3Uart)
quit
