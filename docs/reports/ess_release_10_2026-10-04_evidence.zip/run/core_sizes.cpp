#include <MotorControlRS/profiles/ess_rs/Position.h>
extern "C" {
unsigned char move_context_bytes[sizeof(MotorControlRS::ESS_RS::MoveContext)];
unsigned char prepared_move_bytes[sizeof(MotorControlRS::ESS_RS::PreparedMove)];
unsigned char move_prerequisites_bytes[sizeof(MotorControlRS::ESS_RS::MovePrerequisites)];
unsigned char action_context_bytes[sizeof(MotorControlRS::ESS_RS::ActionContext)];
unsigned char axis_config_bytes[sizeof(MotorControlRS::AxisConfig)];
unsigned char axis_reference_bytes[sizeof(MotorControlRS::AxisReference)];
unsigned char position_request_bytes[sizeof(MotorControlRS::PositionRequest)];
unsigned char prepared_target_bytes[sizeof(MotorControlRS::PreparedTarget)];
}
