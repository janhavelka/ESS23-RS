#include <MotorControlRS/profiles/ess_rs/Position.h>
#include <cstdio>
int main() { using namespace MotorControlRS; using namespace ESS_RS;
    std::printf("{\"AxisConfig\":%zu,\"AxisReference\":%zu,\"PositionRequest\":%zu,\"PreparedTarget\":%zu,\"MoveContext\":%zu,\"PreparedMove\":%zu,\"MovePrerequisites\":%zu,\"ActionContext\":%zu}\n",
        sizeof(AxisConfig),sizeof(AxisReference),sizeof(PositionRequest),sizeof(PreparedTarget),
        sizeof(MoveContext),sizeof(PreparedMove),sizeof(MovePrerequisites),sizeof(ActionContext));
}
