import sys,time,re,json
from pathlib import Path
sys.path.insert(0,'scripts')
from bench_session import run_recorded,checked
from bench_probe import BenchError,observe_stopped
from bench_motion import profile_snapshot,restore_profile

def human(c,text,terminal=None,timeout=12):
 assert not c.pending and not c.buffer
 c.emit('human_command',text=text); c.port.write((text+'\n').encode())
 end=time.monotonic()+timeout; quiet=end; data=bytearray()
 while time.monotonic()<end:
  chunk=c.port.read(8192)
  if chunk: data.extend(chunk); quiet=time.monotonic()+.1
  decoded=data.decode('utf-8')
  if data and time.monotonic()>=quiet and (terminal is None or terminal in decoded):
   c.emit('human_output',text=decoded); print(text+'\n'+decoded,flush=True); return decoded
  time.sleep(.005)
 c.synchronized=False
 raise BenchError('missing human terminal: '+text)

def position(state):
 return state['state_blocks'][2]['raw_position']

def run(c,r):
 r['config']=checked(c,'read-config',address=1)
 r['baseline']=observe_stopped(c,address=1,timeout_s=5)
 r['profile']=profile_snapshot(c,timeout_s=5)
 try:
  r['syntax']=[human(c,x) for x in ('speed 600 rpm','accel 200 ms','decel 50ms','speed 60rpm','accel 100','decel 100 ms')]
  rejected=human(c,'moveby 1/3 steps','Details:'); assert 'No motion command was sent' in rejected and 'After reviewing' not in rejected
  r['rejected']=rejected
  r['moves']=[]
  for i in range(4):
   output=human(c,'moveby 90 deg','Details:'); assert 'Move complete' in output
   child=int(re.search(r'Details: @1 result (\d+)',output).group(1))
   result=checked(c,'result',operation_id=child)
   r['moves'].append(dict(text=output,result=result,state=observe_stopped(c,address=1,timeout_s=5)))
  output=human(c,'moveto 0 deg','Details:'); assert 'Move complete' in output
  child=int(re.search(r'Details: @1 result (\d+)',output).group(1))
  r['return']=dict(text=output,result=checked(c,'result',operation_id=child),state=observe_stopped(c,address=1,timeout_s=5))
  r['noop']=human(c,'moveto 0 steps','Details:'); assert 'Requested target already satisfied' in r['noop']
  r['axis']=checked(c,'axis',host_args=('config',))
  r['readback_positions']=[position(r['baseline'])]+[position(m['state']) for m in r['moves']]+[position(r['return']['state'])]
  assert abs(r['readback_positions'][-1]-r['readback_positions'][0])<=1
  assert r['return']['result']['effective_native']==r['axis']['origin_native']
  r['workload_verified']=True
 finally:
  if c.synchronized:
   r['stop']=checked(c,'stop',address=1,stop_policy='normal')
   r['stopped']=observe_stopped(c,address=1,timeout_s=5)
   r['restored']=restore_profile(c,timeout_s=5)
  else:r['cleanup']='unknown: framing lost, no replay'
run_recorded(port='COM13',out=Path(sys.argv[1]),scenario='boot-zero-and-rejection-regression',inputs={'quarter_turns':4,'speed_rpm':60,'ramps_ms':100,'return_to_boot_zero':True,'implicit_device_clear':False},run=run,refresh=False,firmware=Path('build/usb_motion_fix/pio/bench_s3_load_timer/firmware.bin'))
