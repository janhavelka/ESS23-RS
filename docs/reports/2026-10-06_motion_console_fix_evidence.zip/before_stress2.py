import sys,time,json
from pathlib import Path
sys.path.insert(0,'scripts')
from bench_session import run_recorded,checked
from bench_probe import observe_stopped

def run(c,r):
 r['stopped']=observe_stopped(c,address=1,timeout_s=5)
 r['retained']=checked(c,'result',operation_id=14)
 end=time.monotonic()+300
 r['queries']=0
 while time.monotonic()<end and r['queries']<10000:
  r['last']=checked(c,('stats','version','host','config')[r['queries']%4])
  r['queries']+=1
  if r['queries']%1000==0: print(r['queries'],flush=True)
 r['workload_verified']=True
run_recorded(port='COM13',out=Path('build/usb_motion_fix/before_stress2'),scenario='reset-board-local-usb-stress',inputs={'seconds':300,'max_queries':10000,'motor_writes':0},run=run,refresh=False,max_records=100000,max_bytes=128*1024*1024)
