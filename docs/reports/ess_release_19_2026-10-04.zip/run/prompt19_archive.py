import hashlib,json,subprocess,zipfile
from pathlib import Path
root=Path.cwd(); bench=root/'build/bench'; reports=root/'docs/reports'
stem='ess_release_19_2026-10-04'; path=reports/(stem+'.json')
data=json.loads(path.read_text(encoding='utf-8'))
data['verification']=dict(final_commit='The commit introducing this report',native_suites=47,python_cases=180,generator_negative_cases=18,inventory_negative_cases=21,installed_consumer='PASS: C++11, installed prefix, no examples include path',firmware_builds={key:'PASS' for key in ('bench_s3_units','bench_s3_probe','bench_s3_load_poll','bench_s3_load_timer')},fieldcore_read_only_commit='6debce7c44af9bc36f00fbcaccdfa47631846cce',target_sizes=dict(App=181024,Record=7768,Console=18448,Esp32S3Uart=1720,Runner=320,BusOwner=144,HostTuple=8,HostTiming=60,HostSnapshot=120),independent_review=['SDK/framing reviewer audited other-author owner/main/console/Python and re-reviewed fixes','Configuration-ownership reviewer audited other-author adapter/console/Python and re-reviewed fixes'],hardware=dict(host_only_sixteen_setups='PASS',two_mismatch_restore_scenarios='PASS',unchanged_motor_readback='PASS',short_probe_regression='PASS',alternate_motor_communication='NOT RUN',external_electrical_timing='NOT RUN',physical_sdk_failure_injection='NOT RUN'))
data['verification']['generator_cases']=data['verification'].pop('generator_negative_cases')
data['verification']['operation_inventory_cases']=data['verification'].pop('inventory_negative_cases')
backup=bench/'co2control_com13_before.bin'
assert backup.stat().st_size==16777216
backup_hash=hashlib.sha256(backup.read_bytes()).hexdigest()
assert backup_hash=='85c089bc3956b22037af7e6f0d7945f6ed778bb1a0526fb5b2ba3e8fea02d0c1'
data['original_backup']=dict(bytes=backup.stat().st_size,sha256=backup_hash,preserved=True)
path.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
archive=reports/(stem+'.zip')
members={}
for name in ('prompt19_build.log','prompt19_native_build.log','prompt19_native_tests.log','prompt19_upload.log','prompt19_preflight.json','prompt19_campaign.log','prompt19_campaign.py','prompt19_sizes.py','prompt19_inspect.py','prompt19_archive.py','prompt19_timer_firmware.bin','prompt19_before_guard_timer_firmware.bin','prompt19_before_guard_upload.log','ess_format_manual_page69.png'):
    members['run/'+name]=(bench/name).read_bytes()
members['run/evidence.json']=path.read_bytes()
members['firmware/bench_s3_load_timer/firmware.elf']=(root/'.pio/build/bench_s3_load_timer/firmware.elf').read_bytes()
members['source/tracked_implementation.diff']=subprocess.check_output(['git','diff','--','CMakeLists.txt','README.md','examples','scripts','test','docs',':!docs/reports'])
for relative in ('examples/common/HostSerial.h','test/host_app_test.cpp','test/host_console_test.cpp','docs/host_serial.md','docs/prompts/ess_release/19_host_serial_tuple_support.md','docs/prompts/ess_release/execution_contract.md'):
    members['source/'+relative]=(root/relative).read_bytes()
manifest={key:dict(bytes=len(value),sha256=hashlib.sha256(value).hexdigest()) for key,value in members.items()}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as zipped:
    for key,value in members.items(): zipped.writestr(key,value)
    zipped.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as zipped:
    assert zipped.testzip() is None
    for key,item in manifest.items(): assert hashlib.sha256(zipped.read(key)).hexdigest()==item['sha256']
print('Archive',archive.stat().st_size,'bytes;',len(manifest),'verified members')
