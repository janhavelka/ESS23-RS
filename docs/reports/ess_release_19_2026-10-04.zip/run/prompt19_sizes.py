import json
from elftools.elf.elffile import ELFFile
names={'App','Record','Console','Esp32S3Uart','HostSnapshot','HostTiming','HostTuple','BusOwner','Runner'}
out={}
with open('.pio/build/bench_s3_load_timer/firmware.elf','rb') as f:
    for cu in ELFFile(f).get_dwarf_info().iter_CUs():
        for die in cu.iter_DIEs():
            name=die.attributes.get('DW_AT_name');size=die.attributes.get('DW_AT_byte_size')
            if name and size and name.value.decode(errors='replace') in names:
                key=name.value.decode();out.setdefault(key,[])
                if size.value not in out[key]: out[key].append(size.value)
print(json.dumps(out,indent=2))
