import json
d=json.load(open('docs/reports/ess_release_19_2026-10-04.json'))
s=d['snapshots']
for key,field in [('before_read-identity','identity'),('before_read-config','config'),('before_read-state','state_blocks')]:
    print(key,json.dumps(s[key][field]))
commands=[e for e in d['events'] if e['event']=='exact_command_wire']
lines=[json.loads(e['text']) for e in d['events'] if e['event']=='line' and e['text'].startswith('{')]
print('commands',len(commands),'accepted records',sum(e['type']=='accepted' for e in lines))
print('host setup gen',s['historical_probe']['host_serial'],s['tuple_restore']['serial_generation'])
print('firstlastcommands',commands[0],commands[-1])
