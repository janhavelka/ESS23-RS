import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
REPORTS = ROOT / 'docs/reports'
STEM = 'ess_release_12_2026-10-04'
def sha(data): return hashlib.sha256(data).hexdigest()

verification = dict(baseline='c708153', final_commit='The commit introducing this evidence',
    scope='Prompt12 only; wait completed after prompt11 implementation and audit commits synced',
    native=dict(result='PASS', suites=27, compiler='GCC15.1.0 C++11', flags='-Werror',
                generator_cases=17, inventory_cases=14, harness_cases=155, catalogue_independent_link='PASS'),
    installed_consumer='PASS', contrast_snapshots=5,
    firmware={env:'PASS' for env in ('bench_s3_units','bench_s3_probe','bench_s3_load_poll','bench_s3_load_timer')},
    physical_pair_write_readback_restore='NOT RUN: independent timing/source and stopped-state/input/interpretation prerequisites absent',
    reviewed_fc10_windows=['0x0024/2','0x0021/5','0x001D/3','0x0031/6'], new_windows=0,
    writable_pair_dispositions=20, split_fc06='UNAVAILABLE', atomicity='UNSPECIFIED',
    fieldcore_read_only_commit='7c356aff59132ab7ab7be6e3ec26a599ede6b99e',
    review_fix='Canonical hexadecimal emission prevents accepted0024 being emitted as octal C++; regression and independent rereview passed',
    backup_sha256='85c089bc3956b22037af7e6f0d7945f6ed778bb1a0526fb5b2ba3e8fea02d0c1')
summary={name:json.loads((HERE/filename).read_text(encoding='utf-8')) for name,filename in
         [('preflight','preflight.json'),('campaign','summary.json'),('ending','ending.json')]}
summary['verification']=verification
assert summary['ending']['stats']['frames']==38 and summary['ending']['stats']['rx_bytes']==358
assert not any(summary['ending']['stats'][k] for k in ('failed','timeouts','cancelled','capture_faults','rx_errors'))
(HERE/'verification.json').write_text(json.dumps(verification,indent=2)+'\n',encoding='utf-8')
(REPORTS/(STEM+'.json')).write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
(HERE/'changes.diff').write_bytes(subprocess.run(['git','diff','--','.',':!docs/reports/*'],cwd=ROOT,check=True,stdout=subprocess.PIPE).stdout)
members={}
def add(path,name): members[name]=path.read_bytes()
for path in HERE.iterdir():
    if path.is_file(): add(path,'run/'+path.name)
for folder in ('src','include','examples','scripts','test'):
    for path in (ROOT/folder).rglob('*'):
        if path.is_file() and '__pycache__' not in path.parts and path.suffix!='.pyc':
            add(path,'source/'+path.relative_to(ROOT).as_posix())
for name in ('CMakeLists.txt','platformio.ini','library.properties','library.json','AGENTS.md',
             'docs/ess_pair_writes.md','docs/reference/ess_rs_registers.json','docs/reference/ess_rs_operations.json',
             'docs/prompts/ess_release/execution_contract.md','docs/prompts/ess_release/12_paired_register_write_policy.md'):
    if (ROOT/name).is_file(): add(ROOT/name,'source/'+name)
for env in verification['firmware']:
    for name in (('firmware.bin','firmware.elf') if env=='bench_s3_load_timer' else ('firmware.bin',)):
        add(ROOT/'.pio/build'/env/name,'firmware/'+env+'/'+name)
for path,name in [('build/native/Testing/Temporary/LastTest.log','native_final.log'),
                  ('build/native/CMakeCache.txt','native_cache.txt'),
                  ('build/installed_consumer_p12/Testing/Temporary/LastTest.log','installed_consumer.log')]:
    add(ROOT/path,'verification/'+name)
add(REPORTS/(STEM+'.md'),'report.md')
manifest={name:dict(bytes=len(data),sha256=sha(data)) for name,data in sorted(members.items())}
archive=REPORTS/(STEM+'_evidence.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as out:
    for name,data in sorted(members.items()): out.writestr(name,data)
    out.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as out:
    assert out.testzip() is None
    for name,expected in manifest.items():
        data=out.read(name)
        assert len(data)==expected['bytes'] and sha(data)==expected['sha256']
print(json.dumps(dict(archive_bytes=archive.stat().st_size,members=len(manifest),sha256=sha(archive.read_bytes()))))
