import json
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'scripts'))
from bench_probe import Console, Evidence, open_port
from serial.tools import list_ports
HERE = Path(__file__).resolve().parent
ports = [{'device': p.device, 'hwid': p.hwid} for p in list_ports.comports()]
(HERE / 'ports.json').write_text(json.dumps(ports, indent=2), encoding='utf-8')
with (HERE / 'preflight.jsonl').open('x', encoding='utf-8') as log, open_port('COM13', 115200, 3) as port:
    console = Console(port, on_event=Evidence(log))
    console.drain_startup(.5)
    result = {'version': console.identify()}
    for command in ('config', 'stats', 'load', 'drv', 'memory', 'caps'):
        result[command] = console.command(command)
        assert result[command]['ok'], result[command]
(HERE / 'preflight.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result, indent=2))
