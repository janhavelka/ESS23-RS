import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'scripts'))
from bench_probe import Console, Evidence, open_port

HERE = Path(__file__).resolve().parent
summary = {'baseline': 'c708153', 'physical_actions': 'NOT RUN: independent TX/RX/DE and FC06 echo exclusion missing'}
with (HERE / 'final.jsonl').open('x', encoding='utf-8') as log, open_port('COM13', 115200, 3) as port:
    console = Console(port, on_event=Evidence(log))
    console.drain_startup(.5)
    summary['version'] = console.identify()
    def checked(command, **kwargs):
        value = console.command(command, **kwargs)
        assert value['ok'], value
        return value
    summary['config'] = checked('config')
    summary['stats_start'] = checked('stats')
    summary['load_before'] = checked('load')
    assert [summary['load_before'][k] for k in ('workload_us', 'owner_delay_us', 'console_bytes')] == [0, 0, 0]
    summary['caps'] = checked('caps')
    assert summary['caps']['writes'] and not summary['caps']['actions_qualified']
    summary['identity'] = checked('read-identity', address=1)
    summary['configuration_before'] = checked('read-config', address=1)
    summary['state_before'] = checked('read-state', address=1)
    summary['stats_before_gates'] = checked('stats')
    summary['gates'] = []
    for command, policy in [('enable', None), ('motor-release', None), ('alarm-clear', None), ('stop', 'normal'), ('stop', 'direct')]:
        result = console.command(command, address=1, stop_policy=policy)
        assert result['ok'] is False and result['result'] == 'timing_unqualified' and result['operation_id'] == 0, result
        summary['gates'].append(result)
    summary['stats_after_gates'] = checked('stats')
    assert summary['stats_before_gates'] == {**summary['stats_after_gates'], 'id': summary['stats_before_gates']['id']}
    summary['capture_read'] = checked('capture-read', address=1)
    summary['probes'] = [checked('probe', address=1) for _ in range(10)]
    summary['state_after'] = checked('read-state', address=1)
    summary['configuration_after'] = checked('read-config', address=1)
    for name in ('configuration', 'state'):
        before = summary[name + '_before']; after = summary[name + '_after']
        assert [x['rx'] for x in before['steps']] == [x['rx'] for x in after['steps']], name
    for command in ('status', 'health', 'stats', 'memory', 'load', 'drv', 'caps'):
        summary['final_' + command] = checked(command)
    drv = summary['final_drv']
    assert not any(drv[k] for k in ('busy', 'transmit_enabled', 'recovery_required', 'pending', 'retained', 'reserved'))
    assert not summary['final_caps']['axis_reserved']
    assert not summary['final_load']['sample_gap_exceeded']
    assert summary['final_stats']['frames'] - summary['stats_start']['frames'] == 28, summary['final_stats']
    summary['ok'] = True
image = ROOT / '.pio/build/bench_s3_load_timer/firmware.bin'
summary['firmware_bytes'] = image.stat().st_size
summary['firmware_sha256'] = hashlib.sha256(image.read_bytes()).hexdigest()
(HERE / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: summary[k] for k in ('ok', 'firmware_bytes', 'firmware_sha256', 'final_stats', 'final_memory', 'final_load', 'final_drv')}, indent=2))
