# Prompt 12: paired-register write policy

Executed only prompt 12 after prompt 11's implementation `86c6d9a` and fresh
audit `c708153` had both landed and synced. Baseline: `c708153`; final revision
is the commit introducing this report. The [per-pair handoff](../ess_pair_writes.md)
contains the source review and downstream restrictions. [Structured evidence](ess_release_12_2026-10-04.json)
and the [archive](ess_release_12_2026-10-04_evidence.zip) retain raw traffic,
source snapshots, generator/native/build checks, exact firmware and a member
SHA-256 manifest. Software and available read-only hardware checks: **PASS**.
Physical pair writes/readback/restore: **NOT RUN**, with prerequisites below.

## Selection and implementation

The original ESS pages establish **no additional admissible FC10 window**.
The four existing windows remain exactly `0x0024/2`, `0x0021/5`, `0x001D/3`
and `0x0031/6`. Writable metadata, adjacency, generic Modbus maxima and a
containing example do not authorize another span. All paired halves remain
unavailable through FC06. No new device setting, action or escape hatch was added.

The codec's handwritten FC10 allowlist and count-shape list now come from
`write_multiple_windows` in the existing register ledger. Generated private
`Access.h` supplies both checks without linking descriptive strings. The
generator rejects incomplete pairs, gaps, reserved/read-only/unspecified-access
words, duplicate windows, missing source evidence and invented atomicity.
Its structural 256-byte frame bound is not a claimed ESS device maximum.

All **20 writable pairs** have ledger-owned `write_constraint` explanations.
The generated catalogue and `check_ess_operations.py --details` expose the
reviewed containing windows and unresolved reasons, without granting typed
implementation or hardware credit. The twenty-first pair is read-only current
position. The existing typed Position API and its common/native CLI routes
already reuse `encodeInt32` with qualified interpretation prerequisites; no
additional fully resolved field justifies another pair helper or setter stub.

| Requirement / failure scenario | Production path and actual API | Native/build evidence | Hardware result and artifact | Remaining proof |
| --- | --- | --- | --- | --- |
| Inventory active target, offset, limits and stored targets | Ledger constraints, generated catalogue, derived operation inventory | Exactly 20 writable-pair dispositions; 221-record denominator and implementation credit unchanged PASS | Read-only identity/configuration/state retained | Negative encoding, native bounds/scale remain field-specific |
| Establish homing-offset word order | Original p19/20/30/73 and pair handoff | Source audit preserves UNRESOLVED | Interpretation experiment NOT RUN | p30 omits offset; p20 writes zero, which cannot distinguish order |
| Exact source-supported FC10 policy | Generated access/count checks, existing public codec | All 65536 start addresses against 11 counts; literal four-window fixtures PASS | No physical FC10 sent | Limits, standalone offset and stored targets lack reviewed windows |
| No split halves or access bypass | FC06 validator/builder/parser and checked FC10 parser | All 42 paired halves, neighboring spans, reserved slots, CRC/echo/capacity and unchanged outputs PASS | Action gates reject without TX | Library rejection does not prove device rejection |
| Catalogue remains optional | Private generated helpers | C++11 codec fixture links only Codec.cpp, with no Registers.cpp PASS | Four firmware builds PASS | None for this software boundary |
| Both word orders and helper reuse | Existing encode/decode and Position staging | Signed boundaries/asymmetric vectors and existing move tests PASS | No word-order setting changed | Arithmetic is not ESS negative-encoding qualification |
| Partial application and experiment | Per-pair policy; retained transaction uncertainty | No atomic/rollback promise; generator negative checks PASS | Pair write/readback/restore NOT RUN | Timing/source, stopped/input and interpretation prerequisites missing |
| Handoff to 13–18 | Pair guide; explicit links in 13, 14 and 16 | No speculative API/CLI; unavailable reasons retained | No future prompt executed | Source or bounded firmware evidence before expansion |

## Independent review and verification

A PDF/access-policy reviewer inspected original pages 8, 16, 18, 19, 20,
22, 23, 29, 30, 70, 73, 75, 76 and 79, then authored the pair handoff.
An independent wire-fixture reviewer inspected actual codec/generator/callers,
expanded the tests and reviewed the root's production changes. The root checked
the actual diff and rendered original pages 8, 30 and 73 independently. Vendor
bytes were preserved; function PDF SHA-256 remains
`0ca2d7f6b69404ead3ba9af982076c54f86eb16b1c24ba237f344aac079b81eb`.

Final review found a generator bug introduced during this block: input spelling
`0024` validated as hexadecimal but was emitted as a C++ octal literal. The
generator now emits canonical `0x%04X` from the parsed value. A regression proves
equivalent spellings generate identical policy. The reviewer independently
verified the fix; generated C++ and the current-image permission set stayed
unchanged. No remaining confirmed blocker was found in scope.

Verification: strict native Release build with GCC 15.1.0 and `-Werror`,
**27/27 CTests PASS**, including **17 generator checks**, **14 inventory tests**,
**155 Python harness tests**, actual console parity, delayed/masked capture,
position/velocity/application tests and the isolated codec link. Installed-only
C++11 consumer PASS. Offline contrast snapshots: five PASS. All four firmware
environments (units/probe/load-poll/load-timer) PASS. Timer static RAM 29368 bytes,
linked flash 424028 bytes; no public type, application storage or CLI grammar change.

FieldCore was inspected read-only at `7c356aff59132ab7ab7be6e3ec26a599ede6b99e`:
owner/task/backend/device-module/CLI retain the bounded request/work/result
convention. Eight-byte TX capacity cannot carry 13–21-byte FC10, and identical
request-prefix stripping cannot establish a motor FC06 response source. This
repository retains framework-neutral codecs and its own application owner;
no FieldCore file was edited.

## Current-image read-only regression

Preflight reidentified COM13 USB `303A:1001`, serial `3C:0F:02:CD:6B:98`,
MotorControl-RS 0.6.0 protocol 2. Previous-image counters were 19 frames/167 RX
bytes, zero errors, load off and owner empty; no reset/recover cleared them.
Pins remain UART2 TX47/RX48/DE21, node 1, 115200 8N1, 20-us timer capture,
85-us sample-gap bound, 200-ms response timeout and reviewed 304-us reply gap.

Final timer image: 429888 bytes, SHA-256
`43e3a3abf7d8dea7e5f5f473a149786bfa4da1e697ec0f5762d9455904cb4270`.
Upload completed with verified flash hashes. Original 16-MiB CO2control backup
was preserved/rehashed:
`85c089bc3956b22037af7e6f0d7945f6ed778bb1a0526fb5b2ba3e8fea02d0c1`.

The campaign completed 28 FC03 frames: one identity read, configuration/state
before and after, one 37-byte capture reply and ten probes. Five explicit action
gates rejected before TX with unchanged counters. Ten additional one-attempt
probes at 50-ms intervals passed. Final totals: **38 frames/358 RX bytes**, zero
failures/timeouts/cancellations/capture faults/UART errors/discarded/echo bytes.
Raw configuration and state match before/after: model `4EEA`, firmware `0029`,
alarm/motion 0/1, I/O 0/0, position/speed 0. No motor write or move was sent.

Campaign probes: 5.442–5.653 ms; 37-byte capture: 8.099 ms. Ending active-owner
gap 143 us, capture gap 54 us, high-water 2; no sample-gap fault. Capture-section
time 18178976/89060955 us is about 20.41% of one core; separate scheduler snapshot
0%/6% busy. Optional diagnostic trace overwrites 610 do not indicate lost frame
evidence. This short unloaded check does not extend electrical/load qualification.

Internal free/minimum/largest: 336656/331496/278516 bytes; PSRAM:
8291884/8291884/8257524 bytes; owner/worker stack headroom 3476/3268 bytes.
Ending load/monitor off, DE released, no pending/retained/reserved work or axis
conflict/recovery requirement; no console drops, blocks or short writes.

## Gates and next handoff

Physical pair write/readback/restore remains **NOT RUN** because independent
TX/RX/DE/response-source qualification and established stopped/input/interpretation
prerequisites are absent. The handoff defines a narrow future experiment on
the already reviewed `0x0024/2` parameter with saved raw words, no trigger/save,
one attempt and explicit verified restoration. An uncertain write ends automatic
sequencing; a failed restore remains unresolved. No unknown-window sweep is
authorized by that design, and even successful raw readback would not resolve
homing-offset interpretation or family-wide atomicity.

Prompt 13 is next only when dispatched. It may implement independently supported
single-word settings while retaining guarded soft-limit pairs. Prompt 14 must
not infer offset order from the containing homing window; prompt 16 must keep
all stored target writes unavailable until an admissible form is established.
Prompts 15, 17 and 18 likewise receive no new bulk-write permission. Source
review is complete for this block; the specific vendor/fixture proof gaps remain
visible rather than becoming a family-wide qualification pass.
