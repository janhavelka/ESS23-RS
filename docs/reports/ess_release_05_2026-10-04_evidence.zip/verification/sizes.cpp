#include "MotorControlRS/profiles/ess_rs/Reads.h"
#include "ProbeConsole.h"
extern "C" {
unsigned char sizeReadContext[sizeof(MotorControlRS::ESS_RS::ReadContext)];
unsigned char sizePreparedRead[sizeof(MotorControlRS::ESS_RS::PreparedRead)];
unsigned char sizeIdentity[sizeof(MotorControlRS::ESS_RS::IdentityObservation)];
unsigned char sizeConfig[sizeof(MotorControlRS::ESS_RS::ConfigObservation)];
unsigned char sizeConsole[sizeof(MotorControlRSExample::Probe::Console)];
}
