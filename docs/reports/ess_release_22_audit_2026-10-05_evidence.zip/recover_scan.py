import sys,time,json,serial
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/"scripts"))
import bench_probe as b
root=Path("build/p22_audit_evidence")
with (root/"recovery.jsonl").open("x",encoding="utf-8") as log, serial.Serial("COM13",115200,timeout=0,write_timeout=2) as port:
 def emit(kind,**v):
  log.write(json.dumps(dict(event=kind,**v))+"\n");log.flush()
 c=b.Console(port,on_event=emit);time.sleep(.2);port.read(65536)
 def cmd(name,**args):
  value=c.command(name,timeout_s=4,**args)
  if not value["ok"]:raise RuntimeError((name,value))
  return value
 summary={"version":c.identify(),"before":cmd("stats"),"host_before":cmd("host")}
 summary["begin"]=cmd("discover",host_args=("addresses","1","3","identity"))
 summary["recovery"]=cmd("recover")
 retained=cmd("discover",host_args=("inspect",))["scan"]
 assert retained["cancel_requested"] and retained["requests"]<=1
 assert not any(f["identity_attempted"] for f in retained["findings"])
 if retained["phase"]==4:retained=cmd("discover",host_args=("restore",))["scan"]
 assert retained["phase"]==5 and retained["restored"]
 summary["scan"]=retained
 cmd("discover",host_args=("finish",))
 summary["probe"]=cmd("probe",address=1)
 summary["final"]={n:cmd(n) for n in ("host","stats","memory","drv","status","health")}
 (root/"recovery_summary.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8")
 print("Recovery interrupted scan; requests",retained["requests"],"count",retained["count"],"outcome",retained["outcome"])
