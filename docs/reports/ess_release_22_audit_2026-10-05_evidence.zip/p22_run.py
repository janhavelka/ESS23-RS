import sys,time,json,serial
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/"scripts"))
import bench_probe as b
root=Path("build/p22_audit_evidence")
summary={"cases":[]}
with (root/"physical.jsonl").open("x",encoding="utf-8") as log, serial.Serial("COM13",115200,timeout=0,write_timeout=2) as port:
 def emit(kind,**v):
  log.write(json.dumps(dict(event=kind,**v))+"\n");log.flush()
 c=b.Console(port,on_event=emit)
 time.sleep(.2); port.read(65536)
 def cmd(name,**args):
  value=c.command(name,timeout_s=4,**args)
  if not value["ok"]: raise RuntimeError((name,value))
  return value
 summary["version"]=c.identify();summary["initial"]={n:cmd(n) for n in ("config","load","host","stats","memory")}
 summary["before"]={n:cmd(n,address=1) for n in ("read-identity","read-config","read-state")}
 summary["profiles"]=cmd("profile-list");summary["caps"]=cmd("caps")
 def control(*tokens): return cmd("discover",host_args=tuple(tokens))
 def scan(tokens,label):
  begun=control(*tokens);end=time.monotonic()+6
  while time.monotonic()<end:
   s=control("inspect")["scan"]
   if s["phase"] in (4,5):break
   time.sleep(.01)
  else:raise RuntimeError("scan failed to settle")
  summary["cases"].append(dict(case=label,scan=s));print(label,s["phase"],s["outcome"],s["count"],flush=True)
  if s["phase"]==4:
   rejected=c.command("discover",host_args=("restore",),timeout_s=4)
   assert not rejected["ok"]
   summary["cases"][-1]["restore_before_recovery"]=rejected
   summary["cases"][-1]["recovery"]=cmd("recover")
   s=control("restore")["scan"]
   assert s["phase"]==5 and s["restored"]
  control("finish")
  summary["cases"][-1]["restored_probe"]=cmd("probe",address=1)
 scan(("identity",),"default_identity")
 scan(("addresses","1","2","identity","requests","4","results","4"),"range_partial_timeout")
 scan(("addresses","1","3","results","1"),"result_budget")
 scan(("identity","requests","1"),"request_budget")
 scan(("tuple","115200","8N1","tuple","9600","8N1"),"supported_tuple_mismatch")
 summary["after"]={n:cmd(n,address=1) for n in ("read-identity","read-config","read-state")}
 summary["regression"]=[cmd("probe",address=1) for _ in range(10)]
 summary["final"]={n:cmd(n) for n in ("config","load","host","stats","memory","drv","status","health")}
(root/"physical_summary.json").write_text(json.dumps(summary,indent=2)+"\n")
print("Complete: final host",summary["final"]["host"],flush=True)
